// -----------------------------------------------------------------------------
//
// SKIP
//
// -----------------------------------------------------------------------------
using System;
using RuntimeXNA.RunLoop;
namespace RuntimeXNA.Actions
{
	
	public class ACT_SKIP:CAct
	{
		public override void  execute(CRun rhPtr)
		{
		}
	}
}