﻿//----------------------------------------------------------------------------------
//
// CROTATEDMASK
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Sprites;

namespace RuntimeXNA.Banks
{
    class CRotatedMask
    {
		public CMask mask;
		public int angle;
		public float scaleX;
		public float scaleY;
		public int tick;
    }
}
