﻿//----------------------------------------------------------------------------------
//
// CSOUNDBANK : Stockage des sons
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Audio;
using System.Linq;
using System.Text;
using RuntimeXNA.Application;
using RuntimeXNA.Services;

namespace RuntimeXNA.Banks
{
    public class CSound
    {
		public short handle;
		public SoundEffect sound=null;
        public SoundEffectInstance soundInstance = null;
		public int useCount=0;
		public bool bUninterruptible=false;
		public int nLoops=0;
		public int numSound=0;
		public string name;

        public void loadHandle(CFile file)
        {
            handle = file.readAShort();
			int l=file.readAShort();
			if (file.bUnicode==false)
			{ 
				file.skipBytes(l);
			}
			else
			{
				file.skipBytes(l*2);
			}
        }

        public static CSound createFromSound(CSound source)
        {
            CSound snd = new CSound();
            snd.handle = source.handle;
            snd.sound = source.sound;
            snd.name = source.name;
            return snd;
        }
        public void load(CRunApp app)
        {
            handle = app.file.readAShort();
			int l=app.file.readAShort();
			name=app.file.readAString(l);

            string sndName = handle.ToString("D4");
            sndName = "Snd" + sndName;
            sound = app.content.Load<SoundEffect>(sndName);
        }

		public void play(int nl, bool bPrio, float v, float p)
		{
			nLoops=nl;
			if (nLoops==0)
			{
				nLoops=10000000;
			}
			if (soundInstance!=null)
			{
				soundInstance.Stop();
                soundInstance.Dispose();
                soundInstance = null;
			}
    
            if (soundInstance==null)
            {
                soundInstance=sound.CreateInstance();
            }
            if (soundInstance != null)
            {
                soundInstance.Volume = (float)(v/100.0);
                soundInstance.Pan = (float)(p/100.0);
                soundInstance.Play();
                bUninterruptible= bPrio;
            }
		}

        public void stop()
        {
            if (soundInstance != null)
            {
                soundInstance.Stop();
                soundInstance.Dispose();
                soundInstance = null;
                bUninterruptible = false;
            }
        }
        public void setVolume(int v)
        {
            if (soundInstance != null)
            {
                soundInstance.Volume = (float)(v/100.0);
            }
        }
        public void setPan(int p)
        {
            if (soundInstance != null)
            {
                soundInstance.Pan= (float)(p/100.0);
            }
        }
        public void pause()
        {
            if (soundInstance != null)
            {
                soundInstance.Pause();
            }
        }
        public void resume()
        {
            if (soundInstance != null)
            {
                soundInstance.Resume();
            }
        }
        public bool isPaused()
        {
            if (soundInstance != null)
            {
                if (soundInstance.State == SoundState.Paused)
                {
                    return true;
                }
            }
            return false;
        }
        public bool isPlaying()
        {
            if (soundInstance != null)
            {
                if (soundInstance.State == SoundState.Playing)
                {
                    return true;
                }
            }
            return false;
        }
        public int getDuration()
        {
            TimeSpan time = sound.Duration;
            return time.Milliseconds;
        }
        public bool checkSound()
        {
            if (soundInstance != null)
            {
                if (soundInstance.State==SoundState.Stopped)
                {
                    if (nLoops > 0)
                    {
                        nLoops--;
                        if (nLoops > 0)
                        {
                            soundInstance.Play();
                            return false;
                        }
                    }
                    bUninterruptible = false;
                    soundInstance.Dispose();
                    soundInstance=null;
                    return true;
                }
            }
            return false;
        }

    }
}
