//----------------------------------------------------------------------------------
//
// CGROUPFIND : relocation des groupes
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace RuntimeXNA.Events
{	
	public class CGroupFind
	{
		public short id;
		public int evg;
	}
}