//----------------------------------------------------------------------------------
//
// CLOADQUALIFIERS : chargement des qualifiers
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace RuntimeXNA.Events
{
	
	public class CLoadQualifiers
	{
		public short qOi;
		public short qType;
		
		public CLoadQualifiers()
		{
		}
	}
}