﻿//----------------------------------------------------------------------------------
//
// CRUNACTIVEBACKDROP
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;

namespace RuntimeXNA.Extensions
{
    class CRunActiveBackdrop : CRunExtension
    {
        const int FLAG_VISIBLE=0x00000001;
    
        int nImages;
        short[] imageList = null;
        int flags;
        int currentImage;
        Rectangle tempRect = new Rectangle();

        public override int getNumberOfConditions()
        {
            return 1;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            ho.hoImgWidth = file.readAInt();
            ho.hoImgHeight = file.readAInt();
            nImages = file.readAShort();
            flags = file.readAInt();
            imageList = new short[nImages];
            int n;
            for (n = 0; n < nImages; n++)
            {
                imageList[n] = file.readAShort();
            }
            if (nImages > 0)
            {
                ho.loadImageList(imageList);
                currentImage = 0;
            }
            else
            {
                currentImage = -1;
            }
            return false;
        }

        public override void displayRunObject(SpriteBatch batch)
        {
            if (currentImage >= 0 && ((flags & FLAG_VISIBLE)!= 0))
            {
                CImage image = ho.getImage(imageList[currentImage]);
                if (image != null)
                {
                    tempRect.X = ho.hoX-ho.hoAdRunHeader.rhWindowX+ho.hoAdRunHeader.rhApp.xOffset;
                    tempRect.Y = ho.hoY - ho.hoAdRunHeader.rhWindowY + ho.hoAdRunHeader.rhApp.yOffset;
                    tempRect.Width = image.width;
                    tempRect.Height = image.height;
                    batch.Draw(image.image, tempRect, Color.White);
                }
            }
        }

        public override void getZoneInfos()
        {
            if (currentImage >= 0)
            {
                CImage image = ho.getImage(imageList[currentImage]);
                ho.hoImgWidth = image.width;
                ho.hoImgHeight = image.height;
            }
            else
            {
                ho.hoImgWidth = 1;
                ho.hoImgHeight = 1;
            }
        }

        // Conditions
        // --------------------------------------------------
        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case 0:
                    return cndVisible(cnd);
            }
            return false;
        }
        bool cndVisible(CCndExtension cnd)
        {
            return (flags & FLAG_VISIBLE) != 0;
        }

        // Actions
        // -------------------------------------------------
        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case 0:
                    actSetImage(act);
                    break;
                case 1:
                    actSetX(act);
                    break;
                case 2:
                    actSetY(act);
                    break;
                case 3:
                    actShow(act);
                    break;
                case 4:
                    actHide(act);
                    break;
            }
        }

        void actHide(CActExtension act)
        {
            flags &= FLAG_VISIBLE;
            ho.redisplay();
        }

        void actShow(CActExtension act)
        {
            flags |= FLAG_VISIBLE;
            ho.redisplay();
        }

        void actSetImage(CActExtension act)
        {
            int image = act.getParamExpression(rh, 0);
            if (image >= 0 && image < nImages)
            {
                currentImage = image;
                ho.redisplay();
            }
        }
        void actSetX(CActExtension act)
        {
            ho.hoX = act.getParamExpression(rh, 0);
            ho.redisplay();
        }

        void actSetY(CActExtension act)
        {
            ho.hoY = act.getParamExpression(rh, 0);
            ho.redisplay();
        }

        // Expressions
        // --------------------------------------------
        public override CValue expression(int num)
        {
            switch (num)
            {
                case 0:
                    return expGetImage();
                case 1:
                    return expGetX();
                case 2:
                    return expGetY();
            }
            return null;
        }

        CValue expGetImage()
        {
            return new CValue(currentImage);
        }

        CValue expGetX()
        {
            return new CValue(ho.hoX);
        }

        CValue expGetY()
        {
            return new CValue(ho.hoY);
        }

        
    }
}
