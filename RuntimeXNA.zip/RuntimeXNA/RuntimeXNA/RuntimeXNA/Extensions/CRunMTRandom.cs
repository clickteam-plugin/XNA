﻿//----------------------------------------------------------------------------------
//
// CRunMTTandom: MT random object
// fin 3rd feb 2010
//greyhill
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;

namespace RuntimeXNA.Extensions
{
    class CRunMTRandom : CRunExtension
    {
        const int AID_aSeedClock	=	0;
        const int AID_aSeedOne	=	1;
        const int AID_aSeedTwo	=	2;
        const int AID_aSeedThree =	3;
        const int AID_aSeedFour =	4;
        const int AID_aSeedSix =	5;
        const int AID_aSeedEight =	6;
        const int AID_aSeedTen =	7;
        const int AID_aExpire =	8;
        const int AID_aExpireX =	9;
        const int EID_eRandDbl1			=		0;
        const int EID_eRandDbl1Ex		=	1;
        const int EID_eRandDbl		=		2;
        const int EID_eRandDblEx		=	3;
        const int EID_eRandInt	=		4;
        const int EID_eRandIntEx		=		5;

        MTRandomMersenne rand;
        int START_TIME = -1;


        public CRunMTRandom()
        {
            if (START_TIME == -1)
            {
                START_TIME = DateTime.Now.Millisecond;
            }
        }

        public override int getNumberOfConditions()
        {
            return 0;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            bool seedvalues = (file.readByte() != 0) ? true: false;

            int[] seed = { file.readAInt(), file.readAInt(),
                            file.readAInt(), file.readAInt(),
                            file.readAInt(), file.readAInt(),
                            file.readAInt(), file.readAInt(),
                            file.readAInt(), file.readAInt() };

            this.rand = new MTRandomMersenne();
            if (seedvalues)
            {
                this.rand.setSeed(seed);
            }
    	    return true;
        }

        public override void action(int num, CActExtension act)
        {   
            switch (num)
            {        
                case AID_aSeedClock:
                    rand.setSeed(DateTime.Now.Millisecond);
                    break;        
                case AID_aSeedOne:
                    rand.setSeed(act.getParamExpression(rh, 0));
                    break;
                case AID_aSeedTwo:
                    int[] randvals2 = new int[2];
                    for (int i = 0; i < randvals2.Length; i++){
                        randvals2[i] = act.getParamExpression(rh, i);
                    }
                    rand.setSeed(randvals2);
                    break;
                case AID_aSeedThree:
                    int[] randvals3 = new int[3];
                    for (int i = 0; i < randvals3.Length; i++){
                        randvals3[i] = act.getParamExpression(rh, i);
                    }
                    rand.setSeed(randvals3);
                    break;
                case AID_aSeedFour:
                    int[] randvals4 = new int[4];
                    for (int i = 0; i < randvals4.Length; i++){
                        randvals4[i] = act.getParamExpression(rh, i);
                    }
                    rand.setSeed(randvals4);
                    break;
                case AID_aSeedSix:
                    int[] randvals6 = new int[6];
                    for (int i = 0; i < randvals6.Length; i++){
                        randvals6[i] = act.getParamExpression(rh, i);
                    }
                    rand.setSeed(randvals6);
                    break;
                case AID_aSeedEight:
                    int[] randvals8 = new int[8];
                    for (int i = 0; i < randvals8.Length; i++){
                        randvals8[i] = act.getParamExpression(rh, i);
                    }
                    rand.setSeed(randvals8);
                    break;
                case AID_aSeedTen:
                    int[] randvals10 = new int[10];
                    for (int i = 0; i < randvals10.Length; i++){
                        randvals10[i] = act.getParamExpression(rh, i);
                    }
                    rand.setSeed(randvals10);
                    break;
                case AID_aExpire:
                    rand.nextDouble();
                    break;
                case AID_aExpireX:
                    int x = act.getParamExpression(rh, 0);
                    for (int i=0; i<x; i++)
                        rand.nextDouble();
                    break;
            }
        }

        public override CValue expression(int num)
        {
            switch (num)
            {
                case EID_eRandDbl1:
                    return new CValue(rand.nextDouble());
                case EID_eRandDbl1Ex:
                    return new CValue(rand.nextDoubleEx());
                case EID_eRandDbl:
                    double p1 = ho.getExpParam().getDouble();
                    double p2 = ho.getExpParam().getDouble();
                    return new CValue(rand.nextDouble(p1, p2));
                case EID_eRandDblEx:
                    double p1ex = ho.getExpParam().getDouble();
                    double p2ex = ho.getExpParam().getDouble();
                    return new CValue(rand.nextDoubleEx(p1ex, p2ex));
                case EID_eRandInt:
                    int p1int = ho.getExpParam().getInt();
                    int p2int = ho.getExpParam().getInt() + 1;
                    return new CValue(rand.nextIntEx(p2int - p1int) + p1int);
                case EID_eRandIntEx:
                    int p1intex = ho.getExpParam().getInt();
                    int p2intex = ho.getExpParam().getInt();
                    return new CValue(rand.nextIntEx(p2intex - p1intex) + p1intex);
            }
            return new CValue(0);//won't be used
        }

    }

    class MTRandomMersenne
    {

        private static int N = 624;
        private static int M = 397;
        private static int MATRIX_A = unchecked((int)0x9908b0df);
        private static int UPPER_MASK = unchecked((int)0x80000000);
        private static int LOWER_MASK = 0x7fffffff;
        private static int TEMPERING_MASK_B = unchecked((int)0x9d2c5680);
        private static int TEMPERING_MASK_C = unchecked((int)0xefc60000);
        private int[] mt; // state 
        private int mti; // mti==N+1 means mt[N] is not initialized
        private int[] mag01;

        public MTRandomMersenne()
        {
            setSeed(DateTime.Now.Millisecond);
        }

        public MTRandomMersenne(long seed)
        {
            setSeed(seed);
        }

        /**
          * Initalize the pseudo random number generator.  Don't
          * pass in a long that's bigger than an int (Mersenne Twister
          * only uses the first 32 bits for its seed).   
          */
        public void setSeed(long seed) 
        {
       
            mt = new int[N];

            mag01 = new int[2];
            mag01[0] = 0x0;
            mag01[1] = MATRIX_A;

            mt[0] = (int) (seed & 0xffffffff);
            for (mti = 1; mti < N; mti++) {
                mt[mti] =(int)(1812433253 * (mt[mti - 1] ^ (((uint)mt[mti - 1]) >> 30)) + mti);
                /* See Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier. */
                /* In the previous versions, MSBs of the seed affect   */
                /* only MSBs of the array mt[].                        */
                /* 2002/01/09 modified by Makoto Matsumoto             */
                mt[mti] &= unchecked((int)0xffffffff);
                /* for >32 bit machines */
            }
        }

        /**
         * Sets the seed of the MersenneTwister using an array of integers.
         * Your array must have a non-zero length.  Only the first 624 integers
         * in the array are used; if the array is shorter than this then
         * integers are repeatedly used in a wrap-around fashion.
         */
        public void setSeed(int[] array) 
        {
            if (array.Length == 0) {
                return;
            }
            int i, j, k;
            setSeed(19650218);
            i = 1;
            j = 0;
            k = (N > array.Length ? N : array.Length);
            for (; k != 0; k--) {
                mt[i] = (int)((mt[i] ^ ((mt[i - 1] ^ ( ((uint)mt[i - 1]) >> 30)) * 1664525)) + array[j] + j); /* non linear */
                mt[i] &= unchecked((int)0xffffffff); /* for WORDSIZE > 32 machines */
                i++;
                j++;
                if (i >= N) {
                    mt[0] = mt[N - 1];
                    i = 1;
                }
                if (j >= array.Length) {
                    j = 0;
                }
            }
            for (k = N - 1; k != 0; k--) {
                mt[i] = (int)((mt[i] ^ ((mt[i - 1] ^ ( ((uint)mt[i - 1]) >> 30)) * 1566083941)) - i); /* non linear */
                mt[i] &= unchecked((int)0xffffffff); /* for WORDSIZE > 32 machines */
                i++;
                if (i >= N) {
                    mt[0] = mt[N - 1];
                    i = 1;
                }
            }
            mt[0] = unchecked((int)0x80000000); /* MSB is 1; assuring non-zero initial array */
        }

        /** Returns a random double in the half-open range from [0.0,1.0).  Thus 0.0 is a valid
        result but 1.0 is not. */
        public double nextDoubleEx() 
        {
            int y;
            int z;

            if (mti >= N) // generate N words at one time
            {
                int kk;

                for (kk = 0; kk < N - M; kk++) {
                    y = (mt[kk] & UPPER_MASK) | (mt[kk + 1] & LOWER_MASK);
                    mt[kk] = (int)(mt[kk + M] ^ (((uint)y) >> 1) ^ mag01[y & 0x1]);
                }
                for (; kk < N - 1; kk++) {
                    y = (mt[kk] & UPPER_MASK) | (mt[kk + 1] & LOWER_MASK);
                    mt[kk] = (int)(mt[kk + (M - N)] ^ (((uint)y) >> 1) ^ mag01[y & 0x1]);
                }
                y = (mt[N - 1] & UPPER_MASK) | (mt[0] & LOWER_MASK);
                mt[N - 1] = (int)(mt[M - 1] ^ (((uint)y) >> 1) ^ mag01[y & 0x1]);

                mti = 0;
            }

            y = mt[mti++];
            y ^= (int)((uint)y) >> 11;                          // TEMPERING_SHIFT_U(y)
            y ^= (y << 7) & TEMPERING_MASK_B;       // TEMPERING_SHIFT_S(y)
            y ^= (y << 15) & TEMPERING_MASK_C;      // TEMPERING_SHIFT_T(y)
            y ^= (int)(((uint)y) >> 18);                        // TEMPERING_SHIFT_L(y)

            if (mti >= N) // generate N words at one time
            {
                int kk;

                for (kk = 0; kk < N - M; kk++) {
                    z = (mt[kk] & UPPER_MASK) | (mt[kk + 1] & LOWER_MASK);
                    mt[kk] = (int)(mt[kk + M] ^ (((uint)z) >> 1) ^ mag01[z & 0x1]);
                }
                for (; kk < N - 1; kk++) {
                    z = (mt[kk] & UPPER_MASK) | (mt[kk + 1] & LOWER_MASK);
                    mt[kk] = (int)(mt[kk + (M - N)] ^ (((uint)z) >> 1) ^ mag01[z & 0x1]);
                }
                z = (mt[N - 1] & UPPER_MASK) | (mt[0] & LOWER_MASK);
                mt[N - 1] = (int)(mt[M - 1] ^ (((uint)z) >> 1) ^ mag01[z & 0x1]);

                mti = 0;
            }

            z = mt[mti++];
            z ^= (int)(((uint)z) >> 11);                          // TEMPERING_SHIFT_U(z)
            z ^= (z << 7) & TEMPERING_MASK_B;       // TEMPERING_SHIFT_S(z)
            z ^= (z << 15) & TEMPERING_MASK_C;      // TEMPERING_SHIFT_T(z)
            z ^= (int)(((uint)z) >> 18);   
            /* derived from nextDouble documentation in jdk 1.2 docs, see top */
            return ((((long) (((uint)y) >> 6)) << 27) + (((uint)z) >> 5)) / (double) (1L << 53);
        }

        public double nextDouble()
        {
            double r = nextDoubleEx();
            double mu = 1.0;
            return mu * r;
        }

        public double nextDoubleEx(double min, double max)
        {
            double r = nextDoubleEx();
            double diff = max - min;
            r *= diff;
            r += min;
            return r;
        }
        public double nextDouble(double min, double max)
        {
            double r = (1.0 / (1.0 - Double.MinValue)) * nextDoubleEx();
            double mu = 1.0;
            r *= mu;
            double diff = max - min;
            r *= diff;
            r += min;
            return r;
        }

        /** Returns an integer drawn uniformly from 0 to n-1.  */
        public int nextIntEx(int n) 
        {
            n = Math.Max(0, n);

            if ((n & -n) == n) // i.e., n is a power of 2
            {
                int y;

                if (mti >= N) // generate N words at one time
                {
                    int kk;

                    for (kk = 0; kk < N - M; kk++) {
                        y = (mt[kk] & UPPER_MASK) | (mt[kk + 1] & LOWER_MASK);
                        mt[kk] = (int)(mt[kk + M] ^ (((uint)y) >> 1) ^ mag01[y & 0x1]);
                    }
                    for (; kk < N - 1; kk++) {
                        y = (mt[kk] & UPPER_MASK) | (mt[kk + 1] & LOWER_MASK);
                        mt[kk] = (int)(mt[kk + (M - N)] ^ (((uint)y) >> 1) ^ mag01[y & 0x1]);
                    }
                    y = (mt[N - 1] & UPPER_MASK) | (mt[0] & LOWER_MASK);
                    mt[N - 1] = (int)(mt[M - 1] ^ (((uint)y) >> 1) ^ mag01[y & 0x1]);

                    mti = 0;
                }

                y = mt[mti++];
                y ^= (int)((uint)y) >> 11;                          // TEMPERING_SHIFT_U(y)
                y ^= (y << 7) & TEMPERING_MASK_B;       // TEMPERING_SHIFT_S(y)
                y ^= (y << 15) & TEMPERING_MASK_C;      // TEMPERING_SHIFT_T(y)
                y ^= (int)(((uint)y) >> 18);                        // TEMPERING_SHIFT_L(y)

                return (int) ((n * (long) (((uint)y) >> 1)) >> 31);
            }

            int bits, val;
            do {
                int y;

                if (mti >= N) // generate N words at one time
                {
                    int kk;

                    for (kk = 0; kk < N - M; kk++) {
                        y = (mt[kk] & UPPER_MASK) | (mt[kk + 1] & LOWER_MASK);
                        mt[kk] = (int)(mt[kk + M] ^ (((uint)y) >> 1) ^ mag01[y & 0x1]);
                    }
                    for (; kk < N - 1; kk++) {
                        y = (mt[kk] & UPPER_MASK) | (mt[kk + 1] & LOWER_MASK);
                        mt[kk] =(int)(mt[kk + (M - N)] ^ (((uint)y) >> 1) ^ mag01[y & 0x1]);
                    }
                    y = (mt[N - 1] & UPPER_MASK) | (mt[0] & LOWER_MASK);
                    mt[N - 1] = (int)(mt[M - 1] ^ (((uint)y) >> 1) ^ mag01[y & 0x1]);

                    mti = 0;
                }

                y = mt[mti++];
                y ^= (int)((uint)y) >> 11;                          // TEMPERING_SHIFT_U(y)
                y ^= (y << 7) & TEMPERING_MASK_B;       // TEMPERING_SHIFT_S(y)
                y ^= (y << 15) & TEMPERING_MASK_C;      // TEMPERING_SHIFT_T(y)
                y ^= (int)(((uint)y) >> 18);                        // TEMPERING_SHIFT_L(y)

                bits = (int)(((uint)y) >> 1);
                val = bits % n;
            } while (bits - val + (n - 1) < 0);
            return val;
        }
    }   
}
