﻿//----------------------------------------------------------------------------------
//
// CRunPlatform: Platform Movement object
// fin 03/april/09
//greyhill
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;

namespace RuntimeXNA.Extensions
{
    class CRunPlatform : CRunExtension
    {
        const int CID_ObstacleTest = 0;
        const int CID_JumpThroughTest = 1;
        const int CID_IsOnGround = 2;
        const int CID_IsJumping = 3;
        const int CID_IsFalling = 4;
        const int CID_IsPaused = 5;
        const int CID_IsMoving = 6;
        const int AID_ColObstacle = 0;
        const int AID_ColJumpThrough = 1;
        const int AID_SetObject = 2;
        const int AID_MoveRight = 3;
        const int AID_MoveLeft = 4;
        const int AID_Jump = 5;
        const int AID_SetXVelocity = 6;
        const int AID_SetYVelocity = 7;
        const int AID_SetMaxXVelocity = 8;
        const int AID_SetMaxYVelocity = 9;
        const int AID_SetXAccel = 10;
        const int AID_SetXDecel = 11;
        const int AID_SetGravity = 12;
        const int AID_SetJumpStrength = 13;
        const int AID_SetJumpHoldHeight = 14;
        const int AID_SetStepUp = 15;
        const int AID_JumpHold = 16;
        const int AID_Pause = 17;
        const int AID_UnPause = 18;
        const int AID_SetSlopeCorrection = 19;
        const int AID_SetAddXVelocity = 20;
        const int AID_SetAddYVelocity = 21;
        const int EID_GetXVelocity = 0;
        const int EID_GetYVelocity = 1;
        const int EID_GetMaxXVelocity = 2;
        const int EID_GetMaxYVelocity = 3;
        const int EID_GetXAccel = 4;
        const int EID_GetXDecel = 5;
        const int EID_GetGravity = 6;
        const int EID_GetJumpStrength = 7;
        const int EID_GetJumpHoldHeight = 8;
        const int EID_GetStepUp = 9;
        const int EID_GetSlopeCorrection = 10;
        const int EID_GetAddXVelocity = 11;
        const int EID_GetAddYVelocity = 12;

        int ObjFixed;
//        int ObjShortCut;
        PlatformCOL Col;
        PlatformMove PFMove;

        public override int getNumberOfConditions()
        {
            return 7;
        }

        private String fixString(String input)
        {
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] < 10)
                {
                    return input.Substring(0, i);
                }
            }
            return input;
        }

        int parse(string s)
        {
            int result = 0;
            try
            {
                result = System.Convert.ToInt32(s, 2);
            }
            catch (FormatException e)
            {
                e.GetType();
            }
            catch (ArgumentOutOfRangeException e)
            {
                e.GetType();
            }
            return result;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            file.setUnicode(false);
            file.skipBytes(8);
            this.PFMove = new PlatformMove();
            this.PFMove.MaxXVelocity = parse(fixString(file.readAString(16)));
            this.PFMove.MaxYVelocity = parse(fixString(file.readAString(16)));
            this.PFMove.XAccel = parse(fixString(file.readAString(16)));
            this.PFMove.XDecel = parse(fixString(file.readAString(16)));
            this.PFMove.Gravity = parse(fixString(file.readAString(16)));
            this.PFMove.JumpStrength = parse(fixString(file.readAString(16)));
            this.PFMove.JumpHoldHeight = parse(fixString(file.readAString(16)));
            this.PFMove.StepUp = parse(fixString(file.readAString(16)));
            this.PFMove.SlopeCorrection = parse(fixString(file.readAString(16)));
            this.Col = new PlatformCOL();
            this.Col.JumpThroughColTop = file.readAByte() == 1 ? true : false;
            this.Col.EnableJumpThrough = file.readAByte() == 1 ? true : false;
            return true;
        }

        private CObject GetCObject(int Fixed)
        {
            CObject[] co = rh.rhObjectList;
            for (int i = 0; i < co.Length; i++)
            {
                if (co[i] != null)
                {
                    if ((int)((co[i].hoCreationId << 16) + co[i].hoNumber) == Fixed)
                    {
                        return co[i];
                    }
                }
            }
            return null;
        }

        private bool IsOverObstacle()
        {
            this.Col.Obstacle = false;
            ho.generateEvent(CID_ObstacleTest, ho.getEventParam());
            return this.Col.Obstacle;
        }

        private bool IsOverJumpThrough()
        {
            if (!this.Col.EnableJumpThrough)
            {
                return false;
            }
            this.Col.JumpThrough = false;
            ho.generateEvent(CID_JumpThroughTest, ho.getEventParam());
            return this.Col.JumpThrough;
        }

        public override int handleRunObject()
        {
            CObject Object = GetCObject(this.ObjFixed);
            // If Object is valid, do movement
            if (!this.PFMove.Paused && Object != null)
            {
                if (this.PFMove.RightKey && !this.PFMove.LeftKey)
                {
                    this.PFMove.XVelocity += this.PFMove.XAccel; // add to x velocity when pressing right
                }
                if (this.PFMove.LeftKey && !this.PFMove.RightKey)
                {
                    this.PFMove.XVelocity -= this.PFMove.XAccel; // sub from x velocity when pressing left
                }
                if (this.PFMove.XVelocity != 0 && ((!this.PFMove.LeftKey && !this.PFMove.RightKey) || (this.PFMove.LeftKey && this.PFMove.RightKey)))
                {
                    // slow the object down when not pressing right or left
                    this.PFMove.XVelocity -= this.PFMove.XVelocity / Math.Abs(this.PFMove.XVelocity) * this.PFMove.XDecel;
                    if (this.PFMove.XVelocity <= this.PFMove.XDecel && this.PFMove.XVelocity >= 0 - this.PFMove.XDecel)
                    {
                        this.PFMove.XVelocity = 0; // set x velocity to 0 when it's close to 0
                    }
                }
                /////////////////////////////////////////////////////////////////////////
                // MOVEMENT LOOPS
                // set velocitities to max and min
                this.PFMove.XVelocity = Math.Min(Math.Max(this.PFMove.XVelocity, 0 - this.PFMove.MaxXVelocity), this.PFMove.MaxXVelocity);
                this.PFMove.YVelocity = Math.Min(Math.Max(this.PFMove.YVelocity + this.PFMove.Gravity, 0 - this.PFMove.MaxYVelocity), this.PFMove.MaxYVelocity);
                int tmpXVelocity = this.PFMove.XVelocity + this.PFMove.AddXVelocity;
                int tmpYVelocity = this.PFMove.YVelocity + this.PFMove.AddYVelocity;
                this.PFMove.XMoveCount += Math.Abs(tmpXVelocity);
                this.PFMove.YMoveCount += Math.Abs(tmpYVelocity);

                // X MOVEMENT LOOP
                while (this.PFMove.XMoveCount > 100)
                {
                    if (!IsOverObstacle())
                    {
                        Object.hoX += tmpXVelocity / Math.Abs(tmpXVelocity);
                    }

                    if (IsOverObstacle())
                    {
                        for (int up = 0; up < this.PFMove.StepUp; up++) // Step up (slopes)
                        {
                            Object.hoY--;
                            if (!IsOverObstacle())
                            {
                                break;
                            }
                        }
                        if (IsOverObstacle())
                        {
                            Object.hoY += (short)this.PFMove.StepUp;
                            Object.hoX -= tmpXVelocity / Math.Abs(tmpXVelocity);
                            this.PFMove.XVelocity = this.PFMove.XMoveCount = 0;
                        }
                    }
                    this.PFMove.XMoveCount -= 100;
                    Object.roc.rcChanged = true;
                }

                // Y MOVEMENT LOOP
                while (this.PFMove.YMoveCount > 100)
                {
                    if (!IsOverObstacle())
                    {
                        Object.hoY += tmpYVelocity / Math.Abs(tmpYVelocity);
                        this.PFMove.OnGround = false;
                    }

                    if (IsOverObstacle())
                    {
                        Object.hoY -= tmpYVelocity / Math.Abs(tmpYVelocity);
                        if (tmpYVelocity > 0)
                        {
                            this.PFMove.OnGround = true;
                        }
                        this.PFMove.YVelocity = this.PFMove.YMoveCount = 0;
                    }

                    if (IsOverJumpThrough() && tmpYVelocity > 0)
                    {
                        if (this.Col.JumpThroughColTop)
                        {
                            Object.hoY--;
                            if (!IsOverJumpThrough())
                            {
                                Object.hoY -= tmpYVelocity / Math.Abs(tmpYVelocity);
                                this.PFMove.YVelocity = this.PFMove.YMoveCount = 0;
                                this.PFMove.OnGround = true;
                            }
                            Object.hoY++;
                        }
                        else
                        {
                            Object.hoY -= tmpYVelocity / Math.Abs(tmpYVelocity);
                            this.PFMove.YVelocity = this.PFMove.YMoveCount = 0;
                            this.PFMove.OnGround = true;
                        }
                    }
                    this.PFMove.YMoveCount -= 100;
                    Object.roc.rcChanged = true;

                }
                if (this.PFMove.SlopeCorrection > 0 && tmpYVelocity >= 0)
                {
                    bool tmp = false;
                    // Slope correction
                    for (int sc = 0; sc < this.PFMove.SlopeCorrection; sc++)
                    {
                        Object.hoY++;
                        if (IsOverObstacle())
                        {
                            Object.hoY--;
                            this.PFMove.OnGround = true;
                            tmp = true;
                            break;
                        }
                    }
                    if (tmp == false)
                    {
                        Object.hoY -= (short)this.PFMove.SlopeCorrection;
                    }
                }
            }
            // Reset values
            this.PFMove.RightKey = false;
            this.PFMove.LeftKey = false;
            return 0;
        }

        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CID_ObstacleTest:
                    return true;
                case CID_JumpThroughTest:
                    return true;
                case CID_IsOnGround:
                    return PFMove.OnGround;
                case CID_IsJumping:
                    return (!PFMove.OnGround && PFMove.YVelocity <= 0);
                case CID_IsFalling:
                    return (!PFMove.OnGround && PFMove.YVelocity > 0);
                case CID_IsPaused:
                    return PFMove.Paused;
                case CID_IsMoving:
                    return (Math.Abs(PFMove.XVelocity) > 0);
            }
            return false;
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case AID_ColObstacle:
                    Col.Obstacle = true;
                    break;
                case AID_ColJumpThrough:
                    Col.JumpThrough = true;
                    break;
                case AID_SetObject:
                    SetObject(act.getParamObject(rh, 0));
                    break;
                case AID_MoveRight:
                    PFMove.RightKey = true;
                    break;
                case AID_MoveLeft:
                    PFMove.LeftKey = true;
                    break;
                case AID_Jump:
                    PFMove.YVelocity = 0 - PFMove.JumpStrength;
                    break;
                case AID_SetXVelocity:
                    PFMove.XVelocity = act.getParamExpression(rh, 0);
                    break;
                case AID_SetYVelocity:
                    PFMove.YVelocity = act.getParamExpression(rh, 0);
                    break;
                case AID_SetMaxXVelocity:
                    PFMove.MaxXVelocity = act.getParamExpression(rh, 0);
                    break;
                case AID_SetMaxYVelocity:
                    PFMove.MaxYVelocity = act.getParamExpression(rh, 0);
                    break;
                case AID_SetXAccel:
                    PFMove.XAccel = act.getParamExpression(rh, 0);
                    break;
                case AID_SetXDecel:
                    PFMove.XDecel = act.getParamExpression(rh, 0);
                    break;
                case AID_SetGravity:
                    PFMove.Gravity = act.getParamExpression(rh, 0);
                    break;
                case AID_SetJumpStrength:
                    PFMove.JumpStrength = act.getParamExpression(rh, 0);
                    break;
                case AID_SetJumpHoldHeight:
                    PFMove.JumpHoldHeight = act.getParamExpression(rh, 0);
                    break;
                case AID_SetStepUp:
                    PFMove.StepUp = act.getParamExpression(rh, 0);
                    break;
                case AID_JumpHold:
                    PFMove.YVelocity -= PFMove.JumpHoldHeight;
                    break;
                case AID_Pause:
                    PFMove.Paused = true;
                    break;
                case AID_UnPause:
                    PFMove.Paused = false;
                    break;
                case AID_SetSlopeCorrection:
                    PFMove.SlopeCorrection = act.getParamExpression(rh, 0);
                    break;
                case AID_SetAddXVelocity:
                    PFMove.AddXVelocity = act.getParamExpression(rh, 0);
                    break;
                case AID_SetAddYVelocity:
                    PFMove.AddYVelocity = act.getParamExpression(rh, 0);
                    break;
            }
        }

        private void SetObject(CObject pObject)
        {
            ObjFixed = (int)((pObject.hoCreationId << 16) + pObject.hoNumber);
        }

        public override CValue expression(int num)
        {
            switch (num)
            {
                case EID_GetXVelocity:
                    return new CValue(PFMove.XVelocity);
                case EID_GetYVelocity:
                    return new CValue(PFMove.YVelocity);
                case EID_GetMaxXVelocity:
                    return new CValue(PFMove.MaxXVelocity);
                case EID_GetMaxYVelocity:
                    return new CValue(PFMove.MaxYVelocity);
                case EID_GetXAccel:
                    return new CValue(PFMove.XAccel);
                case EID_GetXDecel:
                    return new CValue(PFMove.XDecel);
                case EID_GetGravity:
                    return new CValue(PFMove.Gravity);
                case EID_GetJumpStrength:
                    return new CValue(PFMove.JumpStrength);
                case EID_GetJumpHoldHeight:
                    return new CValue(PFMove.JumpHoldHeight);
                case EID_GetStepUp:
                    return new CValue(PFMove.StepUp);
                case EID_GetSlopeCorrection:
                    return new CValue(PFMove.SlopeCorrection);
                case EID_GetAddXVelocity:
                    return new CValue(PFMove.AddXVelocity);
                case EID_GetAddYVelocity:
                    return new CValue(PFMove.AddYVelocity);
            }
            return new CValue(0);//won't be used
        }



    }

    class PlatformCOL
    {
        public bool Obstacle, JumpThrough, JumpThroughColTop, EnableJumpThrough;
    }
    class PlatformMove
    {
        public int XVelocity, YVelocity;
        public int MaxXVelocity, MaxYVelocity;
        public int AddXVelocity, AddYVelocity;
        public int XMoveCount, YMoveCount;
        public int XAccel, XDecel;
        public int Gravity;
        public int JumpStrength;
        public int JumpHoldHeight;
        public int StepUp;
        public int SlopeCorrection;
        public bool OnGround, RightKey, LeftKey, Paused;
    }

}
