﻿//----------------------------------------------------------------------------------
//
// CRunStringTokenizer
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;

namespace RuntimeXNA.Extensions
{
    class CRunStringTokenizer : CRunExtension
    {
//    	private bool Initialised;
    	private CArrayList Tokens;
    	private CArrayList Tokens2D;
    	
    	const int CND_LAST = 0;
    	const int ACT0_SPLITSTRING0WITHDELIMITERS11D= 0;
    	const int ACT1_SPLITSTRING0WITHDELIMITERS1AND22D= 1;
    	const int EXP0_ELEMENTCOUNT= 0;
    	const int EXP1_ELEMENT= 1;
    	const int EXP2_ELEMENT2D= 2;
    	const int EXP3_ELEMENTCOUNTX= 3;
    	const int EXP4_ELEMENTCOUNTY= 4;

	    public override int getNumberOfConditions()
	    {
	        return CND_LAST;
	    }

	    public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
	    {
	    	Tokens=new CArrayList();
	    	Tokens2D=new CArrayList();
	    	return false;
	    }

	    // Actions
	    // -------------------------------------------------
	    public override void action(int num, CActExtension act)
	    {
	        switch (num)
	        {
		       case 0: // '\0'
        		    act0_Splitstring0withdelimiters11D(act);
            		break;

        		case 1: // '\001'
            		act1_Splitstring0withdelimiters1and22D(act);
            		break;
 	        }
	    }

		private void act0_Splitstring0withdelimiters11D(CActExtension act)
	    {
	        String param0= act.getParamExpString(rh, 0);
	        String param1= act.getParamExpString(rh, 1);
	        Tokens.clear();
	        CRunStringTokeniser Tokenizer= new CRunStringTokeniser(param0, param1);
	        int TokenCount= Tokenizer.countTokens();
	        int i;
	        for(i = 0; i < TokenCount; i++)
	        {
	            Tokens.add(Tokenizer.nextToken());
	        }
	    }
	
	    private void act1_Splitstring0withdelimiters1and22D(CActExtension act)
	    {
	        String param0= act.getParamExpString(rh, 0);
	        String param1= act.getParamExpString(rh, 1);
	        String param2= act.getParamExpString(rh, 2);
	        Tokens2D.clear();
	        CRunStringTokeniser XTokenizer= new CRunStringTokeniser(param0, param1);
	        int XTokenCount= XTokenizer.countTokens();
	        int x;
	        for(x = 0; x < XTokenCount; x++)
	        {
	            CArrayList New= new CArrayList();
	            CRunStringTokeniser YTokenizer= new CRunStringTokeniser(XTokenizer.nextToken(), param2);
	            int YTokenCount= YTokenizer.countTokens();
	            int y;
	            for(y = 0; y < YTokenCount; y++)
	            {
	                New.add(YTokenizer.nextToken());
	            }	
	            Tokens2D.add(New);
	        }	
	    }

	  	public override CValue expression(int num)
	    {
	        switch(num)
	        {
	        case 0: // '\0'
	            return exp0_ElementCount();
	
	        case 1: // '\001'
	            return exp1_Element();
	
	        case 2: // '\002'
	            return exp2_Element2D();
	
	        case 3: // '\003'
	            return exp3_ElementCountX();
	
	        case 4: // '\004'
	            return exp4_ElementCountY();
	        }
	        return null;
	    }
	
	    private CValue exp0_ElementCount()
	    {
	        return new CValue(Tokens.size());
	    }
	
	    private CValue exp1_Element()
	    {
	        int param0= ho.getExpParam().getInt();
	        CValue ret=new CValue(0);
	        String s=(String)(Tokens.get(param0));
	        if (s==null)
	        {
	        	s="";
	        }	        
	        ret.forceString(s);
	        return ret;
	    }
	
	    private CValue exp2_Element2D()
	    {
	        int param0= ho.getExpParam().getInt();
	        int param1= ho.getExpParam().getInt();
	        CValue ret=new CValue(0);
	        string s=(String)((CArrayList)(Tokens2D.get(param0))).get(param1);
	        if (s==null)
	        {
	        	s="";
	        }	        
	        ret.forceString(s);
	        return ret;
	    }
	
	    private CValue exp3_ElementCountX()
	    {
	        return new CValue(Tokens2D.size());
	    }
	
	    private CValue exp4_ElementCountY()
	    {
	        int param0 = ho.getExpParam().getInt();
	        return new CValue(((CArrayList)(Tokens2D.get(param0))).size());
	    }	    

    }

    class CRunStringTokeniser
    {
	    public CArrayList tokens;
   	 	public int numToken;

	    public CRunStringTokeniser(string text, string delimiter)
	    {
	        tokens=new CArrayList();
	
	        int oldPos=0;
	        int pos=text.IndexOf(delimiter);
	        while(pos>=0)
	        {
	            if (pos>oldPos)
	            {
	                tokens.add(text.Substring(oldPos, pos-oldPos));
	            }
	            oldPos=pos+delimiter.Length;
                if (oldPos>=text.Length)
                {
                    break;
                }
	            pos=text.IndexOf(delimiter, oldPos);
	        }
	        if (text.Length>oldPos)
	        {
	        	tokens.add(text.Substring(oldPos, text.Length-oldPos));
	        }
	        numToken=0;
	    }
	    public int countTokens()
	    {
	        return tokens.size();
	    }
	    public string nextToken()
	    {
	        if (numToken<tokens.size())
	        {
	        	string s=(String)(tokens.get(numToken++));
	        	if (s==null)
	        	{
	        		return "";
	        	}
	            return s;
	        }
	        return "";
	    }
    }
}
