﻿//----------------------------------------------------------------------------------
//
// CRUNKCCOMBO
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.GamerServices;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;
using RuntimeXNA.Application;

namespace RuntimeXNA.Extensions
{
    class CRunkccombo : CRunExtension, IControl
    {
	    const int COMBO_SIMPLE=0x0001;
	    const int COMBO_DROPDOWN=0x0002;
	    const int COMBO_DROPDOWNLIST=0x0004;
	    const int COMBO_SCROLLBAR=0x0008;
	    const int COMBO_SORT=0x0010;
	    const int COMBO_HIDEONSTART=0x0020;
	    const int COMBO_SYSCOLOR=0x0040;
	    const int COMBO_SCROLLTONEWLINE=0x0080;
	    const int COMBO_ONEBASE=0x0100;
	    const int COMBO_JUSTCREATED=0x8000;
	
	    public CFontInfo fontInfo;
    	public int crefListFontColor;
    	public int flags;
    	public int crefListFontBkColor;
    	public CCombo combo;
    	public int oldWidth;
    	public int oldHeight;
		public int selectionChangedEvent;
		public int doubleClickedEvent;
		public int indexOffset;
		public int lastIndex;

	    public override int getNumberOfConditions()
    	{
			return 6;
    	}
	    public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
	    {
	        ho.hoImgWidth=file.readAShort();
	        ho.hoImgHeight=file.readAShort();
	        oldWidth=ho.hoImgWidth;
	        oldHeight=ho.hoImgHeight;
	        if (ho.hoAdRunHeader.rhApp.bUnicode==false)
	        {
	            fontInfo = file.readLogFont16();
	        }
	        else
	        {
	            fontInfo = file.readLogFont();
	        }
	        crefListFontColor=file.readAColor();
	        file.readAString(40);
	        flags=file.readAInt();
	        int lineNumbers=file.readAShort();
	        crefListFontBkColor=file.readAColor();
	        file.skipBytes(12);
	        indexOffset=0;
	        if ((flags&COMBO_ONEBASE)!=0)
	        {
	            indexOffset=-1;
	        }
	        lastIndex=-1;

			// Creates the list
			int newFlags=0;
			if ((flags&COMBO_SCROLLBAR)!=0)
			{
				newFlags|=CCombo.COMBOFLAG_SCROLLBAR;
			}
			if ((flags&COMBO_HIDEONSTART)!=0)
			{
				newFlags|=CCombo.COMBOFLAG_HIDDEN;
			}
			if ((flags&COMBO_SORT)!=0)
			{
				newFlags|=CCombo.COMBOFLAG_SORT;
			}
			if ((flags&COMBO_SCROLLTONEWLINE)!=0)
			{
				newFlags|=CCombo.COMBOFLAG_SCROLLTONEWLINE;
			}
            int type;
            type=CCombo.COMBOTYPE_SIMPLE;
            if ((flags&COMBO_DROPDOWN)!=0)
            {
            	type=CCombo.COMBOTYPE_DROPDOWN;
            }
            if ((flags&COMBO_DROPDOWNLIST)!=0)
            {
            	type=CCombo.COMBOTYPE_DROPDOWNLIST;
            }
			combo=new CCombo(ho.hoAdRunHeader,ho.hoX-ho.hoAdRunHeader.rhWindowX, ho.hoY-ho.hoAdRunHeader.rhWindowY, 
							  	ho.hoImgWidth, ho.hoImgHeight,
							  	fontInfo, crefListFontColor, crefListFontBkColor, newFlags, type);
							  	
			// Insert the strings			
	        while (lineNumbers > 0)
	        {
	            string line = file.readAString();
	            combo.addString(line, lineNumbers==1);
	            lineNumbers--;
	        }
	        
	        selectionChangedEvent=-1;
	        doubleClickedEvent=-1;

            ho.hoAdRunHeader.addControl(this);

	        return false;
	    }

        public override void destroyRunObject(bool bFast)
        {
            ho.hoAdRunHeader.delControl(this);
        }

		public override int handleRunObject()
		{
			combo.handle(ho.hoAdRunHeader.rh2MouseX-ho.hoX, ho.hoAdRunHeader.rh2MouseY-ho.hoY);			
	
			if (combo.bSelChanged)
			{
				combo.bSelChanged=false;
	            selectionChangedEvent = ho.getEventCount();
	            ho.pushEvent(3, 0);             // CND_SELECTIONCHANGED
			}
			if (combo.bDoubleClick)
			{
				combo.bDoubleClick=false;
            	doubleClickedEvent = ho.getEventCount();
            	ho.pushEvent(2, 0);             // CND_DOUBLECLICKED
   			}
			return 0;	
		}

		public void displayRunObject()
		{
			combo.setPosition(ho.hoX-ho.hoAdRunHeader.rhWindowX, ho.hoY-ho.hoAdRunHeader.rhWindowY);
			bool bDisplay=false;
			if (ho.hoImgWidth!=oldWidth)
			{
				combo.width=ho.hoImgWidth;
				oldWidth=ho.hoImgWidth;
				bDisplay=true;
			}
			if (ho.hoImgHeight!=oldHeight)
			{
				combo.height=ho.hoImgHeight;
				oldHeight=ho.hoImgHeight;
				bDisplay=true;		
			}
			if (bDisplay)
			{
				combo.createString();
			}
		}

        public void drawControl(SpriteBatch batch)
        {
            combo.drawControl(batch);
        }

        public void click(int nClicks)
        {
#if WINDOWS_PHONE
            handleRunObject();
#endif
            combo.click(nClicks);
        }
        public int getX()
        {
            return ho.hoX;
        }
        public int getY()
        {
            return ho.hoY;
        }
        public void setMouseControlled(bool bFlag)
        {
            combo.setMouseControlled(bFlag);
        }
        public void setFocus(bool bFlag)
        {
            combo.setFocus(bFlag);
        }

	    // Conditions
	    // --------------------------------------------------
	    public override bool condition(int num, CCndExtension cnd)
	    {
	        switch (num)
	        {
	            case 0:
	                return cndVisible(cnd);
	            case 1:
	                return cndEnable(cnd);
	            case 2:
	                return cndDoubleClicked(cnd);
	            case 3:
	                return cndSelectionChanged(cnd);
	            case 4:
	                return cndHaveFocus(cnd);
	            case 5:
	                return cndIsDropped(cnd);
	        }
			return false;
	    }
	    public bool cndVisible(CCndExtension cnd)
	    {
	        return combo.bVisible;
	    }
	    public bool cndEnable(CCndExtension cnd)
	    {
	        return combo.bEnabled;
	    }
	    public bool cndDoubleClicked(CCndExtension cnd)
	    {
	        // This is a true event, so was pushed
	        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
	        {
	            return true;
	        }
	        // Event occured this event loop
	        if (doubleClickedEvent == ho.getEventCount())
	        {
	            return true;
	        }
	        return false;
	    }
	    public bool cndSelectionChanged(CCndExtension cnd)
	    {
	        // This is a true event, so was pushed
	        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
	        {
	            return true;
	        }
	        // Event occured this event loop
	        if (selectionChangedEvent == ho.getEventCount())
	        {
	            return true;
	        }
	        return false;
	    }
	    public bool cndHaveFocus(CCndExtension cnd)
	    {
	        return combo.bFocus;
	    }
	    public bool cndIsDropped(CCndExtension cnd)
	    {
	        return false;
	    }

	    // Actions
	    // -------------------------------------------------
	    public override void action(int num, CActExtension act)
	    {
	        switch (num)
	        {
	            case 0:
	                break;
	            case 1:
	                break;
	            case 2:
	                break;
	            case 3:
	                break;
	            case 4:
	                break;
	            case 5:
	                actReset(act);
	                break;
	            case 6:
	                actAddLine(act);
	                break;
	            case 7:
	                actInsertLine(act);
	                break;
	            case 8:
	                actDelLine(act);
	                break;
	            case 9: 
	                actSetCurrentLine(act);
	                break;
	            case 10:
	                actShow(act);
	                break;
	            case 11:
	                actHide(act);
	                break;
	            case 12:
	                actActivate(act);
	                break;
	            case 13:
	                actEnable(act);
	                break;
	            case 14:
	                actDisable(act);
	                break;
	            case 15:
	                actSetPosition(act);
	                break;
	            case 16:
	                actSetXPosition(act);
	                break;
	            case 17: 
	                actSetYPosition(act);
	                break;
	            case 18:
	                actSetSize(act);
	                break;
	            case 19:
	                actSetXSize(act);
	                break;
	            case 20:
	                actSetYSize(act);
	                break;
	            case 21:
	                actDesactivate(act);
	                break;
	            case 22:
	                actSetEditText(act);
	                break;
	            case 23:
	                actScrollToTop(act);
	                break;
	            case 24:
	                actScrollToLine(act);
	                break;
	            case 25:
	                actScrollToEnd(act);
	                break;
	            case 26:
	                actSetColor(act);
	                break;
	            case 27:
	                actSetBkdColor(act);
	                break;
	            case 28:
	                break;
	            case 29:
	                break;
	            case 30:
	                break;
			    case 31:	
					actChangeLine(act);
					break;
	        }
	    }
	    public void actReset(CActExtension act)
	    {
	    	combo.reset();
	    }
	    public void actAddLine(CActExtension act)
	    {
	        lastIndex = combo.getSize();
	        combo.addString(act.getParamExpString(rh, 0), true);
	    }
	    public void actInsertLine(CActExtension act)
	    {
	        int index= act.getParamExpression(rh, 0) + indexOffset;
	        if (index < 0)
	        {
	            // append to end
	            index = combo.getSize();
	        }
	        if (index > combo.getSize())
	        {
	            index = combo.getSize();
	        }
	        lastIndex = index;
	        combo.insertString(index, act.getParamExpString(rh, 1));
	    }
	    public void actDelLine(CActExtension act)
	    {
	        int index= act.getParamExpression(rh, 0) + indexOffset;
	        // Must be an existing element
	        if (index < 0)
	            return;
	        if (index >= combo.getSize())
	            return;
	        combo.delString(index);
	    }
	    public void actSetCurrentLine(CActExtension act)
	    {
	        int index= act.getParamExpression(rh, 0) + indexOffset;
	        if ((index >= 0) && (index < combo.getSize()))
	        {
	            combo.setSelected(index);
	        }
	    }
	    public void actShow(CActExtension act)
	    {
	        combo.setVisible(true);
	    }
	    public void actHide(CActExtension act)
	    {
	        combo.setVisible(false);
	    }
	    public void actActivate(CActExtension act)
	    {
	        combo.setFocus(true);
	    }
	    public void actEnable(CActExtension act)
	    {
	        combo.setEnabled(true);
	    }
	    public void actDisable(CActExtension act)
	    {
	        combo.setEnabled(false);
	    }
	    public void actSetPosition(CActExtension act)
	    {
	        ho.setPosition(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
	    }
	    public void actSetXPosition(CActExtension act)
	    {
	        ho.setPosition(act.getParamExpression(rh, 0), ho.getY());
	    }
	    public void actSetYPosition(CActExtension act)
	    {
	        ho.setPosition(act.getParamExpression(rh, 0), ho.getY());
	    }
	    public void actSetSize(CActExtension act)
	    {
	        int width=act.getParamExpression(rh, 0);
	        int height=act.getParamExpression(rh, 1);
	        if (width>=0 && height>=0)
	        {
	            ho.setWidth(width);
	            ho.setHeight(height);
	            ho.redraw();
	        }
	    }
	    public void actSetXSize(CActExtension act)
	    {
	        int width=act.getParamExpression(rh, 0);
	        if (width>=0)
	        {
	            ho.setWidth(width);
	            ho.redraw();
	        }
	    }
	    public void actSetYSize(CActExtension act)
	    {
	        int height=act.getParamExpression(rh, 1);
	        if (height>=0)
	        {
	            ho.setHeight(height);
	            ho.redraw();
	        }
	   	}
	    public void actDesactivate(CActExtension act)
	    {
	    	combo.setFocus(false);
	    }
	    public void actSetEditText(CActExtension act)
	    {
	        string s=act.getParamExpString(rh, 0);
	        combo.setCurrentText(s);
	    }
	    public void actScrollToTop(CActExtension act)
	    {
	    	combo.ensureLineIsVisible(0);
	    }
	    public void actScrollToLine(CActExtension act)
	    {
	        int line=act.getParamExpression(rh, 0)+indexOffset;
	        if (line>=0 && line<combo.getSize())
	        {
	            lastIndex=line;
		    	combo.ensureLineIsVisible(line);
	        }
	    }
	    public void actScrollToEnd(CActExtension act)
	    {
	        if (combo.getSize()>0)
	        {
	            lastIndex=combo.getSize()-1;
		    	combo.ensureLineIsVisible(lastIndex);
	        }
	    }
	    public void actSetColor(CActExtension act)
	    {
	        crefListFontColor=act.getParamColour(rh, 0);
	        combo.setForeground(crefListFontColor);
	    }
	    public void actSetBkdColor(CActExtension act)
	    {
	        crefListFontBkColor=act.getParamColour(rh, 0);
	        combo.setBackground(crefListFontBkColor);
	    }
	    public void actSetLineData(CActExtension act)
	    {
	        int index= act.getParamExpression(rh, 0) + indexOffset;
	        // Must be an existing element
	        if (index < 0)
	            return;
	        if (index >= combo.getSize())
	            return;
	        combo.setData(index, act.getParamExpression(rh, 1));       
	    }
	    public void actChangeLine(CActExtension act)
	    {
	        int index= act.getParamExpression(rh, 0) + indexOffset;
	        // Must be an existing element
	        if (index < 0)
	            return;
	        if (index >= combo.getSize())
	            return;
	        combo.setString(index, act.getParamExpString(rh, 1));       
	    }		
	    
	    // Expressions
	    // --------------------------------------------
	    public override CValue expression(int num)
	    {
	        switch (num)
	        {
	            case 0:
	                return expGetSelectIndex();
	            case 1:
	                return expGetSelectText();
	            case 2:
	                return new CValue("");
	            case 3:
	                return new CValue("");
	            case 4:
	                return expGetLineText();
	            case 5:
	                return new CValue("");
	            case 6:
	                return new CValue("");
	            case 7:
	                return exGetNbLine();
	            case 8:
	                return exGetXPosition();
	            case 9:
	                return expGetYPosition();
	            case 10:
	                return expGetXSize();
	            case 11:
	                return expGetYSize();
	            case 12:
	                return expGetEditText();
	            case 13:
	                return expGetColor();
	            case 14:
	                return expGetBkdColor();
	            case 15:
	                return expFindString();
	            case 16:
	                return expFinStringExact();
	            case 17:
	                return expGetLastIndex();
	            case 18:
	                return expGetLineData();
	        }
			return null;
	    }
	
	    public CValue expGetSelectIndex()
	    {
	        int index=combo.getSelectedIndex();
	        if (index>=0)
	        {
	            return new CValue(index-indexOffset);
	        }
	        return new CValue(-1);
	    }
	    public CValue getText(int index)
	    {	    	
	    	var ret=new CValue("");
	        if ((index >= 0) && (index < combo.getSize()))
	        {
	        	ret.forceString(combo.getString(index));
	        }
	        return ret;
	    }	  
	    public CValue expGetSelectText()
	    {
	        return getText(combo.getSelectedIndex());
	    }
	    public CValue expGetLineText()
	    {
	        return getText(ho.getExpParam().getInt() + indexOffset);
	    }
	    public CValue exGetNbLine()
	    {
	        return new CValue(combo.getSize());
	    }
	    public CValue exGetXPosition()
	    {
	        return new CValue(ho.getX());
	    }
	    public CValue expGetYPosition()
	    {
	        return new CValue(ho.getY());
	    }
	    public CValue expGetXSize()
	    {
	        return new CValue(ho.getWidth());
	    }
	    public CValue expGetYSize()
	    {
	        return new CValue(ho.getHeight());
	    }
	    public CValue expGetEditText()
	    {
	    	var ret=new CValue(0);
	    	ret.forceString(combo.currentText);
	    	return ret;
	    }
	    public CValue expGetColor()
	    {
	        return new CValue(crefListFontColor);
	    }
	    public CValue expGetBkdColor()
	    {
	        return new CValue(crefListFontBkColor);
	    }
	    public CValue expFindString()
	    {
	        string search= ho.getExpParam().getString();
	        int startIndex= ho.getExpParam().getInt();
	        if (startIndex != -1)
	        {
	            startIndex += indexOffset;
	        }
	        if ((startIndex < 0) || (startIndex >= combo.getSize()))
	        {
	            startIndex = -1;
	        }
	        int ret=combo.findString(search, startIndex);
	        if (ret>=0)
	        {
	        	ret-=indexOffset;
	        }
	        return new CValue(ret);	    
	    }
	    public CValue expFinStringExact()
	    {
	        string search= ho.getExpParam().getString();
	        int startIndex= ho.getExpParam().getInt();
	        if (startIndex != -1)
	        {
	            startIndex += indexOffset;
	        }
	        if ((startIndex < 0) || (startIndex >= combo.getSize()))
	        {
	            startIndex = -1;
	        }
	        int ret=combo.findStringExact(search, startIndex);
	        if (ret>=0)
	        {
	        	ret-=indexOffset;
	        }
	        return new CValue(ret);	    
	    }
	    public CValue expGetLastIndex()
	    {
	        return new CValue(lastIndex);
	    }
	    public CValue expGetLineData()
	    {
	        int index= ho.getExpParam().getInt() + indexOffset;
	        if ((index < 0) || (index >= combo.getSize()))
	            return new CValue(0);
	        return new CValue(combo.getData(index));
	    }


    }

    class CCombo : IControl
    {
		public const int COMBOFLAG_SCROLLBAR=0x0001;
		public const int COMBOFLAG_SORT=0x0002;
		public const int COMBOFLAG_HIDDEN=0x0010;
		public const int COMBOFLAG_SCROLLTONEWLINE=0x0020;
		public const int COMBOTYPE_SIMPLE=0x0000;
		public const int COMBOTYPE_DROPDOWNLIST=0x0001;
		public const int COMBOTYPE_DROPDOWN=0x0002;
		const int SX_BUTTON=22;
		const int SX_ARROW=8;
		const int SY_ARROW=6;
		const int SX_BARBORDER=4;
		const int SY_BARBORDER=4;
		const int ZONE_TEXTFIELD=1;
		const int ZONE_BUTTON=2;
		const int ZONE_LIST=3;

		public int width;
		public int height;
		public int xObject;
		public int yObject;
		public int backColor;
		public int fontColor;
		public int flags;
		public bool bVisible;
		public CFontInfo font;
		public Boolean bHilighted;
		public int syBar;
		public int syText;
        public int sxText;
		public CComboList list;
		public int xList;
		public int yList;
		public int type;
		public int currentZone;
		public int xMouse;
		public int yMouse;
		public string currentText;
		public string currentTextCut;
		public bool bSelChanged;
		public bool bClick;
		public bool bDoubleClick;
		public int oldKey;
		public bool bFocus;
		public bool bEnabled;
        public CRun rhPtr;
        public bool bMouseControlled;
        public Texture2D bar;
        public Texture2D arrow;
        public Rectangle tempRect=new Rectangle();
        public SpriteFont spriteFont;
        public Vector2 vector=new Vector2();

		public CCombo(CRun rh, int xx, int yy, int w, int h, CFontInfo ft, int ftColor, int bkColor, int fl, int t)
		{
            rhPtr=rh;
			xObject=xx;
			yObject=yy;
			width=w;
			height=h;
			backColor=bkColor;
			fontColor=ftColor;
			font=ft;
			flags=fl;
			type=t;
			
			bVisible=true;
			if ((flags&COMBOFLAG_HIDDEN)!=0)
			{
				bVisible=false;
			}
			bEnabled=true;
			
			currentText="";
            currentTextCut="";

            CFont fnt = CFont.createFromFontInfo(font, rhPtr.rhApp);
            spriteFont = fnt.getFont();
            syText = spriteFont.LineSpacing;
            syBar = syText + SY_BARBORDER * 2 + 4;
            sxText = width - 2;
            if (type != COMBOTYPE_SIMPLE)
            {
                sxText -= SX_BUTTON;
            }

            int sy = height - syBar;
			if (sy<30)
			{
				sy=30;
			}
			xList=0;
			yList=syBar;
			int f=flags;
			f|=CComboList.LISTFLAG_BORDER;
			if (type!=COMBOTYPE_SIMPLE)
			{
				f|=CComboList.LISTFLAG_HIDDEN;				
			}
			list=new CComboList(rhPtr, xObject+xList, yObject+yList, width-1, sy, font, fontColor, backColor, f);

			currentZone=-1;
			bHilighted=false;
			oldKey=0;
			bFocus=false;

            createDisplay();
        }

        public int getX()
        {
            return xObject;
        }
        public int getY()
        {
            return yObject;
        }
        public void setMouseControlled(bool bFlag)
        {
            bMouseControlled=bFlag;
            list.setMouseControlled(bFlag);
        }
        public void setFocus(bool bFlag)
		{
            bFocus=bFlag;
			list.setFocus(bFlag);
            if (bFlag == false)
            {
                list.setVisible(false);
            }
            createDisplay();
		}

        public void createDisplay()
        {
			int color;			
			color=0x8D8F92;
			if (bHilighted || bFocus)
			{
				color=0x64CFFF;
			}
	    	int color1=0xDEE5E8;
            int color2=0xA8B5BC;
	    	if (bHilighted || bFocus)
	    	{
	    		color1=0xE9EEEF;
	    		color2=0xCBD3D7;
	    	}
            bar=CServices.createGradientRectangle(rhPtr.rhApp, width-1, syBar-1, color1, color2, true, 1, color);
            if (type!=COMBOTYPE_SIMPLE)
            {
			    color=0x808080;
                if (currentZone==ZONE_BUTTON)
                {
                    color = 0x404040;
                }
                if (bEnabled == false)
			    {
				    color=0xC0C0C0;
			    }		
                arrow=CServices.createDownArrow(rhPtr.rhApp, SX_ARROW, SY_ARROW, color);
            }
        }

        public void drawControl(SpriteBatch batch)
        {
            if (bVisible==false)
            {
                return;
            }

            tempRect.X = xObject;
            tempRect.Y = yObject;
            tempRect.Width = bar.Width;
            tempRect.Height = bar.Height;
            batch.Draw(bar, tempRect, Color.White);

            int color;
			if (type!=COMBOTYPE_SIMPLE)
			{
				color=0x8D8F92;
				if (bHilighted)
				{
					color=0x606060;
				}
                rhPtr.rhApp.services.drawRect(batch, xObject+width-SX_BUTTON, yObject, SX_BUTTON-1, syBar-1, color);

                tempRect.X = xObject+width-SX_BUTTON/2-SX_ARROW/2;
                tempRect.Y = yObject+syBar/2-SY_ARROW/2;
                tempRect.Width = arrow.Width;
                tempRect.Height = arrow.Height;
                batch.Draw(arrow, tempRect, Color.White);	
			}
            vector.X=xObject+SX_BARBORDER;
            vector.Y=yObject+SY_BARBORDER;
            color=fontColor;
            if (bEnabled == false)
            {
                color = 0xC0C0C0;
            }
            Color cc = CServices.getColor(color);
            batch.DrawString(spriteFont, currentTextCut, vector, cc);

            list.drawControl(batch);
        }

        public void createString()
        {
            String s = currentText;
            currentTextCut = s;

            Vector2 size = spriteFont.MeasureString(s);
            int pos = s.Length;
            while (size.X >= sxText)
            {
                if (pos == 0)
                {
                    currentTextCut = "";
                    break;
                }
                pos = Math.Max(0, pos - 10);
                string testString = s.Substring(0, pos);
                size = spriteFont.MeasureString(testString);
                if (size.X < sxText)
                {
                    int nn;
                    int oldNN = 0;
                    for (nn = 0; nn < 10; nn++)
                    {
                        testString = s.Substring(0, pos + nn);
                        size = spriteFont.MeasureString(testString);
                        if (size.X >= sxText)
                        {
                            break;
                        }
                        oldNN = nn;
                    }
                    currentTextCut = s.Substring(0, pos + oldNN);
                    break;
                }
            };
        }

		public void handle(int xm, int ym)
		{
			xMouse=xm;
			yMouse=ym;

			if (bVisible==true && bEnabled==true)
			{
				// Gestion de la liste
				list.handle(xMouse-xList, yMouse-yList);
				
				// Trouve la zone courante
                if (bMouseControlled)
                {
                    int oldZone = currentZone;
                    currentZone = getZone(xMouse, yMouse);
                    bool bHi = false;
                    if (currentZone >= 0)
                    {
                        bHi = true;
                    }
                    if (bHi != bHilighted || currentZone != oldZone)
                    {
                        bHilighted = bHi;
                        createDisplay();
                    }
                }
				else
                {
				    // Appui sur return?
                    if (bFocus == true)
                    {
                        int key = 0;
                        if (bMouseControlled == false)
                        {
                            if ((rhPtr.rhPlayer[0] & 0x01) != 0)		// UP
                            {
                                key = 2;
                            }
                            if ((rhPtr.rhPlayer[0] & 0x02) != 0)		// DOWN
                            {
                                key = 3;
                            }
                            if ((rhPtr.rhPlayer[0] & 0x10) != 0)		// RETURN
                            {
                                key = 1;
                            }
                        }
                        if (key != oldKey)
                        {
                            oldKey = key;
                            switch (key)
                            {
                                case 1:
                                    if (type == COMBOTYPE_DROPDOWN || type == COMBOTYPE_SIMPLE)
                                    {
                                        if (list.bVisible == false)
                                        {
                                            if (Guide.IsVisible == false)
                                            {
                                                rhPtr.pause();
                                                Guide.BeginShowKeyboardInput(PlayerIndex.One, rhPtr.rhApp.appName, "", currentText, endKeyboard, (object)"ComboInput");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        list.setVisible(false);
                                    }
                                    break;
                                case 3:
                                    if (list.bVisible == false)
                                    {
                                        list.setVisible(true);
                                        list.oldKey = 2;
                                    }
                                    break;
                            }
                        }
                    }
				}
				
				// Changement de texte
				if (list.bSelChanged)
				{
					list.bSelChanged=false;
					if (list.ySelected>=0)
					{
						currentText=(string)list.strings.get(list.ySelected);
						createString();
						bSelChanged=true;
					}
				}
				if (list.bClick)
				{
					list.bClick=false;
					bClick=true;
					if (type==COMBOTYPE_DROPDOWN || type==COMBOTYPE_DROPDOWNLIST)
					{
						list.setVisible(false);
					}
				}
				if (list.bDoubleClick)
				{
					list.bDoubleClick=false;
					bDoubleClick=true;
				}
			}
		}

		public int getZone(int xm, int ym)
		{
			if (xMouse>=0 && xMouse<width)
			{
				if (yMouse>=0 && yMouse<syBar)
				{
					if (xMouse>width-SX_BUTTON)
					{
						return ZONE_BUTTON;
					}	
					return ZONE_TEXTFIELD;
				}
			}	
			if (list.bVisible)
			{
				if (xMouse>=xList && xMouse<xList+list.width)
				{
					if (yMouse>=yList && yMouse<yList+list.height)
					{
						return ZONE_LIST;
					}
				}
			}
			return -1;
		}

		public void click(int nClicks)
		{
			list.click(nClicks);
//			if (currentZone>=0)
            {
			    if (bVisible==true && bEnabled==true)
			    {
				    switch(type)
				    {
					    case COMBOTYPE_SIMPLE:
						    if (currentZone==ZONE_TEXTFIELD)
						    {
                                if (Guide.IsVisible == false)
                                {
                                    rhPtr.pause();
                                    Guide.BeginShowKeyboardInput(PlayerIndex.One, rhPtr.rhApp.appName, "", currentText, endKeyboard, (object)"ComboInput");
                                }
                            }
		            	    break;
		                case COMBOTYPE_DROPDOWN:
						    if (currentZone==ZONE_TEXTFIELD)
						    {
                                if (Guide.IsVisible == false)
                                {
                                    rhPtr.pause();
                                    Guide.BeginShowKeyboardInput(PlayerIndex.One, rhPtr.rhApp.appName, "", currentText, endKeyboard, (object)"ComboInput");
                                }
			   			    }	
			   			    else if (currentZone==ZONE_BUTTON)
			   			    {
			            	    if (list.bVisible)
			            	    {
			            		    list.setVisible(false);
			            	    }
			            	    else
			            	    {
			            		    list.setVisible(true);
			            	    }
			      		    }
			      		    else if (currentZone<0)
			      		    {
		            		    list.setVisible(false);
			      		    }		      		
		            	    break;
		                case COMBOTYPE_DROPDOWNLIST:
		            	    if (currentZone==ZONE_TEXTFIELD || currentZone==ZONE_BUTTON)
		            	    {
			            	    if (list.bVisible)
			            	    {
			            		    list.setVisible(false);
			            	    }
			            	    else
			            	    {
			            		    list.setVisible(true);
			            		    list.setFocus(true);
			            	    }
			                }
			      		    else if (currentZone<0)
			      		    {
		            		    list.setVisible(false);
			      		    }		      		
		            	    break;
				    }
			    }
            }
		}

        public void endKeyboard(IAsyncResult result)
        {
            rhPtr.resume();
            currentText = Guide.EndShowKeyboardInput(result);
            createString();
            bSelChanged = true;
        }

		public void addString(string s, bool bSort)
		{
			list.addString(s, bSort);
		}
		public void insertString(int index, string s)
		{
			list.insertString(index, s);
		}
		public void setString(int index, string s)
		{
			list.setString(index, s);
		}
		public void delString(int index)
		{
			list.delString(index);
		}
		public void setPosition(int xx, int yy)
		{
			xObject=xx;
			yObject=yy;
            list.setPosition(xObject, yObject+syBar);
		}
		public void setVisible(bool b)
		{
			bVisible=b;
		}
		public void setEnabled(bool b)
		{
			bEnabled=b;
			list.setEnabled(b);
			if (b==false)
			{					
				if (type!=COMBOTYPE_SIMPLE)
				{
					list.setVisible(false);
				}
			}
		}
		public void reset()
		{
			list.reset();
			currentText="";
			currentTextCut="";
		}
		public int getSize()
		{
			return list.strings.size();					
		}
		public void setSelected(int index)
		{
			list.setSelected(index);			
		}
		public void setCurrentText(string t)
		{
			currentText=t;
            createString();
		}
		public void ensureLineIsVisible(int line)
		{
	        list.ensureIndexIsVisible(line);
		}
		public void setForeground(int color)
		{
			fontColor=color;
			list.setForeground(color);
		}
		public void setBackground(int color)
		{
			backColor=color;
			createDisplay();
			list.setBackground(color);
		}
		public void setData(int index, int data)
		{
			list.setData(index, data);
		}
		public int getSelectedIndex()
		{
			return list.ySelected;
		}
		public string getString(int index)
		{
			return (String)(list.strings.get(index));
		}
		public int findString(string search, int startIndex)
		{
			return list.findString(search, startIndex);	
		}
		public int findStringExact(string search, int startIndex)
		{
			return list.findStringExact(search, startIndex);	
		}
		public int getData(int index)
		{
			return list.getData(index);	
		}
        public void setWidth(int w)
        {
            width=w;
            sxText = width - 2;
            if (type != COMBOTYPE_SIMPLE)
            {
                sxText -= SX_BUTTON;
            }
            list.width = w;
        }
        public void setHeight(int h)
        {
            height=h;
            list.height=h;
        }
        public void setFont(CFontInfo f)
        {
            font=f;
            CFont fnt = CFont.createFromFontInfo(font, rhPtr.rhApp);
            spriteFont = fnt.getFont();
			syBar=syText+SY_BARBORDER*2+4;
            list.setFont(f);
        }
    }
    class CComboList : IControl
    {
        public const int LISTFLAG_SCROLLBAR = 0x0001;
        public const int LISTFLAG_SORT = 0x0002;
        public const int LISTFLAG_BORDER = 0x0004;
        public const int LISTFLAG_3DLOOK = 0x0008;
        public const int LISTFLAG_HIDDEN = 0x0010;
        public const int LISTFLAG_SCROLLTONEWLINE = 0x0020;
        int SY_TEXTBORDERS = 4;
        int SELECTED_COLOR = 0x7FCEFF;
        int HILIGHT_COLOR = 0xB2E1FF;

        public int width;
        public int height;
        int trueHeight;
        int xObject;
        int yObject;
        int backColor;
        int fontColor;
        int flags;
        CFontInfo font;
        int nLines;
        public bool bVisible;
        int yPos;
        int syLine;
        public int yHilight;
        public int ySelected;
        int sBorder;
        public bool bFocus;
        public int oldKey;
        public CArrayList strings;
        public CArrayList stringsShort;
        public CArrayList datas;
        CComboVScrollBar slider = null;
        public bool bClick;
        public bool bDoubleClick;
        public bool bEnabled;
        public bool bSelChanged;
        CRun rhPtr;
        bool bMouseControlled;
        int syText;
        CRect tempRc = new CRect();
        Vector2 vector = new Vector2();
        SpriteFont spriteFont;
        int xSlider;
        int ySlider;

        public CComboList(CRun rh, int xx, int yy, int w, int h, CFontInfo ft, int ftColor, int bkColor, int fl)
        {
            rhPtr = rh;
            xObject = xx;
            yObject = yy;
            width = w;
            height = h;
            backColor = bkColor;
            fontColor = ftColor;
            font = ft;
            flags = fl;
            strings = new CArrayList();
            stringsShort = new CArrayList();
            datas = new CArrayList();

            yPos = 0;
            yHilight = -1;
            ySelected = -1;
            oldKey = 0;
            bFocus = false;
            bEnabled = true;

            sBorder = 0;
            if ((flags & LISTFLAG_BORDER) != 0)
            {
                sBorder = 1;
                if ((flags & LISTFLAG_3DLOOK) != 0)
                {
                    sBorder = 3;
                }
            }

            CFont f = CFont.createFromFontInfo(font, rhPtr.rhApp);
            spriteFont = f.getFont();
            syText = spriteFont.LineSpacing;
            syLine = syText + SY_TEXTBORDERS;
            nLines = (height - sBorder * 2) / syLine;
            trueHeight = sBorder * 2 + syLine * nLines;
            if ((flags & LISTFLAG_SCROLLBAR) != 0)
            {
                xSlider = width - sBorder - CComboVScrollBar.SX_BUTTON;
                ySlider = sBorder;
                slider = new CComboVScrollBar(rhPtr, xObject + xSlider, yObject + ySlider, CComboVScrollBar.SX_BUTTON, trueHeight - sBorder * 2);
            }

            bVisible = true;
            if ((flags & LISTFLAG_HIDDEN) != 0)
            {
                bVisible = false;
            }
        }
        public void setMouseControlled(bool bFlag)
        {
            bMouseControlled = bFlag;
            bFocus = bFlag;
        }
        public void destroy()
        {
        }
        public void handle(int xMouse, int yMouse)
        {
            if (bVisible == false || bEnabled == false)
            {
                return;
            }

            if (bMouseControlled)
            {
                yHilight = getLine(xMouse, yMouse);
            }

            if (bFocus)
            {
                int key = 0;
                if (bMouseControlled == false)
                {
                    if ((rhPtr.rhPlayer[0] & 0x01) != 0)		// UP
                    {
                        key = 1;
                    }
                    if ((rhPtr.rhPlayer[0] & 0x02) != 0)		// DOWN
                    {
                        key = 2;
                    }
                    if ((rhPtr.rhPlayer[0] & 0x10) != 0)		// RETURN
                    {
                        key = 3;
                    }
                }
                /*				if (keyBuffer[33]!=0)		// PAGEUP
                                {
                                    key=4;
                                }
                                if (keyBuffer[34]!=0)		// PAGEDOWN
                                {
                                    key=5;
                                }
                */
                if (key != oldKey)
                {
                    oldKey = key;
                    int y = ySelected;
                    switch (key)
                    {
                        case 1:		// Up
                            if (ySelected > 0)
                            {
                                ySelected--;
                                if (ySelected < yPos)
                                {
                                    yPos--;
                                }
                                ensureIndexIsVisible(ySelected);
                                bSelChanged = true;
                            }
                            break;
                        case 2:
                            if (ySelected < strings.size() - 1)
                            {
                                ySelected++;
                                if (ySelected - yPos >= nLines)
                                {
                                    yPos++;
                                }
                                ensureIndexIsVisible(ySelected);
                                bSelChanged = true;
                            }
                            break;
                        case 3:
                            bClick = true;
                            bDoubleClick = false;
                            break;
                        case 4:
                            if (y >= 0)
                            {
                                y -= nLines;
                                if (y < 0)
                                {
                                    y = 0;
                                }
                                if (y != ySelected)
                                {
                                    ySelected = y;
                                    if (ySelected - yPos < 0)
                                    {
                                        yPos = ySelected;
                                    }
                                    ensureIndexIsVisible(ySelected);
                                    bSelChanged = true;
                                }
                            }
                            break;
                        case 5:
                            if (y < strings.size())
                            {
                                y += nLines;
                                if (y >= strings.size())
                                {
                                    y = strings.size() - 1;
                                }
                                if (y != ySelected)
                                {
                                    ySelected = y;
                                    if (ySelected - yPos >= nLines)
                                    {
                                        yPos = ySelected - nLines + 1;
                                        if (yPos + nLines > strings.size())
                                        {
                                            yPos = strings.size() - nLines;
                                        }
                                    }
                                    ensureIndexIsVisible(ySelected);
                                    bSelChanged = true;
                                }
                            }
                            break;
                    }
                }
            }

            if (slider != null)
            {
                slider.setRange(strings.size(), yPos, nLines);
                slider.handle(xMouse - xSlider, yMouse - ySlider);
                if (slider.yPos != yPos)
                {
                    yPos = slider.yPos;
                }
            }
        }
        public int getX()
        {
            return xObject;
        }
        public int getY()
        {
            return yObject;
        }
        public void setPosition(int xx, int yy)
        {
            xObject = xx;
            yObject = yy;
        }
        public void createStrings()
        {
            int n;

            stringsShort.clear();
            for (n = 0; n < strings.size(); n++)
            {
                string pString = (string)strings.get(n);
                Vector2 size = spriteFont.MeasureString(pString);
                int pos = pString.Length;
                while (size.X >= width - sBorder * 2)
                {
                    if (pos == 0)
                    {
                        pString = "";
                        break;
                    }
                    pos = Math.Max(0, pos - 10);
                    string testString = pString.Substring(0, pos);
                    size = spriteFont.MeasureString(testString);
                    if (size.X < width - sBorder * 2)
                    {
                        int nn;
                        int oldNN = 0;
                        for (nn = 0; nn < 10; nn++)
                        {
                            testString = pString.Substring(0, pos + nn);
                            size = spriteFont.MeasureString(testString);
                            if (size.X >= width - sBorder * 2)
                            {
                                break;
                            }
                            oldNN = nn;
                        }
                        pString = pString.Substring(0, pos + oldNN);
                        break;
                    }
                };
                stringsShort.add(pString);
            }
        }
        public void drawControl(SpriteBatch batch)
        {
            if (bVisible == false)
            {
                return;
            }

            // Draw background
            tempRc.left = xObject;
            tempRc.top = yObject;
            tempRc.right = xObject + width;
            tempRc.bottom = yObject + trueHeight;
            rhPtr.rhApp.services.fillRect(batch, tempRc, backColor);
            if ((flags & LISTFLAG_BORDER) != 0)
            {
                if ((flags & LISTFLAG_3DLOOK) == 0)
                {
                    rhPtr.rhApp.services.drawRect(batch, xObject, yObject, width, trueHeight, 0);
                }
                else
                {
                    rhPtr.rhApp.services.drawRect(batch, xObject, yObject, width - 1, trueHeight - 1, 0x698790);
                    rhPtr.rhApp.services.drawRect(batch, xObject + 1, yObject + 1, width - 3, trueHeight - 3, 0xFFFFFF);
                    rhPtr.rhApp.services.drawLine(rhPtr.rhApp.spriteBatch, xObject + 2, yObject + trueHeight - 3, xObject + 2, yObject + 2, 0x696969, 1);
                    rhPtr.rhApp.services.drawLine(rhPtr.rhApp.spriteBatch, xObject + 2, yObject + 2, xObject + width - 3, yObject + 2, 0x696969, 1);
                    rhPtr.rhApp.services.drawLine(rhPtr.rhApp.spriteBatch, xObject + width - 3, yObject + 2, xObject + width - 3, yObject + trueHeight - 3, 0xE3E3E3, 1);
                    rhPtr.rhApp.services.drawLine(rhPtr.rhApp.spriteBatch, xObject + width - 3, yObject + trueHeight - 3, xObject + 2, yObject + trueHeight - 3, 0xE3E3E3, 1);
                }
            }

            int n, color;
            for (n = 0; n < nLines; n++)
            {
                color = -1;
                if (bFocus)
                {
                    if (n + yPos == ySelected)
                    {
                        color = SELECTED_COLOR;
                    }
                    else if (n + yPos == yHilight)
                    {
                        color = HILIGHT_COLOR;
                    }
                }
                if (color != -1)
                {
                    tempRc.left = xObject + sBorder;
                    tempRc.top = yObject + n * syLine + sBorder;
                    tempRc.right = xObject + width - sBorder * 2;
                    tempRc.bottom = tempRc.top + syLine;
                    rhPtr.rhApp.services.fillRect(batch, tempRc, HILIGHT_COLOR);
                }
                vector.X = xObject + sBorder;
                vector.Y = yObject + n * syLine + sBorder;
                Color cc = CServices.getColor(fontColor);
                batch.DrawString(spriteFont, (string)stringsShort.get(n + yPos), vector, cc);
            }
            if (slider != null)
            {
                slider.drawControl(batch);
            }
        }
        public void click(int nClicks)
        {
            if (bVisible == false || bEnabled == false)
            {
                return;
            }
            if (yHilight >= 0)
            {
                if (ySelected != yHilight)
                {
                    ySelected = yHilight;
                    bSelChanged = true;
                }
                if (nClicks == 1)
                {
                    bClick = true;
                    bDoubleClick = false;
                    if (slider != null)
                    {
                        slider.click(nClicks);
                    }
                }
                else
                {
                    bClick = false;
                    bDoubleClick = true;
                    if (slider != null)
                    {
                        slider.click(nClicks);
                    }
                }
            }
        }
        public void setFocus(Boolean bFlag)
        {
            if (bFlag != bFocus)
            {
                bFocus = bFlag;
                if (bFlag)
                {
                    if (ySelected < 0)
                    {
                        ySelected = 0;
                    }
                }
            }
        }
        public int getLine(int x, int y)
        {
            if (x > sBorder && y > sBorder)
            {
                int sx = width - sBorder;
                if (slider != null)
                {
                    sx -= CComboVScrollBar.SX_BUTTON;
                }
                if (x < sx && y < trueHeight - sBorder)
                {
                    int yy = yPos + (y - sBorder) / syLine;
                    if (yy < strings.size())
                    {
                        return yy;
                    }
                }
            }
            return -1;
        }
        public void sortStrings()
        {
            if ((flags & LISTFLAG_SORT) != 0)
            {
                if (strings.size() > 1)
                {
                    int bCount = 0;
                    do
                    {
                        int n;
                        for (n = 0; n < strings.size() - 1; n++)
                        {
                            string s1 = (String)(strings.get(n));
                            string s2 = (String)(strings.get(n + 1));
                            if (string.Compare(s1, s2) > 0)
                            {
                                strings.set(n, s2);
                                strings.set(n + 1, s1);
                                int tmp = (int)(datas.get(n));
                                datas.set(n, datas.get(n + 1));
                                datas.set(n + 1, tmp);
                                bCount++;
                            }
                        }
                    } while (bCount != 0);
                }
            }
            createStrings();
        }
        public void addString(string s, bool bFast)
        {
            strings.add(s);
            if (bFast)
            {
                datas.add(0);
                sortStrings();
                if ((flags & LISTFLAG_SCROLLTONEWLINE) != 0)
                {
                    int index = strings.size() - 1;
                    if ((flags & LISTFLAG_SORT) != 0)
                    {
                        int n;
                        for (n = 0; n < strings.size(); n++)
                        {
                            string ss = (String)(strings.get(n));
                            if (s == ss)
                            {
                                index = n;
                                break;
                            }
                        }
                    }
                    ensureIndexIsVisible(index);
                }
            }
        }
        public void insertString(int index, string s)
        {
            strings.insert(index, s);
            datas.insert(index, 0);
            if (ySelected >= index)
            {
                ySelected++;
            }
            sortStrings();
            if ((flags & LISTFLAG_SCROLLTONEWLINE) != 0)
            {
                if ((flags & LISTFLAG_SORT) != 0)
                {
                    int n;
                    for (n = 0; n < strings.size(); n++)
                    {
                        string ss = (String)(strings.get(n));
                        if (s == ss)
                        {
                            index = n;
                            break;
                        }
                    }
                }
                ensureIndexIsVisible(index);
            }
        }
        public void setString(int index, string s)
        {
            strings.set(index, s);
            sortStrings();
        }
        public void setData(int index, int data)
        {
            if (index >= 0 && index < datas.size())
            {
                datas.set(index, data);
            }
        }
        public int getData(int index)
        {
            if (index >= 0 && index < datas.size())
            {
                return (int)(datas.get(index));
            }
            return 0;
        }
        public void delString(int index)
        {
            strings.remove(index);
            datas.remove(index);
            createStrings();
            if (ySelected == index)
            {
                ySelected = -1;
            }
            if (ySelected > index)
            {
                ySelected--;
            }
            if (yPos > 0)
            {
                if (yPos + nLines > strings.size())
                {
                    yPos = strings.size() - nLines;
                    if (yPos < 0)
                    {
                        yPos = 0;
                    }
                }
            }
        }
        public void setFont(CFontInfo fi)
        {
            font = fi;
            CFont f = CFont.createFromFontInfo(font, rhPtr.rhApp);
            spriteFont = f.getFont();
            syText = spriteFont.LineSpacing;
            syLine = syText + SY_TEXTBORDERS;
            nLines = (height - sBorder * 2) / syLine;
            trueHeight = sBorder * 2 + syLine * nLines;
        }
        public void setForeground(int rgb)
        {
            fontColor = rgb;
        }
        public void setBackground(int rgb)
        {
            backColor = rgb;
        }
        public void setSize(int sx, int sy)
        {
            width = sx;
            height = sy;
            nLines = (height - sBorder * 2) / syLine;
            trueHeight = sBorder * 2 + syLine * nLines;
            createStrings();
        }
        public void reset()
        {
            strings.clear();
            yPos = 0;
            yHilight = -1;
            ySelected = -1;
        }
        public void setSelected(int index)
        {
            if (index < 0 || index >= strings.size())
            {
                index = -1;
            }
            if (index != ySelected)
            {
                ySelected = index;
                bSelChanged = true;
            }
        }
        public void setVisible(bool b)
        {
            bVisible = b;
            if (slider != null)
            {
                slider.setVisible(b);
            }
        }
        public void setEnabled(Boolean b)
        {
            if (bEnabled != b)
            {
                bEnabled = b;
                if (slider != null)
                {
                    slider.setEnabled(b);
                }
            }
        }
        public void ensureIndexIsVisible(int index)
        {
            if (index >= 0 && index < strings.size())
            {
                if (index < yPos)
                {
                    yPos = index;
                    ySelected = index;
                    bSelChanged = true;
                }
                else if (index >= yPos + nLines)
                {
                    yPos = index - nLines + 1;
                    ySelected = index;
                    bSelChanged = true;
                }
            }
        }
        public int findString(string search, int startIndex)
        {
            if (search.Length > 0)
            {
                int tries = strings.size();
                int i = startIndex;
                int subStringLength = search.Length;
                while (tries > 0)
                {
                    tries--;
                    i++;
                    // Wrap around
                    if (i >= strings.size())
                    {
                        i = 0;
                    }
                    string cmp = (String)(strings.get(i));
                    if (cmp.IndexOf(search) == 0)
                    {
                        // Found a line
                        return i;
                    }
                }
            }
            return -1;
        }
        public int findStringExact(string search, int startIndex)
        {
            if (search.Length > 0)
            {
                int tries = strings.size();
                int i = startIndex;
                while (tries > 0)
                {
                    tries--;
                    i++;
                    // Wrap around
                    if (i >= strings.size())
                    {
                        i = 0;
                    }
                    string cmp = (String)(strings.get(i));
                    if (string.Compare(cmp, search) == 0)
                    {
                        // Found a line
                        return i;
                    }
                }
            }
            return -1;
        }

    }

    class CComboVScrollBar
    {
        public const int SX_BUTTON = 19;
        public const int SY_BUTTON = 18;
        public const int SX_LINES = 6;
        public const int SX_ARROW = 8;
        public const int SY_ARROW = 4;

        public int xObject;
        public int yObject;
        public int width;
        public int height;
        public int yPos;
        public int yMax;
        public int syCenter;
        public int sySlider;
        public int ySlider;
        public int hilight;
        public int selected;
        public bool bActivated;
        public int oldZone;
        public int yDrag;
        public int yDragPos;
        public bool bDrag;
        public int oldKey;
        public bool bEnabled;
        public bool bVisible;
        CRun rhPtr;
        Texture2D upArrow = null;
        Texture2D downArrow = null;
        Texture2D background = null;
        Rectangle tempRect = new Rectangle();

        public CComboVScrollBar(CRun rh, int xx, int yy, int w, int h)
        {
            rhPtr = rh;
            xObject = xx;
            yObject = yy;
            width = w;
            height = h;
            yPos = 0;
            yMax = 10;
            syCenter = 1;
            hilight = -1;
            selected = -1;
            oldZone = -1;
            oldKey = 0;
            bEnabled = true;
            bVisible = true;

            background = CServices.createGradientRectangle(rhPtr.rhApp, width - 1, height - 1, 0x94999B, 0xE7E7E7, true, 1, 0x6A6B6E);
            createDisplay();
        }
        public int getX()
        {
            return xObject;
        }
        public int getY()
        {
            return yObject;
        }
        public void click(int nClicks)
        {
        }
        public void setFocus(bool bFocus)
        {
            if (bFocus != bEnabled)
            {
                bEnabled = bFocus;
                createDisplay();
            }
        }
        void createDisplay()
        {
            int color = 0x808080;
            if (hilight == 0)
            {
                color = 0x404040;
            }
            if (bActivated == false || bEnabled == false)
            {
                color = 0xC0C0C0;
            }
            upArrow = CServices.createUpArrow(rhPtr.rhApp, SX_ARROW, SY_ARROW, color);

            color = 0x808080;
            if (hilight == 2)
            {
                color = 0x404040;
            }
            if (bActivated == false || bEnabled == false)
            {
                color = 0xC0C0C0;
            }
            downArrow = CServices.createDownArrow(rhPtr.rhApp, SX_ARROW, SY_ARROW, color);
        }

        public void handle(int xMouse, int yMouse)
        {
            if (bActivated && bEnabled)
            {
                bool bDisplay = false;
                int zone = getZone(xMouse, yMouse);
                if (zone != hilight)
                {
                    hilight = zone;
                    if (zone < 0)
                    {
                        selected = -1;
                    }
                    bDisplay = true;
                }

                int key = 0;
                if ((rhPtr.rh2MouseKeys&0x01)!=0)
                {
                    key = 1;
                }
                if (key != oldKey)
                {
                    oldKey = key;
                    bDisplay = true;
                    if (key == 1)
                    {
                        selected = zone;
                        switch (zone)
                        {
                            case 0:
                                if (yPos > 0)
                                {
                                    yPos--;
                                }
                                break;
                            case 1:
                                bDrag = true;
                                yDrag = yMouse;
                                yDragPos = yPos;
                                break;
                            case 2:
                                if (yPos + syCenter < yMax)
                                {
                                    yPos++;
                                }
                                break;
                            case 3:
                                yPos -= syCenter;
                                if (yPos < 0)
                                {
                                    yPos = 0;
                                }
                                break;
                            case 4:
                                yPos += syCenter;
                                if (yPos > yMax - syCenter)
                                {
                                    yPos = yMax - syCenter;
                                }
                                break;
                        }
                    }
                    else
                    {
                        bDrag = false;
                        selected = -1;
                    }
                }
                if (key == 1 && bDrag == true)
                {
                    int y = yDragPos + ((yMouse - yDrag) * yMax) / (height - SY_BUTTON * 2);
                    if (y < 0)
                    {
                        y = 0;
                    }
                    if (y > yMax - syCenter)
                    {
                        y = yMax - syCenter;
                    }
                    if (y != yPos)
                    {
                        yPos = y;
                    }
                }
                if (bDisplay)
                {
                    createDisplay();
                }
            }
        }

        public int getZone(int xMouse, int yMouse)
        {
            if (xMouse >= 0 && xMouse < SX_BUTTON)
            {
                if (yMouse >= 0 && yMouse < height)
                {
                    if (yMouse < SY_BUTTON)
                    {
                        return 0;
                    }
                    if (yMouse >= ySlider && yMouse < ySlider + sySlider)
                    {
                        return 1;
                    }
                    if (yMouse >= height - SY_BUTTON)
                    {
                        return 2;
                    }
                    if (yMouse < ySlider)
                    {
                        return 3;
                    }
                    return 4;
                }
            }
            return -1;
        }

        public void drawControl(SpriteBatch batch)
        {
            if (bVisible == false)
            {
                return;
            }

            tempRect.X = xObject;
            tempRect.Y = yObject;
            tempRect.Width = background.Width;
            tempRect.Height = background.Height;
            batch.Draw(background, tempRect, Color.White);

            int color = 0x6A6B6E;
            if (hilight == 0)
            {
                color = 0x64CFFF;
            }
            rhPtr.rhApp.services.drawRect(batch, xObject, yObject, width - 1, SY_BUTTON - 1, color);
            color = 0x6A6B6E;
            if (hilight == 2)
            {
                color = 0x64CFFF;
            }
            rhPtr.rhApp.services.drawRect(batch, xObject, yObject + height - SY_BUTTON, width - 1, SY_BUTTON - 1, color);

            color = 0xF4F4F4;
            if (selected == 0)
            {
                color = 0xA6DCFF;
            }
            rhPtr.rhApp.services.fillRect(batch, xObject + 1, yObject + 1, width - 3, SY_BUTTON - 3, color);
            color = 0xF4F4F4;
            if (selected == 2)
            {
                color = 0xA6DCFF;
            }
            rhPtr.rhApp.services.fillRect(batch, xObject + 1, yObject + height - SY_BUTTON, width - 3, SY_BUTTON - 3, color);

            tempRect.X = xObject + SX_BUTTON / 2 - SX_ARROW / 2;
            tempRect.Y = yObject + SY_BUTTON / 2 - SY_ARROW / 2;
            tempRect.Width = upArrow.Width;
            tempRect.Height = upArrow.Height;
            batch.Draw(upArrow, tempRect, Color.White);

            tempRect.Y = yObject + height - SY_BUTTON + SY_BUTTON / 2 - SY_ARROW / 2;
            batch.Draw(downArrow, tempRect, Color.White);

            if (bActivated && bEnabled)
            {
                ySlider = ((height - SY_BUTTON * 2) * yPos) / yMax + SY_BUTTON;
                sySlider = (syCenter * (height - SY_BUTTON * 2)) / yMax;
                if (sySlider < 10)
                {
                    sySlider = 10;
                }
                if (ySlider + sySlider > height - SY_BUTTON)
                {
                    ySlider = height - SY_BUTTON - sySlider;
                }
                color = 0x808080;
                if (hilight == 1)
                {
                    color = 0x64CFFF;
                }
                rhPtr.rhApp.services.drawRect(batch, xObject, yObject + ySlider, width - 1, sySlider - 1, color);

                color = 0xF4F4F4;
                if (selected == 1)
                {
                    color = 0xA6DCFF;
                }
                rhPtr.rhApp.services.fillRect(batch, xObject + 1, yObject + ySlider + 1, width - 3, sySlider - 3, color);

                if (syCenter > 15)
                {
                    int n, y;
                    for (n = 0; n < 5; n++)
                    {
                        y = ySlider + sySlider / 2 - 5 + n * 2;
                        rhPtr.rhApp.services.drawLine(rhPtr.rhApp.spriteBatch, xObject + width / 2 - SX_LINES / 2, yObject + y, xObject + width / 2 + SX_LINES / 2, yObject + y, 0x929292, 1);
                    }
                }
            }
        }
        public void setRange(int ySize, int y, int sy)
        {
            bActivated = false;
            yMax = ySize;
            yPos = y;
            syCenter = sy;
            if (yPos + syCenter > yMax)
            {
                yPos = yMax - syCenter;
                if (yPos < 0)
                {
                    yPos = 0;
                }
            }
            if (yMax > 0 && yPos + syCenter <= yMax)
            {
                bActivated = true;
            }
        }
        public void setEnabled(bool b)
        {
            if (b != bEnabled)
            {
                bEnabled = b;
                createDisplay();
            }
        }
        public void setVisible(bool b)
        {
            bVisible = b;
        }
    }

}
