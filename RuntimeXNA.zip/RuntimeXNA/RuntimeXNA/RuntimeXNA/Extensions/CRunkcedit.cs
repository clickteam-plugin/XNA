﻿//----------------------------------------------------------------------------------
//
// CRUNSTATICTEXT: extension object
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.GamerServices;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Banks;
using RuntimeXNA.Application;

namespace RuntimeXNA.Extensions
{
    class CRunkcedit : CRunExtension, IControl
    {
	    // Fields
		const int CND_VISIBLE = 0;
	    const int CND_ENABLE = 1;
	    const int CND_CANUNDO = 2;
	    const int CND_MODIFIED = 3;
	    const int CND_HAVEFOCUS = 4;
	    const int CND_ISNUMBER = 5;
	    const int CND_ISSELECTED = 6;
	    const int CND_LAST = 7;
	    const int ACT_LOADTEXT = 0;
	    const int ACT_LOADTEXTSELECT = 1;
	    const int ACT_SAVETEXT = 2;
	    const int ACT_SAVETEXTSELECT = 3;
	    const int ACT_SETTEXT = 4;
	    const int ACT_REPLACESELECTION = 5;
	    const int ACT_CUT = 6;
	    const int ACT_COPY = 7;
	    const int ACT_PASTE = 8;
	    const int ACT_CLEAR = 9;
	    const int ACT_UNDO = 10;
	    const int ACT_CLEARUNDOBUFFER = 11;
	    const int ACT_SHOW = 12;
	    const int ACT_HIDE = 13;
	    const int ACT_SETFONTSELECT = 14;
	    const int ACT_SETCOLORSELECT = 15;
	    const int ACT_ACTIVATE = 16;
	    const int ACT_ENABLE = 17;
	    const int ACT_DISABLE = 18;
	    const int ACT_READONLYON = 19;
	    const int ACT_READONLYOFF = 20;
	    const int ACT_TEXTMODIFIED = 21;
	    const int ACT_TEXTNOTMODIFIED = 22;
	    const int ACT_LIMITTEXTSIZE = 23;
	    const int ACT_SETPOSITION = 24;
	    const int ACT_SETXPOSITION = 25;
	    const int ACT_SETYPOSITION = 26;
	    const int ACT_SETSIZE = 27;
	    const int ACT_SETXSIZE = 28;
	    const int ACT_SETYSIZE = 29;
	    const int ACT_DESACTIVATE = 30;
	    const int ACT_SCROLLTOTOP = 31;
	    const int ACT_SCROLLTOLINE = 32;
	    const int ACT_SCROLLTOEND = 33;
	    const int ACT_SETCOLOR = 34;
	    const int ACT_SETBKDCOLOR = 35;
	    const int ACT_LAST = 36;
	    const int EXP_GETTEXT = 0;
	    const int EXP_GETSELECTION = 1;
	    const int EXP_GETXPOSITION = 2;
	    const int EXP_GETYPOSITION = 3;
	    const int EXP_GETXSIZE = 4;
	    const int EXP_GETYSIZE = 5;
	    const int EXP_GETVALUE = 6;
	    const int EXP_GETFIRSTLINE = 7;
	    const int EXP_GETLINECOUNT = 8;
	    const int EXP_GETCOLOR = 9;
	    const int EXP_GETBKDCOLOR = 10;
	    const int EXP_LAST = 11;
	    const int EDIT_HSCROLLBAR = 0x0001;
	    const int EDIT_HSCROLLAUTOSCROLL = 0x0002;
	    const int EDIT_VSCROLLBAR = 0x0004;
	    const int EDIT_VSCROLLAUTOSCROLL = 0x0008;
	    const int EDIT_READONLY = 0x0010;
	    const int EDIT_MULTILINE = 0x0020;
	    const int EDIT_PASSWORD = 0x0040;
	    const int EDIT_BORDER = 0x0080;
	    const int EDIT_HIDEONSTART = 0x0100;
	    const int EDIT_UPPERCASE = 0x0200;
	    const int EDIT_LOWERCASE = 0x0400;
	    const int EDIT_TABSTOP = 0x0800;
	    const int EDIT_SYSCOLOR = 0x1000;
	    const int EDIT_3DLOOK = 0x2000;
	    const int EDIT_TRANSP = 0x4000;
	    const int EDIT_ALIGN_HCENTER = 0x00010000;
	    const int EDIT_ALIGN_RIGHT = 0x00020000;

		CFontInfo textFontInfo;
		int textForeColour;
		int textBackColour;
		int flags;
		bool bVisible;
		bool bModified;
		bool bEditable;
		int oldWidth;
		int oldHeight;		
		bool bFocus;
		int limitTextSize;
		bool bEnabled;
        bool bMouseControlled=false;
        CRect tempRc = new CRect();
        Vector2 vector = new Vector2();
        int sBorder;
        SpriteFont spriteFont;
        string pString="";
        string pStringShort = "";

	    public override int getNumberOfConditions()
	    {
	        return CND_LAST;
	    }

	    public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
	    {
	        // Read in edPtr values
	        ho.hoImgWidth = file.readAShort();
	        ho.hoImgHeight = file.readAShort();
	        if (ho.hoAdRunHeader.rhApp.bUnicode==false)
	        {
	            textFontInfo = file.readLogFont16();
	        }
	        else
	        {
	            textFontInfo = file.readLogFont();
	        }
	        file.skipBytes(4 * 16); // Skip custom colours
	        textForeColour = file.readAColor();
	        textBackColour = file.readAColor();
	        file.readAString(40);			// TextStyle
	        flags = file.readAInt();
	
	        // Init fields
	        bModified=false;
			bFocus=false;
			limitTextSize=-1;
				
            oldWidth=ho.hoImgWidth;
            oldHeight=ho.hoImgHeight;
            bVisible=true;
            if ((flags & EDIT_HIDEONSTART) != 0)
            {
                bVisible=false;
            }
			bFocus=false;
			bEnabled=true;

            bEditable=true;
            if ((flags & EDIT_READONLY)!=0)
            {
            	bEditable=false;
            }
            sBorder=0;
            if ((flags & EDIT_BORDER) != 0)
            {
                sBorder = 1;
                if ((flags & EDIT_3DLOOK) != 0)
                {
                    sBorder = 3;
                }
            }
            CFont f = CFont.createFromFontInfo(textFontInfo, ho.hoAdRunHeader.rhApp);
            spriteFont = f.getFont();

            ho.hoAdRunHeader.addControl(this);

	        return false;
	    }

        public override void destroyRunObject(bool bFast)
        {
            ho.hoAdRunHeader.delControl(this);
        }

        public int getX()
        {
            return ho.hoX;
        }
        public int getY()
        {
            return ho.hoY;
        }
        public void setFocus(bool bFlag)
        {
            bFocus = bFlag;
        }
        public void setMouseControlled(bool bFlag)
        {
            bMouseControlled = bFlag;
        }
        public void click(int nClicks)
        {
        }
        public void drawControl(SpriteBatch batch)
        {
            if (bVisible == false)
            {
                return;
            }

            // Draw background
            int xObject=ho.hoX-ho.hoAdRunHeader.rhWindowX+ho.hoAdRunHeader.rhApp.xOffset;
            int yObject=ho.hoY-ho.hoAdRunHeader.rhWindowY+ho.hoAdRunHeader.rhApp.yOffset;
            CRun rhPtr=ho.hoAdRunHeader;

            int color;
            if ((flags & EDIT_TRANSP) == 0 || bFocus==true)
            {
                tempRc.left = xObject;
                tempRc.top = yObject;
                tempRc.right = xObject + ho.hoImgWidth;
                tempRc.bottom = yObject + ho.hoImgHeight;
                color = textBackColour;
                if (bFocus)
                {
                    color = 0x64CFFF;
                }
                rhPtr.rhApp.services.fillRect(batch, tempRc, color);
            }
            if ((flags & EDIT_BORDER) != 0)
            {
                if ((flags & EDIT_3DLOOK) == 0)
                {
                    rhPtr.rhApp.services.drawRect(batch, xObject, yObject, ho.hoImgWidth, ho.hoImgHeight, 0);
                }
                else
                {
                    rhPtr.rhApp.services.drawRect(batch, xObject, yObject, ho.hoImgWidth - 1, ho.hoImgHeight - 1, 0x698790);
                    rhPtr.rhApp.services.drawRect(batch, xObject + 1, yObject + 1, ho.hoImgWidth - 3, ho.hoImgHeight - 3, 0xFFFFFF);
                    rhPtr.rhApp.services.drawLine(rhPtr.rhApp.spriteBatch, xObject + 2, yObject + ho.hoImgHeight - 3, xObject + 2, yObject + 2, 0x696969, 1);
                    rhPtr.rhApp.services.drawLine(rhPtr.rhApp.spriteBatch, xObject + 2, yObject + 2, xObject + ho.hoImgWidth - 3, yObject + 2, 0x696969, 1);
                    rhPtr.rhApp.services.drawLine(rhPtr.rhApp.spriteBatch, xObject + ho.hoImgWidth - 3, yObject + 2, xObject + ho.hoImgWidth - 3, yObject + ho.hoImgHeight - 3, 0xE3E3E3, 1);
                    rhPtr.rhApp.services.drawLine(rhPtr.rhApp.spriteBatch, xObject + ho.hoImgWidth - 3, yObject + ho.hoImgHeight - 3, xObject + 2, yObject + ho.hoImgHeight - 3, 0xE3E3E3, 1);
                }
            }

            vector.X = xObject + sBorder+1;
            if ((flags&EDIT_ALIGN_RIGHT)!=0)
            {
                Vector2 size=spriteFont.MeasureString(pStringShort);
                vector.X=xObject+ho.hoImgWidth-sBorder-size.X;
            }
            vector.Y = yObject + sBorder;
            if ((flags&EDIT_ALIGN_HCENTER)!=0)
            {
                vector.Y=yObject+ho.hoImgHeight/2-spriteFont.LineSpacing/2;
            }
            color=textForeColour;
            if (bEnabled == false)
            {
                color = 0xC0C0C0;
            }
            Color cc = CServices.getColor(color);
            batch.DrawString(spriteFont, pStringShort, vector, cc);
        }
        public void createString()
        {
            String s = pString;
            if ((flags & EDIT_PASSWORD) != 0)
            {
                char[] stars = new char[pString.Length];
                int n;
                for (n = 0; n < stars.Length; n++)
                {
                    stars[n] = '*';
                }
                s = new string(stars);
            }
            pStringShort = s;

            Vector2 size = spriteFont.MeasureString(s);
            int pos = s.Length;
            while (size.X >= ho.hoImgWidth - sBorder * 2-1)
            {
                if (pos == 0)
                {
                    pStringShort = "";
                    break;
                }
                pos = Math.Max(0, pos - 10);
                string testString = s.Substring(0, pos);
                size = spriteFont.MeasureString(testString);
                if (size.X < ho.hoImgWidth - sBorder * 2-1)
                {
                    int nn;
                    int oldNN = 0;
                    for (nn = 0; nn < 10; nn++)
                    {
                        testString = s.Substring(0, pos + nn);
                        size = spriteFont.MeasureString(testString);
                        if (size.X >= ho.hoImgWidth - sBorder * 2-1)
                        {
                            break;
                        }
                        oldNN = nn;
                    }
                    pStringShort = s.Substring(0, pos + oldNN);
                    break;
                }
            };
        }

        public override int handleRunObject()
        {
            bool bAppear=false;
            CRun rhPtr=ho.hoAdRunHeader;
            if (bVisible && bEnabled && bEditable)
            {
                if (bMouseControlled)
                {
                    if ((rhPtr.rh2MouseKeys & 0x01) != 0)
                    {
                        if (rhPtr.rh2MouseX >= ho.hoX && rhPtr.rh2MouseX < ho.hoX + ho.hoImgWidth)
                        {
                            if (rhPtr.rh2MouseY >= ho.hoY && rhPtr.rh2MouseY < ho.hoY + ho.hoImgHeight)
                            {
                                bAppear = true;
                            }
                        }
                    }
                }
                else
                {
                    if (bFocus)
                    {
                        if ((rhPtr.rhPlayer[0] & 0x10) != 0)
                        {
                            bAppear = true;
                        }
                    }
                }
            }
            if (bAppear)
            {
                if (Guide.IsVisible == false)
                {
                    rhPtr.pause();
                    Guide.BeginShowKeyboardInput(PlayerIndex.One, rhPtr.rhApp.appName, "Please enter the text", pString, endKeyboard, (object)"TextInput", (flags & EDIT_PASSWORD) != 0);
                }
            }
            return 0;
        }

        public void endKeyboard(IAsyncResult result)
        {
            ho.hoAdRunHeader.resume();
            pString = Guide.EndShowKeyboardInput(result);
            if (limitTextSize > 0 && pString.Length > limitTextSize)
            {
                pString = pString.Substring(0, limitTextSize);
            }
            bModified = true;
            createString();
        }

	    public override CFontInfo getRunObjectFont()
	    {
	        return textFontInfo;
	    }
	
	    public override void setRunObjectFont(CFontInfo fi, CRect rc)
	    {
	        textFontInfo = fi;
            CFont f = CFont.createFromFontInfo(textFontInfo, ho.hoAdRunHeader.rhApp);
            spriteFont = f.getFont();
	        if (rc!=null)
	        {
	        	ho.hoImgWidth=rc.right-rc.left;
	        	ho.hoImgHeight=rc.bottom-rc.top;
	        }
            createString();
	    }
	
	    public override int getRunObjectTextColor()
	    {
	        return textForeColour;
	    }
	
	    public override void setRunObjectTextColor(int rgb)
	    {
	        textForeColour = rgb;
	    }

	    // Conditions
	    // --------------------------------------------------
	    public override bool condition(int num, CCndExtension cnd)
	    {
	        switch (num)
	        {
	            case CND_VISIBLE:
	                return cndVISIBLE(cnd);
	            case CND_ENABLE:
	                return cndENABLE(cnd);
	            case CND_CANUNDO:
	                return cndCANUNDO(cnd);
	            case CND_MODIFIED:
	                return cndMODIFIED(cnd);
	            case CND_HAVEFOCUS:
	                return cndHAVEFOCUS(cnd);
	            case CND_ISNUMBER:
	                return cndISNUMBER(cnd);
	            case CND_ISSELECTED:
	                return cndISSELECTED(cnd);
	        }
	        return false;
	    }

	    public bool cndVISIBLE(CCndExtension cnd)
	    {
	        return bVisible;
	    }
	
	    public bool cndENABLE(CCndExtension cnd)
	    {
	        return bEditable;
	    }
	
	    public bool cndCANUNDO(CCndExtension cnd)
	    {
	        return false;
	    }
	
	    public bool cndMODIFIED(CCndExtension cnd)
	    {	
	    	var bRet=bModified;
	    	bModified=false;    	
			return bRet;
		}
	
	    public bool cndHAVEFOCUS(CCndExtension cnd)
	    {
	        return bFocus;
	    }
	
	    public bool cndISNUMBER(CCndExtension cnd)
	    {
			if (pString.Length>0)
			{
				int first=0;
				while(pString[first]==32 && first<pString.Length)
					first++;
                if (first>=pString.Length)
                {
                    return false;
                }
				if (pString[first]>=48 && pString[first]<=57)
				{
					return true;
				}	    	
                if (pString[first]=='+' || pString[first]=='-')
                {
                    first++;
				    while(pString[first]==32 && first<pString.Length)
					    first++;
                    if (first>=pString.Length)
                    {
                        return false;
                    }
				    if (pString[first]>=48 && pString[first]<=57)
				    {
					    return true;
				    }	    	
                }
			}
			return false;
	    }
	
	    private bool cndISSELECTED(CCndExtension cnd)
	    {
	    	return false;
	    }

	    // Actions
	    // -------------------------------------------------
	    public override void action(int num, CActExtension act)
	    {
	        switch (num)
	        {
	            case ACT_LOADTEXT:
	                break;
	            case ACT_LOADTEXTSELECT:
	                break;
	            case ACT_SAVETEXT:
	                break;
	            case ACT_SAVETEXTSELECT:
	                break;
	            case ACT_SETTEXT:
	                actSETTEXT(act);
	                break;
	            case ACT_REPLACESELECTION:
	                actREPLACESELECTION(act);
	                break;
	            case ACT_CUT:
	                break;
	            case ACT_COPY:
	                break;
	            case ACT_PASTE:
	                break;
	            case ACT_CLEAR:
	                actCLEAR(act);
	                break;
	            case ACT_UNDO:
	                break;
	            case ACT_CLEARUNDOBUFFER:
	                break;
	            case ACT_SHOW:
	                actSHOW(act);
	                break;
	            case ACT_HIDE:
	                actHIDE(act);
	                break;
	            case ACT_SETFONTSELECT:
	                break;
	            case ACT_SETCOLORSELECT:
	                break;
	            case ACT_ACTIVATE:
					actACTIVATE(act);
					break;
	            case ACT_ENABLE:
	                actENABLE(act);
	                break;
	            case ACT_DISABLE:
	                actDISABLE(act);
	                break;
	            case ACT_READONLYON:
	                actREADONLYON(act);
	                break;
	            case ACT_READONLYOFF:
	                actREADONLYOFF(act);
	                break;
	            case ACT_TEXTMODIFIED:
	                actTEXTMODIFIED(act);
	                break;
	            case ACT_TEXTNOTMODIFIED:
	                actTEXTNOTMODIFIED(act);
	                break;
	            case ACT_LIMITTEXTSIZE:
	            	actLimitTextSize(act);
	                break;
	            case ACT_SETPOSITION:
	                actSETPOSITION(act);
	                break;
	            case ACT_SETXPOSITION:
	                actSETXPOSITION(act);
	                break;
	            case ACT_SETYPOSITION:
	                actSETYPOSITION(act);
	                break;
	            case ACT_SETSIZE:
	                actSETSIZE(act);
	                break;
	            case ACT_SETXSIZE:
	                actSETXSIZE(act);
	                break;
	            case ACT_SETYSIZE:
	                actSETYSIZE(act);
	                break;
	            case ACT_DESACTIVATE:
					actDESACTIVATE(act);		
	                break;
	            case ACT_SCROLLTOTOP:
	                break;
	            case ACT_SCROLLTOLINE:
	                break;
	            case ACT_SCROLLTOEND:
	                break;
	            case ACT_SETCOLOR:
	                actSETCOLOR(act);
	                break;
	            case ACT_SETBKDCOLOR:
	                actSETBKDCOLOR(act);
	                break;
	        }
	    }

		public void actDESACTIVATE(CActExtension act)
		{
			if(bMouseControlled==false)
			{
                bFocus=false;
			}
		}

		public void actACTIVATE(CActExtension act)
		{
			if(bMouseControlled==false)
			{
                bFocus=true;
                ho.hoAdRunHeader.currentControl=this;
			}
		}

	    public void actLimitTextSize(CActExtension act)
	    {
	    	limitTextSize=act.getParamExpression(rh, 0);
	    }
	    public void actSETTEXT(CActExtension act)
	    {
            pString=act.getParamExpString(rh, 0);
            createString();
	    }
	    private void actREPLACESELECTION(CActExtension act)
	    {
	    }

	    private void actCLEAR(CActExtension act)
	    {
            pString="";
            createString();
	    }

	    public void actSHOW(CActExtension act)
	    {
    		bVisible=true;
	    }
	    
	    public void actHIDE(CActExtension act)
	    {
    		bVisible=false;
	    }

	    public void actENABLE(CActExtension act)
	    {
   			bEnabled=true;
	    }
	
	    public void actDISABLE(CActExtension act)
	    {
   			bEnabled=false;
	    }

	    public void actREADONLYON(CActExtension act)
	    {
   			bEditable=false;
	    }
	
	    public void actREADONLYOFF(CActExtension act)
	    {
   			bEditable=true;
	    }

	    public void actTEXTMODIFIED(CActExtension act)
	    {
	        bModified = true;
	    }

	    public void actTEXTNOTMODIFIED(CActExtension act)
	    {
	        bModified = false;
	    }

	    public void actSETPOSITION(CActExtension act)
	    {
	        CPositionInfo pos= act.getParamPosition(rh, 0);
	        ho.setPosition(pos.x, pos.y);
	    }

	    public void actSETXPOSITION(CActExtension act)
	    {
	        ho.setPosition(act.getParamExpression(rh, 0), ho.hoY);
	    }
	
	    public void actSETYPOSITION(CActExtension act)
	    {
	        ho.setPosition(ho.hoX, act.getParamExpression(rh, 0));
    	}

	    public void actSETSIZE(CActExtension act)
	    {
	        ho.hoImgWidth = act.getParamExpression(rh, 0);
	        ho.hoImgHeight = act.getParamExpression(rh, 1);
	        ho.redraw();
	    }
	
	    public void actSETXSIZE(CActExtension act)
	    {
	        ho.hoImgWidth = act.getParamExpression(rh, 0);
	        ho.redraw();
	    }
	
	    public void actSETYSIZE(CActExtension act)
	    {
	        ho.hoImgHeight = act.getParamExpression(rh, 0);
	        ho.redraw();
	    }

	    public void actSETCOLOR(CActExtension act)
	    {
	        textForeColour = act.getParamColour(rh, 0);
	    }
	
	    public void actSETBKDCOLOR(CActExtension act)
	    {
            textBackColour = act.getParamColour(rh, 0);
        }

	    // Expressions
	    // --------------------------------------------
	    public override CValue expression(int num)
	    {
	        switch (num)
	        {
	            case EXP_GETTEXT:
	                return expGETTEXT();
	            case EXP_GETSELECTION:
	                return expGETSELECTION();
	            case EXP_GETXPOSITION:
	                return expGETXPOSITION();
	            case EXP_GETYPOSITION:
	                return expGETYPOSITION();
	            case EXP_GETXSIZE:
	                return expGETXSIZE();
	            case EXP_GETYSIZE:
	                return expGETYSIZE();
	            case EXP_GETVALUE:
	                return expGETVALUE();
	            case EXP_GETFIRSTLINE:
	                return expGETFIRSTLINE();
	            case EXP_GETLINECOUNT:
	                return expGETLINECOUNT();
	            case EXP_GETCOLOR:
	                return expGETCOLOR();
	            case EXP_GETBKDCOLOR:
	                return expGETBKDCOLOR();
	        }
	        return null;
	    }

	    public CValue expGETTEXT()
	    {
	    	return new CValue(pString);
	    }
	
	    public CValue expGETSELECTION()
	    {
	    	return new CValue("");
	    }
	    
	    public CValue expGETXPOSITION()
	    {
	        return new CValue(ho.hoX);
	    }
	
	    public CValue expGETYPOSITION()
	    {
	        return new CValue(ho.hoY);
	    }
	
	    public CValue expGETXSIZE()
	    {
	        return new CValue(ho.hoImgWidth);
    	}

	    public CValue expGETYSIZE()
	    {
	        return new CValue(ho.hoImgHeight);
	    }

	    public CValue expGETVALUE()
	    {
			CValue ret=new CValue(0);
            CFuncVal val=new CFuncVal();
			switch(val.parse(pString))
			{
				case 0:
					ret.forceInt(val.intValue);
					break;
				case 1:
					ret.forceDouble(val.doubleValue);
					break;
			}
			return ret;
	    }
	    
	    public CValue expGETFIRSTLINE()
	    {
	        return new CValue(0);
	    }
	
	    public CValue expGETLINECOUNT()
	    {
            return new CValue(1);
	    }
	
	    public CValue expGETCOLOR()
	    {
	        return new CValue(textForeColour);
	    }
	
	    public CValue expGETBKDCOLOR()
	    {
	        return new CValue(textBackColour);
	    }
	    
    }
}
