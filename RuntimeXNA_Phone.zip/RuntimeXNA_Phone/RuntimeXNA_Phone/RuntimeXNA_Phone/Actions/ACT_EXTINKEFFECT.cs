// -----------------------------------------------------------------------------
//
// SET INK EFFECT
//
// -----------------------------------------------------------------------------
using System;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Sprites;
namespace RuntimeXNA.Actions
{
	
	public class ACT_EXTINKEFFECT:CAct
	{
		public override void  execute(CRun rhPtr)
		{
			CObject pHo = rhPtr.rhEvtProg.get_ActionObjects(this);
			if (pHo == null)
				return ;
			
			if (pHo.ros != null)
			{
				PARAM_2SHORTS p = (PARAM_2SHORTS) evtParams[0];
				
				int mask = p.value1;
				pHo.ros.rsEffect &= ~ CSpriteGen.EFFECT_MASK;
				pHo.ros.rsEffect |= mask;
				
				int param = p.value2;
				pHo.ros.rsEffectParam = param;
				
				pHo.roc.rcChanged = true;
				if (pHo.roc.rcSprite != null)
				{
					pHo.hoAdRunHeader.rhApp.spriteGen.modifSpriteEffect(pHo.roc.rcSprite, pHo.ros.rsEffect, pHo.ros.rsEffectParam);
				}
			}
		}
	}
}