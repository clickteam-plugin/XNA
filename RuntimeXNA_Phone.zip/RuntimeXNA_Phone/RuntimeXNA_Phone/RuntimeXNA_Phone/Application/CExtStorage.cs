﻿//----------------------------------------------------------------------------------
//
// CEXTSTORAGE : donnees gloables pour une extension
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RuntimeXNA.Application
{
    public class CExtStorage
    {
        public int id = 0;
    }
}
