//----------------------------------------------------------------------------------
//
// CRUNIPHONEJOYSTICKCONTROL iPhone joysticks
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Application;

namespace RuntimeXNA.Extensions
{
    class CRunJoystickControl : CRunExtension
    {
        const int ACT_STARTACCELEROMETER=0;
        const int ACT_STOPACCELEROMETER=1;
        const int ACT_STARTSTOPTOUCH=2;
        const int ACT_SETJOYPOSITION=3;
        const int ACT_SETFIRE1POSITION=4;
        const int ACT_SETFIRE2POSITION=5;
        const int ACT_SETXJOYSTICK=6;
        const int ACT_SETYJOYSTICK=7;
        const int ACT_SETXFIRE1=8;
        const int ACT_SETYFIRE1=9;
        const int ACT_SETXFIRE2=10;
        const int ACT_SETYFIRE2=11;
        const int ACT_SETJOYMASK=12;
        const int EXP_XJOYSTICK=0;
        const int EXP_YJOYSTICK=1;
        const int EXP_XFIRE1=2;
        const int EXP_YFIRE1=3;
        const int EXP_XFIRE2=4;
        const int EXP_YFIRE2=5;
        const int POS_NOTDEFINED=unchecked((int)0x80000000);

	    bool bAccelerometer;
	    bool bJoystick;
	    int xJoystick;
	    int yJoystick;
	    int xFire1;
	    int yFire1;
	    int xFire2;
	    int yFire2;

        public override int getNumberOfConditions()
        {
            return 0;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
	        xJoystick=POS_NOTDEFINED;
	        yJoystick=POS_NOTDEFINED;
	        xFire1=POS_NOTDEFINED;
	        yFire1=POS_NOTDEFINED;
	        xFire2=POS_NOTDEFINED;
	        yFire2=POS_NOTDEFINED;
	        bAccelerometer=false;
	        bJoystick=false;
	
	        return true;
        }

        public override void destroyRunObject(bool bFast)
        {
            if (bJoystick)
            {
                ho.hoAdRunHeader.joystick = null;
            }
            if (bAccelerometer)
            {
                ho.hoAdRunHeader.stopJoystickAcc();
            }
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
		        case ACT_STARTACCELEROMETER:
			        startAccelerometer(act);
			        break;
		        case ACT_STOPACCELEROMETER:
			        stopAccelerometer(act);
			        break;
		        case ACT_STARTSTOPTOUCH:
			        startStopTouch(act);
			        break;
		        case ACT_SETJOYPOSITION:
			        setJoyPosition(act);
			        break;
		        case ACT_SETFIRE1POSITION:
			        setFire1Position(act);
			        break;
		        case ACT_SETFIRE2POSITION:
			        setFire2Position(act);
			        break;
		        case ACT_SETXJOYSTICK:
			        setXJoystick(act);
			        break;
		        case ACT_SETYJOYSTICK:
			        setYJoystick(act);
			        break;
		        case ACT_SETXFIRE1:
			        setXFire1(act);
			        break;
		        case ACT_SETYFIRE1:
			        setYFire1(act);
			        break;
		        case ACT_SETXFIRE2:
			        setXFire2(act);
			        break;
		        case ACT_SETYFIRE2:
			        setYFire2(act);
			        break;
		        case ACT_SETJOYMASK:
			        setJoyMask(act);
			        break;
            }
        }

        void startAccelerometer(CActExtension act)
        {
	        CRunApp rhApp=ho.hoAdRunHeader.rhApp;
	        if (rhApp.parentApp!=null)
	        {
		        return;
	        }
	        if (rhApp.frame.joystick!=CRunFrame.JOYSTICK_EXT)
	        {
		        return;
	        }

	        if (bAccelerometer==false)
	        {
		        bAccelerometer=true;
                ho.hoAdRunHeader.startJoystickAcc();
            }
        }
        void stopAccelerometer(CActExtension act)
        {
	        if (bAccelerometer==true)
	        {
		        bAccelerometer=false;
                ho.hoAdRunHeader.stopJoystickAcc();
	        }
        }
        void startStopTouch(CActExtension act)
        {
	        CRunApp rhApp=ho.hoAdRunHeader.rhApp;
	        if (rhApp.parentApp!=null)
	        {
		        return;
	        }
	        if (rhApp.frame.joystick!=CRunFrame.JOYSTICK_EXT)
	        {
		        return;
	        }
	
	        int joy=act.getParamExpression(rh, 0);
	        int fire1=act.getParamExpression(rh, 1);
	        int fire2=act.getParamExpression(rh, 2);
	        int leftHanded=act.getParamExpression(rh, 3);
	
	        int flags=0;
	        if (fire1!=0)
	        {
		        flags=CJoystick.JFLAG_FIRE1;
	        }
	        if (fire2!=0)
	        {
		        flags|=CJoystick.JFLAG_FIRE2;
	        }
	        if (joy!=0)
	        {
		        flags|=CJoystick.JFLAG_JOYSTICK;
	        }
	        if (leftHanded!=0)
	        {
		        flags|=CJoystick.JFLAG_LEFTHANDED;
	        }
	        if ((flags&(CJoystick.JFLAG_FIRE1|CJoystick.JFLAG_FIRE2|CJoystick.JFLAG_JOYSTICK))!=0)
	        {
                ho.hoAdRunHeader.joystick.reset(flags);
		        if (xJoystick!=POS_NOTDEFINED)
		        {
			        ho.hoAdRunHeader.joystick.setXPosition(CJoystick.JFLAG_JOYSTICK, xJoystick);
		        }
		        else 
		        {
			        xJoystick=ho.hoAdRunHeader.joystick.imagesX[CJoystick.KEY_JOYSTICK];
		        }

		        if (yJoystick!=POS_NOTDEFINED)
		        {
			        ho.hoAdRunHeader.joystick.setYPosition(CJoystick.JFLAG_JOYSTICK, yJoystick);
		        }
		        else 
		        {
			        yJoystick=ho.hoAdRunHeader.joystick.imagesY[CJoystick.KEY_JOYSTICK];
		        }

		        if (xFire1!=POS_NOTDEFINED)
		        {
			        ho.hoAdRunHeader.joystick.setXPosition(CJoystick.JFLAG_FIRE1, xFire1);
		        }
		        else 
		        {
			        xFire1=ho.hoAdRunHeader.joystick.imagesX[CJoystick.KEY_FIRE1];
		        }
		
		        if (yFire1!=POS_NOTDEFINED)
		        {
			        ho.hoAdRunHeader.joystick.setYPosition(CJoystick.JFLAG_FIRE1, yFire1);
		        }
		        else 
		        {
			        yFire1=ho.hoAdRunHeader.joystick.imagesY[CJoystick.KEY_FIRE1];
		        }

		        if (xFire2!=POS_NOTDEFINED)
		        {
			        ho.hoAdRunHeader.joystick.setXPosition(CJoystick.JFLAG_FIRE2, xFire2);
		        }
		        else 
		        {
			        xFire2=ho.hoAdRunHeader.joystick.imagesX[CJoystick.KEY_FIRE2];
		        }
		
		        if (yFire2!=POS_NOTDEFINED)
		        {
			        ho.hoAdRunHeader.joystick.setXPosition(CJoystick.JFLAG_FIRE2, yFire2);
		        }
		        else 
		        {
			        yFire2=ho.hoAdRunHeader.joystick.imagesY[CJoystick.KEY_FIRE2];
		        }
		
		        bJoystick=true;
	        }
	        else
	        {
		        ho.hoAdRunHeader.joystick=null;
		        bJoystick=false;
	        }
        }
        void setJoyPosition(CActExtension act)
        {
	        CPositionInfo pos=act.getParamPosition(rh, 0);
	        xJoystick=pos.x;
	        yJoystick=pos.y;
	        if (bJoystick)
	        {
		        ho.hoAdRunHeader.joystick.setXPosition(CJoystick.JFLAG_JOYSTICK, xJoystick);
		        ho.hoAdRunHeader.joystick.setYPosition(CJoystick.JFLAG_JOYSTICK, yJoystick);
	        }
        }
        void setFire1Position(CActExtension act)
        {
	        CPositionInfo pos=act.getParamPosition(rh, 0);
	        xFire1=pos.x;
	        yFire1=pos.y;
	        if (bJoystick)
	        {
		        ho.hoAdRunHeader.joystick.setXPosition(CJoystick.JFLAG_FIRE1, xFire1);
		        ho.hoAdRunHeader.joystick.setYPosition(CJoystick.JFLAG_FIRE1, yFire1);
	        }
        }
        void setFire2Position(CActExtension act)
        {
	        CPositionInfo pos=act.getParamPosition(rh, 0);
	        xFire2=pos.x;
	        yFire2=pos.y;
	        if (bJoystick)
	        {
		        ho.hoAdRunHeader.joystick.setXPosition(CJoystick.JFLAG_FIRE2, xFire2);
		        ho.hoAdRunHeader.joystick.setYPosition(CJoystick.JFLAG_FIRE2, yFire2);
	        }
        }
        void setXJoystick(CActExtension act)
        {
	        xJoystick=act.getParamExpression(rh, 0);
	        if (bJoystick)
	        {
		        ho.hoAdRunHeader.joystick.setXPosition(CJoystick.JFLAG_JOYSTICK, xJoystick);
	        }
        }
        void setYJoystick(CActExtension act)
        {
	        yJoystick=act.getParamExpression(rh, 0);
	        if (bJoystick)
	        {
		        ho.hoAdRunHeader.joystick.setYPosition(CJoystick.JFLAG_JOYSTICK, yJoystick);
	        }
        }
        void setXFire1(CActExtension act)
        {
	        xFire1=act.getParamExpression(rh, 0);
	        if (bJoystick)
	        {
		        ho.hoAdRunHeader.joystick.setXPosition(CJoystick.JFLAG_FIRE1, xFire1);
	        }
        }
        void setYFire1(CActExtension act)
        {
	        yFire1=act.getParamExpression(rh, 0);
	        if (bJoystick)
	        {
		        ho.hoAdRunHeader.joystick.setYPosition(CJoystick.JFLAG_FIRE1, yFire1);
	        }
        }
        void setXFire2(CActExtension act)
        {
	        xFire2=act.getParamExpression(rh, 0);
	        if (bJoystick)
	        {
		        ho.hoAdRunHeader.joystick.setXPosition(CJoystick.JFLAG_FIRE2, xFire2);
	        }
        }
        void setYFire2(CActExtension act)
        {
	        yFire2=act.getParamExpression(rh, 0);
	        if (bJoystick)
	        {
		        ho.hoAdRunHeader.joystick.setXPosition(CJoystick.JFLAG_FIRE2, yFire2);
	        }
        }
        void setJoyMask(CActExtension act)
        {
	        int mask=act.getParamExpression(rh, 0);
	        ho.hoAdRunHeader.rhJoystickMask=(byte)mask;
        }

        public override CValue expression(int num)
        {
            int ret = 0;
            switch (num)
            {
                case EXP_XJOYSTICK:
                    ret = xJoystick;
                    break;
                case EXP_YJOYSTICK:
                    ret = yJoystick;
                    break;
                case EXP_XFIRE1:
                    ret = xFire1;
                    break;
                case EXP_YFIRE1:
                    ret = yFire1;
                    break;
                case EXP_XFIRE2:
                    ret = xFire2;
                    break;
                case EXP_YFIRE2:
                    ret = yFire2;
                    break;
            }
            return new CValue(ret);
        }
    }
}