﻿//----------------------------------------------------------------------------------
//
// CRunKcArray: array object
//
//greyhill
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;
using RuntimeXNA.Application;

namespace RuntimeXNA.Extensions
{
    class CRunKcArray : CRunExtension
    {
        const int ARRAY_GLOBAL = 0x0008;
        const int ARRAY_TYPENUM = 0x0001;
        const int ARRAY_TYPETXT = 0x0002;
        const int INDEX_BASE1 = 0x0004;

        const int CND_INDEXAEND = 0;
        const int CND_INDEXBEND = 1;
        const int CND_INDEXCEND = 2;
        const int ACT_SETINDEXA = 0;
        const int ACT_SETINDEXB = 1;
        const int ACT_SETINDEXC = 2;
        const int ACT_ADDINDEXA = 3;
        const int ACT_ADDINDEXB = 4;
        const int ACT_ADDINDEXC = 5;
        const int ACT_WRITEVALUE = 6;
        const int ACT_WRITESTRING = 7;
        const int ACT_CLEARARRAY = 8;
        const int ACT_LOAD = 9;
        const int ACT_LOADSELECTOR = 10;
        const int ACT_SAVE = 11;
        const int ACT_SAVESELECTOR = 12;
        const int ACT_WRITEVALUE_X = 13;
        const int ACT_WRITEVALUE_XY = 14;
        const int ACT_WRITEVALUE_XYZ = 15;
        const int ACT_WRITESTRING_X = 16;
        const int ACT_WRITESTRING_XY = 17;
        const int ACT_WRITESTRING_XYZ = 18;
        const int EXP_INDEXA = 0;
        const int EXP_INDEXB = 1;
        const int EXP_INDEXC = 2;
        const int EXP_READVALUE = 3;
        const int EXP_READSTRING = 4;
        const int EXP_READVALUE_X = 5;
        const int EXP_READVALUE_XY = 6;
        const int EXP_READVALUE_XYZ = 7;
        const int EXP_READSTRING_X = 8;
        const int EXP_READSTRING_XY = 9;
        const int EXP_READSTRING_XYZ = 10;
        const int EXP_DIMX = 11;
        const int EXP_DIMY = 12;
        const int EXP_DIMZ = 13;

        public KcArrayData pArray;

        public override int getNumberOfConditions()
        {
            return 3;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            CRun rhPtr = this.ho.hoAdRunHeader;

            int lDimensionX = file.readAInt();
            int lDimensionY = file.readAInt();
            int lDimensionZ = file.readAInt();
            int lFlags = file.readAInt();

            KcArrayCGlobalDataList pData = null;
            if ((lFlags & ARRAY_GLOBAL) != 0)
            {
                CExtStorage pExtData = rhPtr.getStorage(ho.hoIdentifier);
                if (pExtData == null) //first global object of this type
                {
                    pArray = new KcArrayData(lFlags, lDimensionX, lDimensionY, lDimensionZ);
                    pData = new KcArrayCGlobalDataList();
                    pData.AddObject(this);
                    rhPtr.addStorage(pData, ho.hoIdentifier);
                }
                else
                {
                    pData = (KcArrayCGlobalDataList)pExtData;
                    KcArrayData found = pData.FindObject(ho.hoOiList.oilName);
                    if (found != null) //found array object of same name
                    {
                        pArray = found; //share data
                    }
                    else
                    {
                        pArray = new KcArrayData(lFlags, lDimensionX, lDimensionY, lDimensionZ);
                        pData.AddObject(this);
                    }
                }
            }
            else
            {
                pArray = new KcArrayData(lFlags, lDimensionX, lDimensionY, lDimensionZ);
            }
            return true;
        }

        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CND_INDEXAEND:
                    return EndIndexA();
                case CND_INDEXBEND:
                    return EndIndexB();
                case CND_INDEXCEND:
                    return EndIndexC();
            }
            return false;
        }

        private bool EndIndexA()
        {
            if (pArray.lIndexA >= pArray.lDimensionX - 1)
            {
                return true;
            }
            return false;
        }

        private bool EndIndexB()
        {
            if (pArray.lIndexB >= pArray.lDimensionY - 1)
            {
                return true;
            }
            return false;
        }
        private bool EndIndexC()
        {
            if (pArray.lIndexC >= pArray.lDimensionZ - 1)
            {
                return true;
            }
            return false;
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_SETINDEXA:
                    SetIndexA(act.getParamExpression(rh, 0));
                    break;
                case ACT_SETINDEXB:
                    SetIndexB(act.getParamExpression(rh, 0));
                    break;
                case ACT_SETINDEXC:
                    SetIndexC(act.getParamExpression(rh, 0));
                    break;
                case ACT_ADDINDEXA:
                    IncIndexA();
                    break;
                case ACT_ADDINDEXB:
                    IncIndexB();
                    break;
                case ACT_ADDINDEXC:
                    IncIndexC();
                    break;
                case ACT_WRITEVALUE:
                    WriteValue(act.getParamExpression(rh, 0));
                    break;
                case ACT_WRITESTRING:
                    WriteString(act.getParamExpString(rh, 0));
                    break;
                case ACT_CLEARARRAY:
                    ClearArray();
                    break;
                case ACT_LOAD:
                    break;
                case ACT_LOADSELECTOR:
                    break;
                case ACT_SAVE:
                    break;
                case ACT_SAVESELECTOR:
                    break;
                case ACT_WRITEVALUE_X:
                    break;
                case ACT_WRITEVALUE_XY:
                    break;
                case ACT_WRITEVALUE_XYZ:
                    break;
                case ACT_WRITESTRING_X:
                    break;
                case ACT_WRITESTRING_XY:
                    break;
                case ACT_WRITESTRING_XYZ:
                    break;
            }
        }

        private void SetIndexA(int i)
        {
            if ((pArray.lFlags & INDEX_BASE1) != 0)
            {
                pArray.lIndexA = i - 1;
            }
            else
            {
                pArray.lIndexA = i;
            }
        }
        private void SetIndexB(int i)
        {
            if ((pArray.lFlags & INDEX_BASE1) != 0)
            {
                pArray.lIndexB = i - 1;
            }
            else
            {
                pArray.lIndexB = i;
            }
        }
        private void SetIndexC(int i)
        {
            if ((pArray.lFlags & INDEX_BASE1) != 0)
            {
                pArray.lIndexC = i - 1;
            }
            else
            {
                pArray.lIndexC = i;
            }
        }
        private void IncIndexA()
        {
            pArray.lIndexA++;
        }

        private void IncIndexB()
        {
            pArray.lIndexB++;
        }
        private void IncIndexC()
        {
            pArray.lIndexC++;
        }
        private void WriteValue(int value)
        {
            WriteValueXYZ(value, pArray.lIndexA, pArray.lIndexB, pArray.lIndexC);
        }
        private void WriteString(String value)
        {
            WriteStringXYZ(value, pArray.lIndexA, pArray.lIndexB, pArray.lIndexC);
        }
        private void ClearArray()
        {
            pArray.Clean();
        }
        private void WriteValue_X(int value, int x)
        {
            x -= pArray.oneBased();
            WriteValueXYZ(value, x, pArray.lIndexB, pArray.lIndexC);
        }
        private void WriteValue_XY(int value, int x, int y)
        {
            x -= pArray.oneBased();
            y -= pArray.oneBased();
            WriteValueXYZ(value, x, y, pArray.lIndexC);
        }
        private void WriteValue_XYZ(int value, int x, int y, int z)
        {
            x -= pArray.oneBased();
            y -= pArray.oneBased();
            z -= pArray.oneBased();
            WriteValueXYZ(value, x, y, z);
        }
        private void WriteValueXYZ(int value, int x, int y, int z)
        {
            //x,y,z should be fixed for 1-based index if used before this function
            if ((x < 0) || (y < 0) || (z < 0))
            {
                return;
            }
            if ((pArray.lFlags & ARRAY_TYPENUM) != 0)
            {
                // Expand if required
                if ((x >= pArray.lDimensionX) || (y >= pArray.lDimensionY) || (z >= pArray.lDimensionZ))
                {
                    int newDimX = Math.Max(pArray.lDimensionX, x + 1);
                    int newDimY = Math.Max(pArray.lDimensionY, y + 1);
                    int newDimZ = Math.Max(pArray.lDimensionZ, z + 1);
                    pArray.Expand(newDimX, newDimY, newDimZ);
                }
                //write
                pArray.lIndexA = x;
                pArray.lIndexB = y;
                pArray.lIndexC = z;
                pArray.numberArray[z * pArray.lDimensionY * pArray.lDimensionX + y * pArray.lDimensionX + x] = value;
            }
        }

        private void WriteString_X(String value, int x)
        {
            x -= pArray.oneBased();
            WriteStringXYZ(value, x, pArray.lIndexB, pArray.lIndexC);
        }
        private void WriteString_XY(String value, int x, int y)
        {
            x -= pArray.oneBased();
            y -= pArray.oneBased();
            WriteStringXYZ(value, x, y, pArray.lIndexC);
        }
        private void WriteString_XYZ(String value, int x, int y, int z)
        {
            x -= pArray.oneBased();
            y -= pArray.oneBased();
            z -= pArray.oneBased();
            WriteStringXYZ(value, x, y, z);
        }
        private void WriteStringXYZ(String value, int x, int y, int z)
        {
            //x,y,z should be fixed for 1-based index if used before this function
            if ((x < 0) || (y < 0) || (z < 0))
            {
                return;
            }
            if ((pArray.lFlags & ARRAY_TYPETXT) != 0)
            {
                // Expand if required
                if ((x >= pArray.lDimensionX) || (y >= pArray.lDimensionY) || (z >= pArray.lDimensionZ))
                {
                    int newDimX = Math.Max(pArray.lDimensionX, x + 1);
                    int newDimY = Math.Max(pArray.lDimensionY, y + 1);
                    int newDimZ = Math.Max(pArray.lDimensionZ, z + 1);
                    pArray.Expand(newDimX, newDimY, newDimZ);
                }
                //write
                pArray.lIndexA = x;
                pArray.lIndexB = y;
                pArray.lIndexC = z;
                pArray.stringArray[z * pArray.lDimensionY * pArray.lDimensionX + y * pArray.lDimensionX + x] = value;
            }
        }

        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_INDEXA:
                    return IndexA();
                case EXP_INDEXB:
                    return IndexB();
                case EXP_INDEXC:
                    return IndexC();
                case EXP_READVALUE:
                    return ReadValue();
                case EXP_READSTRING:
                    return ReadString();
                case EXP_READVALUE_X:
                    return ReadValue_X(ho.getExpParam().getInt());
                case EXP_READVALUE_XY:
                    return ReadValue_XY(ho.getExpParam().getInt(),
                        ho.getExpParam().getInt());
                case EXP_READVALUE_XYZ:
                    return ReadValue_XYZ(ho.getExpParam().getInt(),
                        ho.getExpParam().getInt(),
                        ho.getExpParam().getInt());
                case EXP_READSTRING_X:
                    return ReadString_X(ho.getExpParam().getInt());
                case EXP_READSTRING_XY:
                    return ReadString_XY(ho.getExpParam().getInt(),
                        ho.getExpParam().getInt());
                case EXP_READSTRING_XYZ:
                    return ReadString_XYZ(ho.getExpParam().getInt(),
                        ho.getExpParam().getInt(),
                        ho.getExpParam().getInt());
                case EXP_DIMX:
                    return Exp_DimX();
                case EXP_DIMY:
                    return Exp_DimY();
                case EXP_DIMZ:
                    return Exp_DimZ();
            }
            return new CValue(0);//won't be used
        }
        private CValue IndexA()
        {
            if ((pArray.lFlags & INDEX_BASE1) != 0)
            {
                return new CValue(pArray.lIndexA + 1);
            }
            else
            {
                return new CValue(pArray.lIndexA);
            }
        }
        private CValue IndexB()
        {
            if ((pArray.lFlags & INDEX_BASE1) != 0)
            {
                return new CValue(pArray.lIndexB + 1);
            }
            else
            {
                return new CValue(pArray.lIndexB);
            }
        }
        private CValue IndexC()
        {
            if ((pArray.lFlags & INDEX_BASE1) != 0)
            {
                return new CValue(pArray.lIndexC + 1);
            }
            else
            {
                return new CValue(pArray.lIndexC);
            }
        }
        private CValue ReadValue()
        {
            return ReadValueXYZ(pArray.lIndexA,
                    pArray.lIndexB,
                    pArray.lIndexC);
        }
        private CValue ReadString()
        {
            return ReadStringXYZ(pArray.lIndexA,
                    pArray.lIndexB,
                    pArray.lIndexC);
        }

        private CValue ReadValue_X(int x)
        {
            return ReadValueXYZ(x - pArray.oneBased(),
                    pArray.lIndexB,
                    pArray.lIndexC);
        }
        private CValue ReadValue_XY(int x, int y)
        {
            return ReadValueXYZ(x - pArray.oneBased(),
                    y - pArray.oneBased(),
                    pArray.lIndexC);
        }
        private CValue ReadValue_XYZ(int x, int y, int z)
        {
            return ReadValueXYZ(x - pArray.oneBased(),
                    y - pArray.oneBased(),
                    z - pArray.oneBased());
        }
        private CValue ReadValueXYZ(int x, int y, int z)
        {
            //x y z should be fixed for 1-based, if so
            if ((x < 0) || (y < 0) || (z < 0))
            {
                return new CValue(0);
            }
            if ((pArray.lFlags & ARRAY_TYPENUM) != 0)
            {
                if ((x < pArray.lDimensionX) && (y < pArray.lDimensionY) && (z < pArray.lDimensionZ))
                {
                    return new CValue(pArray.numberArray[z * pArray.lDimensionY * pArray.lDimensionX + y * pArray.lDimensionX + x]);
                }
            }
            return new CValue(0);
        }
        private CValue ReadString_X(int x)
        {
            return ReadStringXYZ(x - pArray.oneBased(),
                    pArray.lIndexB,
                    pArray.lIndexC);
        }
        private CValue ReadString_XY(int x, int y)
        {
            return ReadStringXYZ(x - pArray.oneBased(),
                    y - pArray.oneBased(),
                    pArray.lIndexC);
        }
        private CValue ReadString_XYZ(int x, int y, int z)
        {
            return ReadStringXYZ(x - pArray.oneBased(),
                    y - pArray.oneBased(),
                    z - pArray.oneBased());
        }
        private CValue ReadStringXYZ(int x, int y, int z)
        {
            //x y z should be fixed for 1-based, if so
            if ((x < 0) || (y < 0) || (z < 0))
            {
                return new CValue(0);
            }
            if ((pArray.lFlags & ARRAY_TYPETXT) != 0)
            {
                if ((x < pArray.lDimensionX) && (y < pArray.lDimensionY) && (z < pArray.lDimensionZ))
                {
	                string r = pArray.stringArray[z*pArray.lDimensionY*pArray.lDimensionX+y*pArray.lDimensionX+x];
                    if (r != null)
                    {
                        return new CValue(r);
                    }
                }
            }
            return new CValue("");
        }
        private CValue Exp_DimX()
        {
            return new CValue(pArray.lDimensionX);
        }
        private CValue Exp_DimY()
        {
            return new CValue(pArray.lDimensionY);
        }
        private CValue Exp_DimZ()
        {
            return new CValue(pArray.lDimensionZ);
        }
    

    }
    class KcArrayCGlobalDataList : CExtStorage 
    {
        //should be equal, comparable
        public CArrayList dataList;
        public CArrayList names;    
        
        public KcArrayCGlobalDataList() 
        {
            dataList = new CArrayList();
            names = new CArrayList();
        }
        public KcArrayData FindObject(String objectName)
        {
            for (int i = 0; i < names.size(); i++)
            {
                 if ( string.Compare((string)names.get(i), objectName) == 0)
                {
                    return (KcArrayData)dataList.get(i);
                }
            }
            return null;
        }
        public void AddObject(CRunKcArray o)
        {
            dataList.add(o.pArray);
            names.add(o.ho.hoOiList.oilName);
        }        
    }

    class KcArrayData 
    {
        const int ARRAY_TYPENUM = 0x0001;
        const int ARRAY_TYPETXT = 0x0002;
        const int INDEX_BASE1 = 0x0004;

            
        public int			lDimensionX;
        public int lDimensionY;
        public int lDimensionZ;
        public int lFlags;
        //indicies will never be 1-based
        public int lIndexA;
        public int lIndexB;
        public int lIndexC;
         //int			lArraySize;
        public int[] numberArray;
        public String[] stringArray;
        
        public KcArrayData(int flags, int dimX, int dimY, int dimZ) 
        {
            dimX = Math.Max(1, dimX);
            dimY = Math.Max(1, dimY);
            dimZ = Math.Max(1, dimZ);
            
            lFlags = flags;
            lDimensionX = dimX;
            lDimensionY = dimY;
            lDimensionZ = dimZ;
            if ((flags & ARRAY_TYPENUM) != 0)
            {
                numberArray = new int[dimZ*dimY*dimX];
            }
            else if ((flags & ARRAY_TYPETXT) != 0)
            {
                stringArray = new String[dimZ*dimY*dimX];
            }
        } 
        public int oneBased()
        {
            if ((lFlags & INDEX_BASE1) != 0)
            {
                return 1;
            }
            return 0;
        }
        public void Expand(int newX, int newY, int newZ)
        {
            //inputs should always be equal or larger than current dimensions
            if ((lFlags & ARRAY_TYPENUM) != 0)
            {
                int[] temp = numberArray;
                numberArray = new int[newZ*newY*newX];
                for (int z = 0; z < lDimensionZ; z++)
                {
                    for (int y = 0; y < lDimensionY; y++)
                    {
                        for (int x = 0; x < lDimensionX; x++)
                        {
	                        numberArray[z*newY*newX+y*newX+x] = temp[z*lDimensionY*lDimensionX+y*lDimensionX+x];
                        }
                    }
                }
            }
            else if ((lFlags & ARRAY_TYPETXT) != 0)
            {
                String[] temp = stringArray;
                stringArray = new String[newZ*newY*newX];
                for (int z = 0; z < lDimensionZ; z++)
                {
                    for (int y = 0; y < lDimensionY; y++)
                    {
                        for (int x = 0; x < lDimensionX; x++)
                        {
	                        stringArray[z*newY*newX+y*newX+x] = temp[z*lDimensionY*lDimensionX+y*lDimensionX+x];
                        }
                    }
                }           
            }
            lDimensionX = newX;
            lDimensionY = newY;
            lDimensionZ = newZ;
        }
        public void Clean()
        {
            if ((lFlags & ARRAY_TYPENUM) != 0)
            {
                for (int z = 0; z < lDimensionZ; z++)
                {
                    for (int y = 0; y < lDimensionY; y++)
                    {
                        for (int x = 0; x < lDimensionX; x++)
                        {
	                        numberArray[z*lDimensionY*lDimensionX+y*lDimensionX+x] = 0;
                        }
                    }
                }
            }
            else if ((lFlags & ARRAY_TYPETXT) != 0)
            {
                for (int z = 0; z < lDimensionX; z++)
                {
                    for (int y = 0; y < lDimensionY; y++)
                    {
                        for (int x = 0; x < lDimensionX; x++)
                        {
	                        stringArray[z*lDimensionY*lDimensionX+y*lDimensionX+x] = null;
                        }
                    }
                }           
            }
        }
    }
}
