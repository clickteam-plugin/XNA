//----------------------------------------------------------------------------------
//
// CRUNMultipleTouch
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Input.Touch;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;

namespace RuntimeXNA.Extensions 
{
    class CRunMultipleTouch : CRunExtension, ITouches
    {
        const int CND_NEWTOUCH=0;
        const int CND_ENDTOUCH=1;
        const int CND_NEWTOUCHANY=2;
        const int CND_ENDTOUCHANY=3;
        const int CND_TOUCHMOVED=4;
        const int CND_TOUCHACTIVE=5;
        const int ACT_SETORIGINX=0;
        const int ACT_SETORIGINY=1;
        const int EXP_GETNUMBER=0;
        const int EXP_GETLAST=1;
        const int EXP_MTGETX=2;
        const int EXP_MTGETY=3;
        const int EXP_GETLASTNEWTOUCH=4;
        const int EXP_GETLASTENDTOUCH=5;
        const int EXP_GETORIGINX=6;
        const int EXP_GETORIGINY=7;
        const int EXP_GETDELTAX=8;
        const int EXP_GETDELTAY=9;
        const int EXP_GETTOUCHANGLE=10;
        const int EXP_GETDISTANCE = 11;

	    int newTouchCount;
	    int endTouchCount;
	    int movedTouchCount;
	    int[] touchesID;
	    int[] touchesX;
	    int[] touchesY;
	    int[] startX;
	    int[] startY;
	    int[] dragX;
	    int[] dragY;
	    int[] touchesNew;
	    int[] touchesEnd;
	    int lastTouch;
	    int lastNewTouch;
	    int lastEndTouch;
        int maxTouches;

        public override int getNumberOfConditions()
        {
            return 6;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            maxTouches = ho.hoAdRunHeader.rhApp.numberOfTouches;
            touchesID=new int[maxTouches];
            touchesX = new int[maxTouches];
            touchesY = new int[maxTouches];
            startX = new int[maxTouches];
            startY = new int[maxTouches];
            dragX = new int[maxTouches];
            dragY = new int[maxTouches];
            touchesNew = new int[maxTouches];
            touchesEnd = new int[maxTouches];

            newTouchCount = -1;
            endTouchCount = -1;
            movedTouchCount = -1;
            lastNewTouch = -1;
            lastEndTouch = -1;
            lastTouch = -1;

            int n;
            for (n = 0; n < maxTouches; n++)
            {
                touchesID[n] = -1;
                touchesX[n] = -1;
                touchesY[n] = -1;
                touchesNew[n] = 0;
                touchesEnd[n] = 0;
                startX[n] = 0;
                startY[n] = 0;
                dragX[n] = 0;
                dragY[n] = 0;
            }
            ho.hoAdRunHeader.touches = this;
            return true;
        }

        public override void destroyRunObject(bool bFast)
        {
            ho.hoAdRunHeader.touches = null;
        }

        public override int handleRunObject()
        {
            int n;
            for (n = 0; n < maxTouches; n++)
            {
                if (touchesNew[n] > 0)
                {
                    touchesNew[n]--;
                }
                if (touchesEnd[n] > 0)
                {
                    touchesEnd[n]--;
                }
            }
            return 0;
        }

        public bool touchBegan(TouchLocation touch)
        {
	        int n;
	        for (n=0; n<maxTouches; n++)
	        {
		        if (touchesID[n]==touch.Id)
		        {
			        break;
		        }
		        if (touchesID[n]<0)
		        {
			        break;
		        }
	        }
	        if (n<maxTouches && touchesID[n]<0)
	        {
		        touchesID[n]=touch.Id;
		        touchesX[n]=(int)touch.Position.X;
                touchesY[n] = (int)touch.Position.Y;
                startX[n] = (int)touch.Position.X;
                dragX[n] = (int)touch.Position.X;
                startY[n] = (int)touch.Position.Y;
                dragY[n] = (int)touch.Position.Y;
		        touchesNew[n]=2;
		        lastTouch=n;
		        lastNewTouch=n;
		        newTouchCount=ho.getEventCount();
		        ho.generateEvent(CND_NEWTOUCH, 0);
		        ho.generateEvent(CND_NEWTOUCHANY, 0);
	        }
	        return true;
        }

        public void touchMoved(TouchLocation touch)
        {
	        int n;
	        for (n=0; n<maxTouches; n++)
	        {
		        if (touchesID[n]==touch.Id)
		        {
			        touchesX[n]=(int)touch.Position.X;
			        touchesY[n]=(int)touch.Position.Y;
			        dragX[n]=(int)touch.Position.X;
			        dragY[n]=(int)touch.Position.Y;
			        lastTouch=n;
			        ho.generateEvent(CND_TOUCHMOVED, 0);
		        }
	        }
        }

        public void touchEnded(TouchLocation touch)
        {
	        int n;
	        for (n=0; n<maxTouches; n++)
	        {
		        if (touchesID[n]==touch.Id)
		        {
			        touchesX[n]=(int)touch.Position.X;
			        touchesY[n]=(int)touch.Position.Y;
			        dragX[n]=(int)touch.Position.X;
			        dragY[n]=(int)touch.Position.Y;
			        touchesID[n]=-1;
			        touchesEnd[n]=2;
			        lastTouch=n;
			        lastEndTouch=n;
			        endTouchCount=ho.getEventCount();
			        ho.generateEvent(CND_ENDTOUCH, 0);
			        ho.generateEvent(CND_ENDTOUCHANY, 0);
		        }
	        }
        }

        public void touchCancelled(TouchLocation touch)
        {
            touchEnded(touch);
        }

        public override bool condition(int num, CCndExtension cnd)
        {
	        switch (num)
	        {
		        case CND_NEWTOUCH:
			        return cndNewTouch(cnd);
		        case CND_ENDTOUCH:
			        return cndEndTouch(cnd);
		        case CND_NEWTOUCHANY:
			        return cndNewTouchAny(cnd);
		        case CND_ENDTOUCHANY:
			        return cndEndTouchAny(cnd);
		        case CND_TOUCHMOVED:
			        return cndTouchMoved(cnd);
		        case CND_TOUCHACTIVE:
			        return cndTouchActive(cnd);
	        }
	        return false;
        }

        bool cndNewTouch(CCndExtension cnd)
        {
	        int touch=cnd.getParamExpression(rh, 0);
	        bool bTest=false;
	        if (touch<0)
	        {
		        bTest=true;
	        }
	        if (touch>=0 && touch<maxTouches)
	        {
		        if (touchesNew[touch]!=0)
		        {
			        bTest=true;
		        }
	        }
	        if (bTest)
	        {
		        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		        {
			        return true;
		        }
		        if (ho.getEventCount()==newTouchCount)
		        {
			        return true;
		        }
	        }
	        return false;
        }

        bool cndNewTouchAny(CCndExtension cnd)
        {
	        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
	        {
		        return true;
	        }
	        if (ho.getEventCount() == newTouchCount)
	        {
		        return true;
	        }
	        return false;
        }

        bool cndEndTouchAny(CCndExtension cnd)
        {
	        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
	        {
		        return true;
	        }
	        if (ho.getEventCount() == newTouchCount)
	        {
		        return true;
	        }
	        return false;
        }

        bool cndEndTouch(CCndExtension cnd)
        {
	        int touch=cnd.getParamExpression(rh, 0);
	        bool bTest=false;
	        if (touch<0)
	        {
		        bTest=true;
	        }
	        if (touch>=0 && touch<maxTouches)
	        {
		        if (touchesEnd[touch]!=0)
		        {
			        bTest=true;
		        }
	        }
	        if (bTest)
	        {
		        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		        {
			        return true;
		        }
		        if (ho.getEventCount() == endTouchCount)
		        {
			        return true; 
		        }
	        }
	        return false;
        }

        bool cndTouchMoved(CCndExtension cnd)
        {
	        int touch=cnd.getParamExpression(rh, 0);
	        bool bTest=false;
	        if (touch<0)
	        {
		        bTest=true;
	        }
	        if (touch==lastTouch)
	        {
		        bTest=true;
	        }
	        if (bTest)
	        {
		        if ((ho.hoFlags & CObject.HOF_TRUEEVENT) != 0)
		        {
			        return true;
		        }
		        if (ho.getEventCount() == movedTouchCount)
		        {
			        return true;
		        }
	        }
	        return false;
        }

        bool cndTouchActive(CCndExtension cnd)
        {
	        int touch=cnd.getParamExpression(rh, 0);
	        if (touch>=0 && touch<maxTouches)
	        {
		        if (touchesID[touch]>=0)
		        {
			        return true;
		        }
	        }
	        return false;
        }

        public override void action(int num, CActExtension act)
        {
	        switch (num)
	        {
		        case ACT_SETORIGINX:
			        setOriginX(act);
			        break;
		        case ACT_SETORIGINY:
			        setOriginY(act);
			        break;
	        }
        }

        void setOriginX(CActExtension act)
        {
	        int touch=act.getParamExpression(rh, 0);
	        int coord=act.getParamExpression(rh, 1);
	
	        if (touch>=0 && touch<maxTouches)						   
	        {
		        startX[touch]=coord-rh.rhWindowX;
	        }							   
        }
        void setOriginY(CActExtension act)
        {
	        int touch=act.getParamExpression(rh, 0);
	        int coord=act.getParamExpression(rh, 1);
	
	        if (touch>=0 && touch<maxTouches)						   
	        {
		        startY[touch]=coord-rh.rhWindowY;
	        }							   
        }

        public override CValue expression(int num)
        {
	        switch (num)
	        {
		        case EXP_GETNUMBER:
			        return expGetNumber();
		        case EXP_GETLAST:
			        return new CValue(lastTouch);
		        case EXP_MTGETX:
			        return expGetX();
		        case EXP_MTGETY:
			        return expGetY();
		        case EXP_GETLASTNEWTOUCH:
			        return new CValue(lastNewTouch);
		        case EXP_GETLASTENDTOUCH:
			        return new CValue(lastEndTouch);
		        case EXP_GETORIGINX:
			        return expGetOriginX();
		        case EXP_GETORIGINY:
			        return expGetOriginY();
		        case EXP_GETDELTAX:
			        return expGetDeltaX();
		        case EXP_GETDELTAY:
			        return expGetDeltaX();
		        case EXP_GETTOUCHANGLE:
			        return expGetAngle();
		        case EXP_GETDISTANCE:
			        return expGetDistance();
	        }
	        return null;
        }

        CValue expGetNumber()
        {
	        int count=0;
	        int n;
	        for (n=0; n<maxTouches; n++)
	        {
		        if (touchesID[n]>=0)
		        {
			        count++;
		        }
	        }
	        return new CValue(count);
        }
        CValue expGetX()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        return new CValue(touchesX[touch]+rh.rhWindowX);
	        }
	        return new CValue(-1);
        }
        CValue expGetY()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        return new CValue(touchesY[touch]+rh.rhWindowY);
	        }
	        return new CValue(-1);
        }
        CValue expGetOriginX()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        return new CValue(startX[touch]+rh.rhWindowX);
	        }
	        return new CValue(-1);
        }
        CValue expGetOriginY()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        return new CValue(startY[touch]+rh.rhWindowY);
	        }
	        return new CValue(-1);
        }
        CValue expGetDeltaX()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        return new CValue(dragX[touch]-startX[touch]);
	        }
	        return new CValue(-1);
        }
        CValue expGetDeltaY()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        return new CValue(dragY[touch]-startY[touch]);
	        }
	        return new CValue(-1);
        }
        CValue expGetAngle()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        int deltaX=dragX[touch]-startX[touch];
		        int deltaY=dragY[touch]-startY[touch];
		        double angle=Math.Atan2(-deltaY,deltaX)*57.295779513082320876798154814105;
		        if (angle<0)
		        {
			        angle=360.0+angle;
		        }
		        return new CValue((int)angle);
	        }
	        return new CValue(-1);
        }
        CValue expGetDistance()
        {
	        int touch=ho.getExpParam().getInt();
	        if (touch>=0 && touch<maxTouches)
	        {
		        int deltaX=dragX[touch]-startX[touch];
		        int deltaY=dragY[touch]-startY[touch];
		        double distance=Math.Sqrt(deltaX*deltaX+deltaY*deltaY);
		        return new CValue((int)distance);
	        }
            return new CValue(-1);
        }
    }
}
