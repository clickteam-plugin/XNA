﻿//----------------------------------------------------------------------------------
//
// CRunparser: String Parser object
// fin 14/04/09
//greyhill
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;

namespace RuntimeXNA.Extensions
{
    class CRunparser : CRunExtension
    {
        public const int CASE_INSENSITIVE = 0;
        public const int SEARCH_LITERAL = 0;
        const int CND_ISURLSAFE = 0;
        const int ACT_SETSTRING = 0;
        const int ACT_SAVETOFILE = 1;
        const int ACT_LOADFROMFILE = 2;
        const int ACT_APPENDTOFILE = 3;
        const int ACT_APPENDFROMFILE = 4;
        const int ACT_RESETDELIMS = 5;
        const int ACT_ADDDELIM = 6;
        const int ACT_SETDELIM = 7;
        const int ACT_DELETEDELIMINDEX = 8;
        const int ACT_DELETEDELIM = 9;
        const int ACT_SETDEFDELIMINDEX = 10;
        const int ACT_SETDEFDELIM = 11;
        const int ACT_SAVEASCSV = 12;
        const int ACT_LOADFROMCSV = 13;
        const int ACT_SAVEASMMFARRAY = 14;
        const int ACT_LOADFROMMMFARRAY = 15;
        const int ACT_SAVEASDYNAMICARRAY = 16;
        const int ACT_LOADFROMDYNAMICARRAY = 17;
        const int ACT_CASEINSENSITIVE = 18;
        const int ACT_CASESENSITIVE = 19;
        const int ACT_SEARCHLITERAL = 20;
        const int ACT_SEARCHWILDCARDS = 21;
        const int ACT_SAVEASINI = 22;
        const int ACT_LOADFROMINI = 23;
        const int EXP_GETSTRING = 0;
        const int EXP_GETLENGTH = 1;
        const int EXP_LEFT = 2;
        const int EXP_RIGHT = 3;
        const int EXP_MIDDLE = 4;
        const int EXP_NUMBEROFSUBS = 5;
        const int EXP_INDEXOFSUB = 6;
        const int EXP_INDEXOFFIRSTSUB = 7;
        const int EXP_INDEXOFLASTSUB = 8;
        const int EXP_REMOVE = 9;
        const int EXP_REPLACE = 10;
        const int EXP_INSERT = 11;
        const int EXP_REVERSE = 12;
        const int EXP_UPPERCASE = 13;
        const int EXP_LOWERCASE = 14;
        const int EXP_URLENCODE = 15;
        const int EXP_CHR = 16;
        const int EXP_ASC = 17;
        const int EXP_ASCLIST = 18;
        const int EXP_NUMBEROFDELIMS = 19;
        const int EXP_GETDELIM = 20;
        const int EXP_GETDELIMINDEX = 21;
        const int EXP_GETDEFDELIM = 22;
        const int EXP_GETDEFDELIMINDEX = 23;
        const int EXP_LISTCOUNT = 24;
        const int EXP_LISTSETAT = 25;
        const int EXP_LISTINSERTAT = 26;
        const int EXP_LISTAPPEND = 27;
        const int EXP_LISTPREPEND = 28;
        const int EXP_LISTGETAT = 29;
        const int EXP_LISTFIRST = 30;
        const int EXP_LISTLAST = 31;
        const int EXP_LISTFIND = 32;
        const int EXP_LISTCONTAINS = 33;
        const int EXP_LISTDELETEAT = 34;
        const int EXP_LISTSWAP = 35;
        const int EXP_LISTSORTASC = 36;
        const int EXP_LISTSORTDESC = 37;
        const int EXP_LISTCHANGEDELIMS = 38;
        const int EXP_SETSTRING = 39;
        const int EXP_SETVALUE = 40;
        const int EXP_GETMD5 = 41;

        
        String source = "";
        bool caseSensitive;
        bool wildcards;
        CArrayList delims = new CArrayList(); //Strings
        String defaultDelim;
        CArrayList tokensE = new CArrayList(); //parserElement

        public override int getNumberOfConditions()
        {
            return 1;
        }

        private String fixString(String input)
        {
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] < 10)
                {
                    return input.Substring(0, i);
                }
            }
            return input;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            file.setUnicode(false);
            file.skipBytes(4);
            this.source = fixString(file.readAString(1025));
            short nComparison = file.readAShort();
            if (nComparison == CASE_INSENSITIVE)
            {
                this.caseSensitive = false;
            }
            else
            {
                this.caseSensitive = true;
            }
            short nSearchMode = file.readShort();
            if (nSearchMode == SEARCH_LITERAL)
            {
                this.wildcards = false;
            }
            else
            {
                this.wildcards = true;
            }
            return true;
        }

        public void redoTokens()
        {
            this.tokensE.clear();
            String sourceToTest = this.source;
            if (!(sourceToTest.Length==0))
            {
                int lastTokenLocation = 0;
                bool work = true;
                while (work)
                {
                    CArrayList aTokenE = new CArrayList(); //parserElement
                    CArrayList aDelim = new CArrayList(); //String
                    for (int j = 0; j < this.delims.size(); j++)
                    {
                        String delim = (String)this.delims.get(j);
                        int index = getSubstringIndex(sourceToTest, delim, 0);
                        if (index != -1)
                        {
                            aTokenE.add(new parserElement(sourceToTest.Substring(0, index), lastTokenLocation));
                            aDelim.add(delim);
                        }
                    }
                    //pick smallest token
                    int smallestC = Int32.MaxValue;
                    int smallest = -1;
                    for (int j = 0; j < aTokenE.size(); j++)
                    {
                        if (((parserElement)aTokenE.get(j)).text.Length < smallestC)
                        {
                            smallestC = ((parserElement)aTokenE.get(j)).text.Length;
                            smallest = j;
                        }
                    }
                    if (smallest != -1)
                    {
                        this.tokensE.add(aTokenE.get(smallest));
                        sourceToTest = sourceToTest.Substring(
                                ((parserElement)aTokenE.get(smallest)).text.Length +
                                ((String)aDelim.get(smallest)).Length);
                        lastTokenLocation += ((parserElement)aTokenE.get(smallest)).text.Length +
                                ((String)aDelim.get(smallest)).Length;
                    }
                    else
                    {
                        //if at end of search, add remainder
                        this.tokensE.add(new parserElement(sourceToTest, lastTokenLocation));
                        work = false;
                    }
                }
                for (int i = 0; i < this.tokensE.size(); i++)
                {
                    //remove ""
                    parserElement e = (parserElement)this.tokensE.get(i);
                    if (e.text.Length==0)
                    {
                        this.tokensE.remove(i);
                        i--;
                    }
                }
            }
        }

        public int getSubstringIndex(String source, String find, int occurance)
        { //occurance is 0-based
            String theSource = source;
            if (source.Length==0)
            {
                return -1;
            }
            if (!this.caseSensitive)
            {
                theSource = theSource.ToLower();
                find = find.ToLower();
            }
            if (this.wildcards)
            {
                StringTokenizer st = new StringTokenizer(find, "*");
                int ct = st.countTokens();
                String[] asteriskless = new String[ct];
                for (int i = 0; i < ct; i++)
                {
                    asteriskless[i] = st.nextToken();
                }
                int lastOccurance = -1;
                for (int occ = 0; occ <= occurance; occ++)
                {
                    int[] asterisklessLocation = new int[ct];
                    for (int asterisk = 0; asterisk < ct; asterisk++)
                    {
                        for (int i = 0; i < theSource.Length; i++)
                        {
                            String findThis = asteriskless[asterisk];
                            //replace "?" occurances with chars from source
                            for (int j = 0; j < findThis.Length; j++)
                            {
                                if (findThis[j]=='?')
                                {
                                    if (i + j < theSource.Length)
                                    {
                                        findThis = findThis.Substring(0, j) +
                                                theSource.Substring(i + j, 1) +
                                                findThis.Substring(j + 1);
                                    }
                                }
                            }
                            if ((asterisk == 0) || (asterisklessLocation[asterisk - 1] == -1))
                            {
                                asterisklessLocation[asterisk] = theSource.IndexOf(findThis, lastOccurance + 1);
                            }
                            else
                            {
                                asterisklessLocation[asterisk] = theSource.IndexOf(findThis, asterisklessLocation[asterisk - 1]);
                            }
                            if (asterisklessLocation[asterisk] != -1)
                            {
                                i = theSource.Length; //stop
                            }
                        }
                    }
                    //now each int in asterisklessLocation should be in an acsending order (lowest first)
                    //if they are not, then the string wasn't found in the source
                    int last = -1;
                    for (int i = 0; i < ct; i++)
                    {
                        if (asterisklessLocation[i] > last)
                        {
                            last = asterisklessLocation[i];
                        }
                        else
                        {
                            lastOccurance = -1;
                            i = ct; //stop
                        }
                    }
                    if ((occ == 0) || (lastOccurance != -1))
                    {
                        if (asterisklessLocation.Length > 0)
                        {
                            lastOccurance = asterisklessLocation[0];
                        }
                        else
                        {
                            lastOccurance = -1;
                        }
                    }
                }
                return lastOccurance;
            }
            else
            { //no wildcards
                int lastIndex = -1;
                for (int i = 0; i <= occurance; i++)
                {
                    lastIndex = theSource.IndexOf(find, lastIndex + 1);
                }
                return lastIndex;
            }
        }

        public bool substringMatches(String source, String find)
        {
            String theSource = source;
            if (!this.caseSensitive)
            {
                theSource = theSource.ToLower();
                find = find.ToLower();
            }
            if (this.wildcards)
            {
                StringTokenizer st = new StringTokenizer(find, "*");
                int ct = st.countTokens();
                String[] asteriskless = new String[ct];
                for (int i = 0; i < ct; i++)
                {
                    asteriskless[i] = st.nextToken();
                }
                int[] asterisklessLocation = new int[ct];
                for (int asterisk = 0; asterisk < ct; asterisk++)
                {
                    for (int i = 0; i < theSource.Length; i++)
                    {
                        String findThis = asteriskless[asterisk];
                        //replace "?" occurances with chars from source
                        for (int j = 0; j < findThis.Length; j++)
                        {
                            if (findThis[j]=='?')
                            {
                                if (i + j < theSource.Length)
                                {
                                    findThis = findThis.Substring(0, j) +
                                            theSource.Substring(i + j, 1) +
                                            findThis.Substring(j + 1);
                                }
                            }
                        }
                        if ((asterisk == 0) || (asterisklessLocation[asterisk - 1] == -1))
                        {
                            asterisklessLocation[asterisk] = theSource.IndexOf(findThis);
                        }
                        else
                        {
                            asterisklessLocation[asterisk] = theSource.IndexOf(findThis, asterisklessLocation[asterisk - 1]);
                        }
                        if (asterisklessLocation[asterisk] != -1)
                        {
                            i = theSource.Length; //stop
                        }
                    }
                }
                //now each int in asterisklessLocation should be in an acsending order (lowest first)
                //if they are not, then the string wasn't found in the source
                int last = -1;
                bool ok = true;
                for (int i = 0; i < ct; i++)
                {
                    if (asterisklessLocation[i] > last)
                    {
                        last = asterisklessLocation[i];
                    }
                    else
                    {
                        i = ct; //stop
                        ok = false;
                    }
                }
                if ((ok) && (find.Length > 0) && (asterisklessLocation.Length > 0))
                {
                    if (getSubstringIndex(theSource, find, 1) == -1)
                    { //no other occurances
                        if (find[0]=='*')
                        {
                            if (find[find.Length - 1]=='*')
                            {
                                //if it starts with a * and ends with a *
                                return true;
                            }
                            else
                            {
                                //if last element is at the end of the source
                                if (asterisklessLocation[ct - 1] + asteriskless[ct - 1].Length == theSource.Length)
                                {
                                    return true;
                                }
                            }
                        }
                        else
                        {
                            if (asterisklessLocation[0] == 0)
                            {
                                if (find[find.Length - 1]=='*')
                                {
                                    //if it starts with a * and ends with a *
                                    return true;
                                }
                                else
                                {
                                    //if last element is at the end of the source
                                    if (asterisklessLocation[ct - 1] + asteriskless[ct - 1].Length == theSource.Length)
                                    {
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else
            { //no wildcards
                if ((theSource.Length == find.Length) && (theSource.IndexOf(find, 0) == 0))
                {
                    return true;
                }
            }
            return false;
        }

        bool isLetterOrDigit(char c)
        {
            if (c >= 'A' && c <= 'Z')
            {
                return true;
            }
            if (c >= 'a' && c <= 'z')
            {
                return true;
            }
            if (c >= '0' && c <= '9')
            {
                return true;
            }
            if (c == '_')
            {
                return true;
            }
            return false;
        }
        public override bool condition(int num, CCndExtension cnd)
        {
            if (num == CND_ISURLSAFE)
            {
                for (int index = 0; index < source.Length; index++)
                {
                    while (!isLetterOrDigit(source[index]))
                    {
                        if (source[index] == '+')
                        {
                            break;
                        }
                        else
                        {
                            if (source[index] == '%')
                            {
                                if (source.Length > index + 2)
                                {
                                    if (isLetterOrDigit(source[index + 1])
                                            && isLetterOrDigit(source[index + 2]))
                                    {
                                        index = index + 2;
                                    }
                                    else
                                    {
                                        return false;
                                    }
                                    break;
                                }
                                else
                                {
                                    return false;
                                }
                            }
                            else
                            {
                                return false;
                            }
                        }
                    }
                }
                return true;
            }
            return false;
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_SETSTRING:
                    source = act.getParamExpString(rh, 0);
                    redoTokens();
                    break;
                case ACT_SAVETOFILE:
                    break;
                case ACT_LOADFROMFILE:
                    break;
                case ACT_APPENDTOFILE:
                    break;
                case ACT_APPENDFROMFILE:
                    break;
                case ACT_RESETDELIMS:
                    delims.clear();
                    break;
                case ACT_ADDDELIM:
                    SP_addDelim(act.getParamExpString(rh, 0));
                    break;
                case ACT_SETDELIM:
                    SP_setDelim(act.getParamExpString(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case ACT_DELETEDELIMINDEX:
                    SP_deleteDelimIndex(act.getParamExpression(rh, 0));
                    break;
                case ACT_DELETEDELIM:
                    SP_deleteDelim(act.getParamExpString(rh, 0));
                    break;
                case ACT_SETDEFDELIMINDEX:
                    SP_setDefDelimIndex(act.getParamExpression(rh, 0));
                    break;
                case ACT_SETDEFDELIM:
                    SP_setDefDelim(act.getParamExpString(rh, 0));
                    break;
                case ACT_SAVEASCSV:
                    break;
                case ACT_LOADFROMCSV:
                    break;
                case ACT_SAVEASMMFARRAY:
                    break;
                case ACT_LOADFROMMMFARRAY:
                    break;
                case ACT_SAVEASDYNAMICARRAY:
                    break;
                case ACT_LOADFROMDYNAMICARRAY:
                    break;
                case ACT_CASEINSENSITIVE:
                    caseSensitive = false;
                    redoTokens();
                    break;
                case ACT_CASESENSITIVE:
                    caseSensitive = true;
                    redoTokens();
                    break;
                case ACT_SEARCHLITERAL:
                    wildcards = false;
                    redoTokens();
                    break;
                case ACT_SEARCHWILDCARDS:
                    wildcards = true;
                    redoTokens();
                    break;
                case ACT_SAVEASINI:
                    break;
                case ACT_LOADFROMINI:
                    break;
            }
        }

        private void SP_addDelim(String delim)
        {
            if (delim.Length!=0)
            {
                bool exists = false;
                for (int i = 0; i < delims.size(); i++)
                {
                    String thisDelim = (String) delims.get(i);
                    if (getSubstringIndex(thisDelim, delim, 0) >= 0)
                    {
                        exists = true;
                    }
                }
                if (exists == false)
                {
                    delims.add(delim);
                    redoTokens();
                    defaultDelim = delim;
                }
            }
        }

        private void SP_setDelim(String delim, int index)
        {
            if ((index >= 0) && (index < delims.size()))
            {
                delims.set(index, delim);
                defaultDelim = delim;
                redoTokens();
            }
        }

        private void SP_deleteDelimIndex(int index)
        {
            if ((index >= 0) && (index < delims.size()))
            {
                delims.remove(index);
                if (index < delims.size())
                {
                    defaultDelim = (String) delims.get(index);
                }
                else
                {
                    defaultDelim = null;
                }
                redoTokens();
            }
        }

        private void SP_deleteDelim(String delim)
        {
            for (int i = 0; i < delims.size(); i++)
            {
                if (string.Compare(((String)delims.get(i)), delim)==0)
                {
                    delims.remove(i);
                    if (i < delims.size())
                    {
                        defaultDelim = (String) delims.get(i);
                    }
                    else
                    {
                        defaultDelim = null;
                    }
                    redoTokens();
                    return;
                }
            }
        }

        private void SP_setDefDelimIndex(int index)
        {
            if ((index >= 0) && (index < delims.size()))
            {
                defaultDelim = (String) delims.get(index);
            }
        }

        private void SP_setDefDelim(String delim)
        {
            for (int i = 0; i < delims.size(); i++)
            {
                if (string.Compare((String)delims.get(i), delim)==0)
                {
                    defaultDelim = (String) delims.get(i);
                    return;
                }
            }
        }

        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_GETSTRING:
                    return new CValue(source);
                case EXP_GETLENGTH:
                    return new CValue(source.Length);
                case EXP_LEFT:
                    return SP_left(ho.getExpParam().getInt());
                case EXP_RIGHT:
                    return SP_right(ho.getExpParam().getInt());
                case EXP_MIDDLE:
                    return SP_middle(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_NUMBEROFSUBS:
                    return SP_numberOfSubs(ho.getExpParam().getString());
                case EXP_INDEXOFSUB:
                    return SP_indexOfSub(ho.getExpParam().getString(), ho.getExpParam().getInt());
                case EXP_INDEXOFFIRSTSUB:
                    return SP_indexOfFirstSub(ho.getExpParam().getString());
                case EXP_INDEXOFLASTSUB:
                    return SP_indexOfLastSub(ho.getExpParam().getString());
                case EXP_REMOVE:
                    return SP_remove(ho.getExpParam().getString());
                case EXP_REPLACE:
                    return SP_replace(ho.getExpParam().getString(), ho.getExpParam().getString());
                case EXP_INSERT:
                    return SP_insert(ho.getExpParam().getString(), ho.getExpParam().getInt());
                case EXP_REVERSE:
                    return SP_reverse();
                case EXP_UPPERCASE:
                    return new CValue(source.ToUpper());
                case EXP_LOWERCASE:
                    return new CValue(source.ToLower());
                case EXP_URLENCODE:
                    return SP_urlEncode();
                case EXP_CHR:
                    return SP_chr(ho.getExpParam().getInt());
                case EXP_ASC:
                    return SP_asc(ho.getExpParam().getString());
                case EXP_ASCLIST:
                    return SP_ascList(ho.getExpParam().getString());
                case EXP_NUMBEROFDELIMS:
                    return new CValue(delims.size());
                case EXP_GETDELIM:
                    return SP_getDelim(ho.getExpParam().getInt());
                case EXP_GETDELIMINDEX:
                    return SP_getDelimIndex(ho.getExpParam().getString());
                case EXP_GETDEFDELIM:
                    return SP_getDefDelim();
                case EXP_GETDEFDELIMINDEX:
                    return SP_getDefDelimIndex();
                case EXP_LISTCOUNT:
                    return new CValue(tokensE.size());
                case EXP_LISTSETAT:
                    return SP_listSetAt(ho.getExpParam().getString(), ho.getExpParam().getInt());
                case EXP_LISTINSERTAT:
                    return SP_listInsertAt(ho.getExpParam().getString(), ho.getExpParam().getInt());
                case EXP_LISTAPPEND:
                    return new CValue(source + ho.getExpParam().getString());
                case EXP_LISTPREPEND:
                    return new CValue(ho.getExpParam().getString() + source);
                case EXP_LISTGETAT:
                    return SP_listGetAt(ho.getExpParam().getInt());
                case EXP_LISTFIRST:
                    return SP_listFirst();
                case EXP_LISTLAST:
                    return SP_listLast();
                case EXP_LISTFIND: //matching
                    return SP_listFind(ho.getExpParam().getString(), ho.getExpParam().getInt());
                case EXP_LISTCONTAINS:
                    return SP_listContains(ho.getExpParam().getString(), ho.getExpParam().getInt());
                case EXP_LISTDELETEAT:
                    return SP_listDeleteAt(ho.getExpParam().getInt());
                case EXP_LISTSWAP:
                    return SP_listSwap(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_LISTSORTASC:
                    return SP_listSortAsc();
                case EXP_LISTSORTDESC:
                    return SP_listSortDesc();
                case EXP_LISTCHANGEDELIMS:
                    return SP_listChangeDelims(ho.getExpParam().getString());
                case EXP_SETSTRING:
                    return SP_setStringEXP(ho.getExpParam().getString());
                case EXP_SETVALUE:
                    return SP_setValueEXP(ho.getExpParam().getString());
                case EXP_GETMD5:
                    return SP_getMD5();
            }
            return new CValue(0);//won't be used
        }

        private CValue SP_left(int i)
        {
            if ((i >= 0) && (i <= source.Length))
            {
                return new CValue(source.Substring(0, i));
            }
            return new CValue("");
        }

        private CValue SP_right(int i)
        {
            if ((i >= 0) && (i <= source.Length))
            {
                return new CValue(source.Substring(source.Length - i));
            }
            return new CValue("");
        }

        private CValue SP_middle(int i, int length)
        {
            length = Math.Max(0, length);
            if ((i >= 0) && (i + length <= source.Length))
            {
                return new CValue(source.Substring(i, length));
            }
            return new CValue("");
        }

        private CValue SP_numberOfSubs(String sub)
        {
            int count = 0;
            while (getSubstringIndex(source, sub, count) != -1)
            {
                count++;
            }
            return new CValue(count);
        }

        private CValue SP_indexOfSub(String sub, int occurance)
        { //1-based
            occurance = Math.Max(1, occurance);
            return new CValue(getSubstringIndex(source, sub, occurance - 1));
        }

        private CValue SP_indexOfFirstSub(String sub)
        {
            return new CValue(getSubstringIndex(source, sub, 0));
        }

        private CValue SP_indexOfLastSub(String sub)
        {
            int n = Math.Max(1, SP_numberOfSubs(sub).getInt());
            return new CValue(getSubstringIndex(source, sub, n - 1));
        }

        private CValue SP_remove(String sub)
        {
            int count = 0;
            CArrayList parts = new CArrayList(); //Integer
            int index = getSubstringIndex(source, sub, count);
            while (index != -1)
            {
                parts.add(index);
                count++;
                index = getSubstringIndex(source, sub, count);
            }
            if (parts.size() == 0)
            {
                return new CValue(source);
            }
            int last = 0;
            String r = "";
            for (int i = 0; i < parts.size(); i++)
            {
                r += source.Substring(last, ((int) parts.get(i))-last);
                last = ((int) parts.get(i)) + sub.Length;
                if (i == parts.size() - 1)
                {
                    r += source.Substring(last);
                }
            }
            return new CValue(r);
        }

        private CValue SP_replace(String old, String newString)
        {
            int count = 0;
            CArrayList parts = new CArrayList(); //Integer
            int index = getSubstringIndex(source, old, count);
            while (index != -1)
            {
                parts.add(index);
                count++;
                index = getSubstringIndex(source, old, count);
            }
            if (parts.size() == 0)
            {
                return new CValue(source);
            }
            int last = 0;
            String r = "";
            for (int i = 0; i < parts.size(); i++)
            {
                r += source.Substring(last, ((int) parts.get(i))-last) + newString;
                last = ((int) parts.get(i)) + old.Length;
                if (i == parts.size() - 1)
                {
                    r += source.Substring(last);
                }
            }
            return new CValue(r);
        }

        private CValue SP_insert(String insert, int index)
        {
            if ((index >= 1) && (index <= source.Length))
            {
                return new CValue(source.Substring(0, index - 1) + insert + source.Substring(index - 1));
            }
            return new CValue("");
        }

        private CValue SP_reverse()
        {
            String r = "";
            for (int i = source.Length - 1; i >= 0; i--)
            {
                r += source.Substring(i, i);
            }
            return new CValue(r);
        }

        private CValue SP_urlEncode()
        {
            String r = "";
            for (int i = 0; i < source.Length; i++)
            {
                if (isLetterOrDigit(source[i]))
                {
                    r += source.Substring(i, 1);
                }
                else
                {
                    if (source[i]==' ')
                    {
                        r += "+";
                    }
                    else
                    {
                        if (source[i] == 13)
                        {
                            r += "+";
                            i++;
                        }
                        else
                        {
                            r += "%";
                            r += ((int)(source[i] >> 4)).ToString("X");
                            r += ((int)(source[i] % 16)).ToString("X");;
                        }
                    }
                }
            }
            return new CValue(r);
        }

        private CValue SP_chr(int value)
        {
            String r = new String((char)value, 1);
            return new CValue(r);
        }

        private CValue SP_asc(String value)
        {
            if (value.Length> 0)
            {
                int r = (int) value[0];
                return new CValue(r);
            }
            return new CValue(0);
        }

        private CValue SP_ascList(String delim)
        {
            String r = "";
            for (int i = 0; i < source.Length; i++)
            {
                r += ((int)source[i]).ToString();
                if (i < source.Length - 1)
                {
                    r += delim;
                }
            }
            return new CValue(r);
        }

        private CValue SP_getDelim(int i)
        { //0-based, silly 3ee
            if ((i >= 0) && (i < delims.size()))
            {
                return new CValue((String) delims.get(i));
            }
            return new CValue("");
        }

        private CValue SP_getDelimIndex(String delim)
        {
            for (int i = 0; i < delims.size(); i++)
            {
                String thisDelim = (String) delims.get(i);
                if (getSubstringIndex(thisDelim, delim, 0) >= 0)
                {
                    return new CValue(i);
                }
            }
            return new CValue(-1);
        }

        private CValue SP_getDefDelim()
        {
            if (defaultDelim != null)
            {
                return new CValue(defaultDelim);
            }
            return new CValue("");
        }

        private CValue SP_getDefDelimIndex()
        {
            if (defaultDelim != null)
            {
                for (int i = 0; i < delims.size(); i++)
                {
                    String thisDelim = (String) delims.get(i);
                    if (getSubstringIndex(thisDelim, defaultDelim, 0) >= 0)
                    {
                        return new CValue(i);
                    }
                }
            }
            return new CValue(-1);
        }

        private CValue SP_listSetAt(String replace, int index)
        { //1-based
            if ((index >= 1) && (index <= tokensE.size()))
            {
                parserElement e = (parserElement) tokensE.get(index - 1);
                String r = source.Substring(0, e.index) + replace + source.Substring(e.endIndex);
                return new CValue(r);
            }
            return new CValue("");
        }

        private CValue SP_listInsertAt(String insert, int index)
        { //1-based
            if ((index >= 1) && (index <= tokensE.size()))
            {
                parserElement e = (parserElement) tokensE.get(index - 1);
                String r = source.Substring(0, e.index) + insert + source.Substring(e.index);
                return new CValue(r);
            }
            return new CValue("");
        }

        private CValue SP_listGetAt(int index)
        { //1-based
            if ((index >= 1) && (index <= tokensE.size()))
            {
                parserElement e = (parserElement) tokensE.get(index - 1);
                return new CValue(e.text);
            }
            return new CValue("");
        }

        private CValue SP_listFirst()
        {
            if (tokensE.size() > 0)
            {
                parserElement e = (parserElement) tokensE.get(0);
                return new CValue(e.text);
            }
            return new CValue("");
        }

        private CValue SP_listLast()
        {
            if (tokensE.size() > 0)
            {
                parserElement e = (parserElement) tokensE.get(tokensE.size() - 1);
                return new CValue(e.text);
            }
            return new CValue("");
        }

        private CValue SP_listFind(String find, int occurance)
        { //matching //1-based
            if ((occurance > 0) && (find.Length > 0))
            {
                int occuranceCount = 0;
                for (int i = 0; i < tokensE.size(); i++)
                {
                    parserElement e = (parserElement) tokensE.get(i);
                    if (substringMatches(e.text, find))
                    {
                        occuranceCount++;
                    }
                    if (occuranceCount == occurance)
                    {
                        return new CValue(i + 1);
                    }
                }
            }
            return new CValue(0);
        }

        private CValue SP_listContains(String find, int occurance)
        { //matching //1-based
            if ((occurance > 0) && (find.Length > 0))
            {
                int occuranceCount = 0;
                for (int i = 0; i < tokensE.size(); i++)
                {
                    parserElement e = (parserElement) tokensE.get(i);
                    if (getSubstringIndex(e.text, find, 0) != -1)
                    {
                        occuranceCount++;
                    }
                    if (occuranceCount == occurance)
                    {
                        return new CValue(i + 1);
                    }
                }
            }
            return new CValue(0);
        }

        private CValue SP_listDeleteAt(int index)
        { //1-based
            if ((index >= 1) && (index <= tokensE.size()))
            {
                parserElement e = (parserElement) tokensE.get(index - 1);
                String r = source.Substring(0, e.index) + source.Substring(e.endIndex);
                return new CValue(r);
            }
            return new CValue("");
        }

        private CValue SP_listSwap(int i1, int i2)
        { //1-based
            if ((i1 >= 1) && (i2 >= 1) && (i1 <= tokensE.size()) && (i2 <= tokensE.size()))
            {
                if (i1 == i2)
                {
                    return new CValue(source);
                }
                parserElement e1 = (parserElement) tokensE.get(i1 - 1);
                parserElement e2 = (parserElement) tokensE.get(i2 - 1);
                String r = "";
                if (i1 > i2)
                {
                    //e2 comes sooner
                    r += source.Substring(0, e2.index); //string leading up to e2
                    r += source.Substring(e1.index, e1.endIndex - e1.index); //e1
                    r += source.Substring(e2.endIndex, e1.index - e2.endIndex); //string between e2 and e1
                    r += source.Substring(e2.index, e2.endIndex - e2.index); //e2
                    r += source.Substring(e1.endIndex); //string from end of e1 to end
                }
                else
                { //i1 < i2
                    //e1 comes sooner
                    r += source.Substring(0, e1.index); //string leading up to e1
                    r += source.Substring(e2.index, e2.endIndex - e2.index); //e2
                    r += source.Substring(e1.endIndex, e2.index - e1.endIndex); //string between e1 and e2
                    r += source.Substring(e1.index, e1.endIndex - e1.index); //e1
                    r += source.Substring(e2.endIndex); //string from end of e2 to end
                }
                return new CValue(r);
            }
            return new CValue("");
        }

        private CValue SP_listSortAsc()
        {
            CArrayList sorted = new CArrayList(); //parserElement
            for (int i = 0; i < tokensE.size(); i++)
            {
                parserElement e = (parserElement) tokensE.get(i);
                if (sorted.size() == 0)
                {
                    sorted.add(e);
                }
                else
                {
                    int index = 0;
                    for (int j = 0; j < sorted.size(); j++)
                    {
                        parserElement element = (parserElement) sorted.get(j);
                        if (caseSensitive)
                        {
                            if (string.Compare(e.text, element.text) >= 0)
                            {
                                index = j;
                            }
                        }
                        else
                        {
                            if (string.Compare(e.text, element.text, StringComparison.OrdinalIgnoreCase) >= 0)
                            {
                                index = j;
                            }
                        }
                    }
                    sorted.add(index, e);
                }
            }
            String r = "";
            for (int i = 0; i < sorted.size(); i++)
            {
                parserElement e = (parserElement) sorted.get(i);
                parserElement oe = (parserElement) tokensE.get(i);
                if (i == 0)
                {
                    r += source.Substring(0, oe.index);
                }
                else
                {
                    parserElement lastOrigE = (parserElement) tokensE.get(i - 1);
                    r += source.Substring(lastOrigE.endIndex, oe.index - lastOrigE.endIndex);
                }
                r += source.Substring(e.index, e.endIndex - e.index);
                if (i == sorted.size() - 1)
                {
                    r += source.Substring(oe.endIndex);
                }
            }
            return new CValue(r);
        }

        private CValue SP_listSortDesc()
        {
            CArrayList sorted = new CArrayList(); //parserElement
            for (int i = 0; i < tokensE.size(); i++)
            {
                parserElement e = (parserElement) tokensE.get(i);
                if (sorted.size() == 0)
                {
                    sorted.add(e);
                }
                else
                {
                    int index = sorted.size();
                    for (int j = sorted.size() - 1; j >= 0; j--)
                    {
                        parserElement element = (parserElement) sorted.get(j);
                        if (caseSensitive)
                        {
                            if (string.Compare(e.text, element.text) >= 0)
                            {
                                index = j;
                            }
                        }
                        else
                        {
                            if (string.Compare(e.text, element.text, StringComparison.OrdinalIgnoreCase) >= 0)
                            {
                                index = j;
                            }
                        }
                    }
                    sorted.add(index, e);
                }
            }
            String r = "";
            for (int i = 0; i < sorted.size(); i++)
            {
                parserElement e = (parserElement) sorted.get(i);
                parserElement oe = (parserElement) tokensE.get(i);
                if (i == 0)
                {
                    r += source.Substring(0, oe.index);
                }
                else
                {
                    parserElement lastOrigE = (parserElement) tokensE.get(i - 1);
                    r += source.Substring(lastOrigE.endIndex, oe.index - lastOrigE.endIndex);
                }
                r += source.Substring(e.index, e.endIndex - e.index);
                if (i == sorted.size() - 1)
                {
                    r += source.Substring(oe.endIndex);
                }
            }
            return new CValue(r);
        }

        private CValue SP_listChangeDelims(String changeDelim)
        {
            if (defaultDelim != null)
            {
                String r = "";
                for (int i = 0; i < tokensE.size(); i++)
                {
                    parserElement e = (parserElement) tokensE.get(i);
                    int here = e.index - defaultDelim.Length;
                    if ((here >= 0) && (string.Compare(source.Substring(here, e.index-here), defaultDelim)==0))
                    {
                        r += changeDelim;
                    }
                    else
                    {
                        if (i == 0)
                        {
                            r += source.Substring(0, e.index);
                        }
                        else
                        {
                            parserElement lastOrigE = (parserElement) tokensE.get(i - 1);
                            r += source.Substring(lastOrigE.endIndex, e.index - lastOrigE.endIndex);
                        }
                    }
                    r += source.Substring(e.index, e.endIndex - e.index);
                    if (i == tokensE.size() - 1)
                    {
                        if (string.Compare(source.Substring(e.endIndex), defaultDelim)==0)
                        {
                            r += changeDelim;
                        }
                        else
                        {
                            r += source.Substring(e.endIndex);
                        }
                    }
                }
                return new CValue(r);
            }
            return new CValue("");
        }

        private CValue SP_setStringEXP(String newSource)
        {
            source = newSource;
            redoTokens();
            return new CValue("");
        }

        private CValue SP_setValueEXP(String newSource)
        {
            source = newSource;
            redoTokens();
            return new CValue(0);
        }

        private CValue SP_getMD5()
        {
	    	CValue ret=new CValue(MD5.getMD5(source));
            return ret;
        }
    }

    class MD5
    {
		static int RotateLeft(int lValue, int iShiftBits)
		{
			return (int)(((uint)(lValue<<iShiftBits)) | (uint)(( ((uint)lValue)>>(32-iShiftBits))));
		}
		 
		static public int AddUnsigned(int lX, int lY)
    	{
			int lX4,lY4,lX8,lY8,lResult;
			lX8 = (int)(lX & 0x80000000);
			lY8 = (int)(lY & 0x80000000);
			lX4 = (int)(lX & 0x40000000);
			lY4 = (int)(lY & 0x40000000);
			lResult = (lX & 0x3FFFFFFF)+(lY & 0x3FFFFFFF);
			if ((lX4 & lY4)!=0)
            {
				return (int)(lResult ^ 0x80000000 ^ lX8 ^ lY8);
			}
			if ((lX4 | lY4)!=0)
            {
				if ((lResult & 0x40000000)!=0)
                {
					return (int)(lResult ^ 0xC0000000 ^ lX8 ^ lY8);
				} else {
					return (int)(lResult ^ 0x40000000 ^ lX8 ^ lY8);
				}
			} else {
				return (lResult ^ lX8 ^ lY8);
			}
		}
		 
		static int F(int x, int y, int z)
        { 
            return (x & y) | ((~x) & z); 
        }
		static int G(int x, int y, int z)
        { 
            return (x & z) | (y & (~z)); 
        }
		static int H(int x, int y, int z)
        { 
            return (x ^ y ^ z); 
        }
		static int I(int x, int y, int z)
        { 
            return (y ^ (x | (~z))); 
        }
		 
		static int FF(int a, int b, int c, int d, int x, int s, int ac)
		{
			a = AddUnsigned(a, AddUnsigned(AddUnsigned(F(b, c, d), x), ac));
			return AddUnsigned(RotateLeft(a, s), b);
		}
		 
		static int GG(int a,int b, int c, int d, int x, int s, int ac)
		{
			a = AddUnsigned(a, AddUnsigned(AddUnsigned(G(b, c, d), x), ac));
			return AddUnsigned(RotateLeft(a, s), b);
		}
		 
		static int HH(int a,int b, int c, int d, int x, int s, int ac)
		{
			a = AddUnsigned(a, AddUnsigned(AddUnsigned(H(b, c, d), x), ac));
			return AddUnsigned(RotateLeft(a, s), b);
		}
		 
		static int II(int a,int b, int c, int d, int x, int s, int ac)
		{
			a = AddUnsigned(a, AddUnsigned(AddUnsigned(I(b, c, d), x), ac));
			return AddUnsigned(RotateLeft(a, s), b);
		}
		 
		static ushort[] ConvertToWordArray(string pString)
		{
			int lWordCount;
			int lMessageLength = pString.Length;
			int lNumberOfWords_temp1=lMessageLength + 8;
			int lNumberOfWords_temp2=(lNumberOfWords_temp1-(lNumberOfWords_temp1 % 64))/64;
			int lNumberOfWords= (lNumberOfWords_temp2+1)*16;
			ushort[] lWordArray=new ushort[lNumberOfWords-1];
			int lBytePosition= 0;
			int lByteCount= 0;
			while ( lByteCount < lMessageLength ) 
            {
				lWordCount = (lByteCount-(lByteCount % 4))/4;
				lBytePosition = (lByteCount % 4)*8;
				lWordArray[lWordCount] = (ushort)(lWordArray[lWordCount] | (pString[lByteCount]<<lBytePosition));
				lByteCount++;
			}
			lWordCount = (lByteCount-(lByteCount % 4))/4;
			lBytePosition = (lByteCount % 4)*8;
			lWordArray[lWordCount] = (ushort)(lWordArray[lWordCount] | (0x80<<lBytePosition));
			lWordArray[lNumberOfWords-2] = (ushort)(lMessageLength<<3);
			lWordArray[lNumberOfWords-1] = (ushort)(((uint)lMessageLength)>>29);
			return lWordArray;
		}
		 
		static string WordToHex(int lValue)
		{
			string WordToHexValue="",WordToHexValue_temp="";
            int lByte,lCount;
			for (lCount = 0;lCount<=3;lCount++) 
            {
				lByte = (int)(((uint)lValue)>>(lCount*8)) & 255;
				WordToHexValue_temp = "0" + lByte.ToString("X");
				WordToHexValue = WordToHexValue + WordToHexValue_temp.Substring(WordToHexValue_temp.Length-2,2);
			}
			return WordToHexValue;
		}
		 
		static string Utf8Encode(string pString)
		{		 
			string utftext= "";
		 
			for (int n = 0; n < pString.Length; n++) 
            {
				int c = pString[n];
		 
				if (c < 128) 
                {
					utftext += new string((char)c, 1);
				}
				else if((c > 127) && (c < 2048)) 
                {
					utftext += new string((char)((c >> 6) | 192), 1);
					utftext += new string((char)((c & 63) | 128), 1);
				}
				else {
					utftext += new string((char)((c >> 12) | 224), 1);
					utftext += new string((char)(((c >> 6) & 63) | 128), 1);
					utftext += new string((char)((c & 63) | 128), 1);
				}
		 
			}
		 
			return utftext;
		}
		 
        public static string getMD5(string pString)
        {
		    ushort[] x;
		    int k,AA,BB,CC,DD,a,b,c,d;
		    int S11=7, S12=12, S13=17, S14=22;
		    int S21=5, S22=9 , S23=14, S24=20;
		    int S31=4, S32=11, S33=16, S34=23;
		    int S41=6, S42=10, S43=15, S44=21;
		 
		    pString = Utf8Encode(pString);
		 
		    x = ConvertToWordArray(pString);
		 
		    a = 0x67452301; b = unchecked((int)0xEFCDAB89); c = unchecked((int)0x98BADCFE); d = 0x10325476;
		 
		    for (k=0;k<x.Length;k+=16) 
            {
			    AA=a; BB=b; CC=c; DD=d;
			    a=FF(a,b,c,d,x[k+0], S11,unchecked((int)0xD76AA478));
			    d=FF(d,a,b,c,x[k+1], S12,unchecked((int)0xE8C7B756));
			    c=FF(c,d,a,b,x[k+2], S13,unchecked((int)0x242070DB));
			    b=FF(b,c,d,a,x[k+3], S14,unchecked((int)0xC1BDCEEE));
			    a=FF(a,b,c,d,x[k+4], S11,unchecked((int)0xF57C0FAF));
			    d=FF(d,a,b,c,x[k+5], S12,unchecked((int)0x4787C62A));
			    c=FF(c,d,a,b,x[k+6], S13,unchecked((int)0xA8304613));
			    b=FF(b,c,d,a,x[k+7], S14,unchecked((int)0xFD469501));
			    a=FF(a,b,c,d,x[k+8], S11,unchecked((int)0x698098D8));
			    d=FF(d,a,b,c,x[k+9], S12,unchecked((int)0x8B44F7AF));
			    c=FF(c,d,a,b,x[k+10],S13,unchecked((int)0xFFFF5BB1));
			    b=FF(b,c,d,a,x[k+11],S14,unchecked((int)0x895CD7BE));
			    a=FF(a,b,c,d,x[k+12],S11,unchecked((int)0x6B901122));
			    d=FF(d,a,b,c,x[k+13],S12,unchecked((int)0xFD987193));
			    c=FF(c,d,a,b,x[k+14],S13,unchecked((int)0xA679438E));
			    b=FF(b,c,d,a,x[k+15],S14,unchecked((int)0x49B40821));
			    a=GG(a,b,c,d,x[k+1], S21,unchecked((int)0xF61E2562));
			    d=GG(d,a,b,c,x[k+6], S22,unchecked((int)0xC040B340));
			    c=GG(c,d,a,b,x[k+11],S23,unchecked((int)0x265E5A51));
			    b=GG(b,c,d,a,x[k+0], S24,unchecked((int)0xE9B6C7AA));
			    a=GG(a,b,c,d,x[k+5], S21,unchecked((int)0xD62F105D));
			    d=GG(d,a,b,c,x[k+10],S22,unchecked((int)0x2441453));
			    c=GG(c,d,a,b,x[k+15],S23,unchecked((int)0xD8A1E681));
			    b=GG(b,c,d,a,x[k+4], S24,unchecked((int)0xE7D3FBC8));
			    a=GG(a,b,c,d,x[k+9], S21,unchecked((int)0x21E1CDE6));
			    d=GG(d,a,b,c,x[k+14],S22,unchecked((int)0xC33707D6));
			    c=GG(c,d,a,b,x[k+3], S23,unchecked((int)0xF4D50D87));
			    b=GG(b,c,d,a,x[k+8], S24,unchecked((int)0x455A14ED));
			    a=GG(a,b,c,d,x[k+13],S21,unchecked((int)0xA9E3E905));
			    d=GG(d,a,b,c,x[k+2], S22,unchecked((int)0xFCEFA3F8));
			    c=GG(c,d,a,b,x[k+7], S23,unchecked((int)0x676F02D9));
			    b=GG(b,c,d,a,x[k+12],S24,unchecked((int)0x8D2A4C8A));
			    a=HH(a,b,c,d,x[k+5], S31,unchecked((int)0xFFFA3942));
			    d=HH(d,a,b,c,x[k+8], S32,unchecked((int)0x8771F681));
			    c=HH(c,d,a,b,x[k+11],S33,unchecked((int)0x6D9D6122));
			    b=HH(b,c,d,a,x[k+14],S34,unchecked((int)0xFDE5380C));
			    a=HH(a,b,c,d,x[k+1], S31,unchecked((int)0xA4BEEA44));
			    d=HH(d,a,b,c,x[k+4], S32,unchecked((int)0x4BDECFA9));
			    c=HH(c,d,a,b,x[k+7], S33,unchecked((int)0xF6BB4B60));
			    b=HH(b,c,d,a,x[k+10],S34,unchecked((int)0xBEBFBC70));
			    a=HH(a,b,c,d,x[k+13],S31,unchecked((int)0x289B7EC6));
			    d=HH(d,a,b,c,x[k+0], S32,unchecked((int)0xEAA127FA));
			    c=HH(c,d,a,b,x[k+3], S33,unchecked((int)0xD4EF3085));
			    b=HH(b,c,d,a,x[k+6], S34,unchecked((int)0x4881D05));
			    a=HH(a,b,c,d,x[k+9], S31,unchecked((int)0xD9D4D039));
			    d=HH(d,a,b,c,x[k+12],S32,unchecked((int)0xE6DB99E5));
			    c=HH(c,d,a,b,x[k+15],S33,unchecked((int)0x1FA27CF8));
			    b=HH(b,c,d,a,x[k+2], S34,unchecked((int)0xC4AC5665));
			    a=II(a,b,c,d,x[k+0], S41,unchecked((int)0xF4292244));
			    d=II(d,a,b,c,x[k+7], S42,unchecked((int)0x432AFF97));
			    c=II(c,d,a,b,x[k+14],S43,unchecked((int)0xAB9423A7));
			    b=II(b,c,d,a,x[k+5], S44,unchecked((int)0xFC93A039));
			    a=II(a,b,c,d,x[k+12],S41,unchecked((int)0x655B59C3));
			    d=II(d,a,b,c,x[k+3], S42,unchecked((int)0x8F0CCC92));
			    c=II(c,d,a,b,x[k+10],S43,unchecked((int)0xFFEFF47D));
			    b=II(b,c,d,a,x[k+1], S44,unchecked((int)0x85845DD1));
			    a=II(a,b,c,d,x[k+8], S41,unchecked((int)0x6FA87E4F));
			    d=II(d,a,b,c,x[k+15],S42,unchecked((int)0xFE2CE6E0));
			    c=II(c,d,a,b,x[k+6], S43,unchecked((int)0xA3014314));
			    b=II(b,c,d,a,x[k+13],S44,unchecked((int)0x4E0811A1));
			    a=II(a,b,c,d,x[k+4], S41,unchecked((int)0xF7537E82));
			    d=II(d,a,b,c,x[k+11],S42,unchecked((int)0xBD3AF235));
			    c=II(c,d,a,b,x[k+2], S43,unchecked((int)0x2AD7D2BB));
			    b=II(b,c,d,a,x[k+9], S44,unchecked((int)0xEB86D391));
			    a=AddUnsigned(a,AA);
			    b=AddUnsigned(b,BB);
			    c=AddUnsigned(c,CC);
			    d=AddUnsigned(d,DD);
		    }
		 
			string temp = WordToHex(a)+WordToHex(b)+WordToHex(c)+WordToHex(d);
		 
			return temp.ToLower();
		}		
    }
    class parserElement
    {
        public String text;
        public int index;
        public int endIndex;

        public parserElement(String text, int index)
        {
            this.text = text;
            this.index = index;
            this.endIndex = index + this.text.Length;
        }
    }

    class StringTokenizer
    {
        string[] array=null;
        int count=0;

        public StringTokenizer(string source, string delim)
        {
            int total=0;
            int pos = source.IndexOf(delim);
            while (pos >= 0)
            {
                total++;
                pos++;
                if (pos>=source.Length)
                {
                    break;
                }
                pos = source.IndexOf(delim, pos);
            }
            if (total > 0)
            {
                array = new string[total];
                total = 0;
                pos = source.IndexOf(delim);
                int oldPos = 0;
                while (pos >= 0)
                {
                    array[total]=source.Substring(oldPos, pos - oldPos);
                    oldPos = pos + 1;
                    total++;
                    if (oldPos >= source.Length)
                    {
                        break;
                    }
                    pos = source.IndexOf(delim, oldPos);
                }
            }
        }
        public int countTokens()
        {
            if (array != null)
            {
                return array.Length;
            }
            return 0;
        }
        public string nextToken()
        {
            if (array!=null)
            {
                return array[count++];
            }
            return "";
        }
    }
}
