﻿//----------------------------------------------------------------------------------
//
// CRunAdvDir: Advanced Direction pObject
// fin 
//greyhill
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;

namespace RuntimeXNA.Extensions
{
    class CRunAdvDir : CRunExtension
    {
        const int CND_COMPDIST = 0;
        const int CND_COMPDIR = 1;
        const int ACT_SETNUMDIR = 0;
        const int ACT_GETOBJECTS = 1;
        const int ACT_ADDOBJECTS = 2;
        const int ACT_RESET = 3;
        const int EXP_GETNUMDIR = 0;
        const int EXP_DIRECTION = 1;
        const int EXP_DISTANCE = 2;
        const int EXP_DIRECTIONLONG = 3;
        const int EXP_DISTANCELONG = 4;
        const int EXP_ROTATE = 5;
        const int EXP_DIRDIFFABS = 6;
        const int EXP_DIRDIFF = 7;
        const int EXP_GETFIXEDOBJ = 8;
        const int EXP_GETDISTOBJ = 9;
        const int EXP_XMOV = 10;
        const int EXP_YMOV = 11;
        const int EXP_DIRBASE = 12;

        int CurrentObject;
        double EventCount;
        int NumDir;
        CArrayList Distance = new CArrayList(); //Float
        CArrayList Fixed = new CArrayList(); //Integer
        CPoint Last = new CPoint();

        public override int getNumberOfConditions()
        {
            return 2;
        }

        private String fixString(String input)
        {
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] < 10)
                {
                    return input.Substring(0, i);
                }
            }
            return input;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            bool bUnicode = file.bUnicode;
            file.setUnicode(false);
            file.skipBytes(8);
            this.EventCount = -1;
            NumDir = 0;
            try
            {
                NumDir = System.Convert.ToInt32(file.readAString(32), 10);
            }
            catch(FormatException e)
            {
                e.GetType();
            }
            catch (ArgumentOutOfRangeException e)
            {
                e.GetType();
            }
            file.setUnicode(bUnicode);
            return true;
        }

        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CND_COMPDIST:
                    return CompDist(cnd.getParamPosition(rh, 0), cnd.getParamPosition(rh, 1), cnd.getParamExpression(rh, 2));
                case CND_COMPDIR:
                    return CompDir(cnd.getParamPosition(rh, 0), cnd.getParamPosition(rh, 1), cnd.getParamExpression(rh, 2), cnd.getParamExpression(rh, 3));
            }
            return false;
        }

        private bool CompDist(PARAM_POSITION p1, PARAM_POSITION p2, int v)
        {
            int x1 = p1.posX;
            int y1 = p1.posY;
            int x2 = p2.posX;
            int y2 = p2.posY;

            if ((int)Math.Sqrt(((x1 - x2) * (x1 - x2)) + ((y1 - y2) * (y1 - y2))) <= v)
            {
                return true;
            }
            return false;
        }

        private int lMin(int v1, int v2, int v3)
        {
            return Math.Min(v1, Math.Min(v2, v3));
            /*	if(v1 <= v2 && v1 <= v3)	return v1;
            if(v2 <= v1 && v2 <= v3)	return v2;
            if(v3 <= v1 && v3 <= v2)	return v3;*/
            //return 0;
        }

        private bool CompDir(PARAM_POSITION p1, PARAM_POSITION p2, int dir, int offset)
        {
            int x1 = p1.posX;
            int y1 = p1.posY;
            int x2 = p2.posX;
            int y2 = p2.posY;

            while (dir >= NumDir)
            {
                dir -= NumDir;
            }
            while (dir < 0)
            {
                dir += NumDir;
            }

            int dir2 = (int)(((((Math.Atan2(y2 - y1, x2 - x1) * 180) / Math.PI) * -1) / 360) * NumDir);

            while (dir2 >= NumDir)
            {
                dir2 -= NumDir;
            }
            while (dir2 < 0)
            {
                dir2 += NumDir;
            }

            if (lMin(Math.Abs(dir - dir2), Math.Abs(dir - dir2 - NumDir), Math.Abs(dir - dir2 + NumDir)) <
                    offset)
            {
                return true;
            }
            return false;
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_SETNUMDIR:
                    SetNumDir(act.getParamExpression(rh, 0));
                    break;
                case ACT_GETOBJECTS:
                    GetObjects(act.getParamObject(rh, 0), act.getParamPosition(rh, 1));
                    break;
                case ACT_ADDOBJECTS:
                    AddObjects(act.getParamObject(rh, 0));
                    break;
                case ACT_RESET:
                    CurrentObject = 0;
                    break;
            }
        }

        private void SetNumDir(int n)
        {
            NumDir = n;
        }

        private void GetObjects(CObject pObject, CPositionInfo position)
        {
            CRun rhPtr = ho.hoAdRunHeader;
            //resetting if another event
            if (EventCount != rhPtr.rh4EventCount)
            {
                CurrentObject = 0;
                EventCount = rhPtr.rh4EventCount;
            }
            int x1 = position.x;
            int y1 = position.y;
            Last.x = position.x;
            Last.y = position.y;
            int x2 = pObject.hoX;
            int y2 = pObject.hoY;
            while (CurrentObject >= Distance.size())
            {
                Distance.add(null);
                Fixed.add(null);
            }
            Distance.set(CurrentObject, (float)Math.Sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) ));
            Fixed.set(CurrentObject, (int)((pObject.hoCreationId << 16) + pObject.hoNumber));
            CurrentObject++;
        }

        private void AddObjects(CObject pObject)
        {
            int x1 = Last.x;
            int y1 = Last.y;
            int x2 = pObject.hoX;
            int y2 = pObject.hoY;
            while (CurrentObject >= Distance.size())
            {
                Distance.add(null);
                Fixed.add(null);
            }
            Distance.set(CurrentObject, (float) Math.Sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)));
            Fixed.set(CurrentObject, (int)((pObject.hoCreationId << 16) + pObject.hoNumber));
            CurrentObject++;
        }

        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_GETNUMDIR:
                    return new CValue(NumDir);
                case EXP_DIRECTION:
                    return Direction(ho.getExpParam().getInt(), ho.getExpParam().getInt(), ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_DISTANCE:
                    return getDistance(ho.getExpParam().getInt(), ho.getExpParam().getInt(), ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_DIRECTIONLONG:
                    return LongDir(ho.getExpParam().getInt(), ho.getExpParam().getInt(), ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_DISTANCELONG:
                    return LongDist(ho.getExpParam().getInt(), ho.getExpParam().getInt(), ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_ROTATE:
                    return Rotate(ho.getExpParam().getInt(), ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_DIRDIFFABS:
                    return DirDiffAbs(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_DIRDIFF:
                    return DirDiff(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_GETFIXEDOBJ:
                    return GetFixedObj(ho.getExpParam().getInt());
                case EXP_GETDISTOBJ:
                    return GetDistObj(ho.getExpParam().getInt());
                case EXP_XMOV:
                    return XMov(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_YMOV:
                    return YMov(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EXP_DIRBASE:
                    return DirBase(ho.getExpParam().getInt(), ho.getExpParam().getInt());
            }
            return new CValue(0);//won't be used
        }

        private CValue Direction(int x1, int y1, int x2, int y2)
        {
            //Just doing simple math now.
            float r = (float)(((((Math.Atan2(y2 - y1, x2 - x1) * 180) / Math.PI) * -1) / 360) * NumDir);

            while (r >= NumDir)
            {
                r -= NumDir;
            }
            while (r < 0)
            {
                r += NumDir;
            }

            return new CValue(r);
        }

        private CValue getDistance(int x1, int y1, int x2, int y2)
        {
            float r = (float)Math.Sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
            return new CValue(r);
        }

        private CValue LongDir(int x1, int y1, int x2, int y2)
        {
            //Just doing simple math now.
            float r = (float)(((((Math.Atan2(y2 - y1, x2 - x1) * 180) / Math.PI) * -1) / 360) * NumDir);
            if ((int)r < NumDir / 2)
            {
                r += 0.5F;
            }
            if ((int)r > NumDir / 2)
            {
                r -= 0.5F;
            }
            while (r >= NumDir)
            {
                r -= NumDir;
            }
            while (r < 0)
            {
                r += NumDir;
            }

            return new CValue((int)r);
        }

        private CValue LongDist(int x1, int y1, int x2, int y2)
        {
            return new CValue((int)Math.Sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)));
        }

        private CValue Rotate(int angle, int angletgt, int rotation)
        {
            if (rotation < 0)
            {
                rotation *= -1;
                angletgt += NumDir / 2;
            }

            while (angletgt < 0)
            {
                angletgt += NumDir;
            }
            while (angletgt >= NumDir)
            {
                angletgt -= NumDir;
            }

            if (Math.Abs((int)(angle - angletgt)) <= rotation)
            {
                angle = angletgt;
            }
            if (Math.Abs((int)(angle - angletgt - NumDir)) <= rotation)
            {
                angle = angletgt;
            }
            if (Math.Abs((int)(angle - angletgt + NumDir)) <= rotation)
            {
                angle = angletgt;
            }

            if (angletgt != angle)
            {
                if (angle - angletgt >= 0 && angle - angletgt < NumDir / 2)
                {
                    angle -= rotation;
                }
                if (angle - angletgt >= NumDir / 2)
                {
                    angle += rotation;
                }
                if (angle - angletgt <= 0 && angle - angletgt > NumDir / -2)
                {
                    angle += rotation;
                }
                if (angle - angletgt <= NumDir / -2)
                {
                    angle -= rotation;
                }
            }

            while (angle >= NumDir)
            {
                angle -= NumDir;
            }
            while (angle < 0)
            {
                angle += NumDir;
            }

            return new CValue(angle);
        }

        int lSMin(int v1, int v2, int v3)
        {
            if (Math.Abs(v1) <= Math.Abs(v2) && Math.Abs(v1) <= Math.Abs(v3))
            {
                return v1;
            }
            if (Math.Abs(v2) <= Math.Abs(v1) && Math.Abs(v2) <= Math.Abs(v3))
            {
                return v2;
            }
            if (Math.Abs(v3) <= Math.Abs(v1) && Math.Abs(v3) <= Math.Abs(v2))
            {
                return v3;
            }
            return 0;
        }

        private CValue DirDiffAbs(int p1, int p2)
        {
            return new CValue(lMin(Math.Abs(p1 - p2), Math.Abs(p1 - p2 - NumDir), Math.Abs(p1 - p2 + NumDir)));
        }

        private CValue DirDiff(int p1, int p2)
        {
            return new CValue(lSMin(p1 - p2, p1 - p2 - NumDir, p1 - p2 + NumDir));
        }

        private CValue GetFixedObj(int p1)
        {
            if (p1 >= CurrentObject || p1 < 0)
            {
                p1 = CurrentObject - 1;
            }
            int r = 0;
            if (CurrentObject > 0)
            {
                CArrayList Fixes = new CArrayList();// = (long *)malloc(sizeof(long) * rdPtr->CurrentObject);
                for (int i = 0; i < CurrentObject; i++)
                {
                    Fixes.add(Fixed.get(i));
                }
                for (int i = 0; i <= p1; i++)
                {
                    int ClosestID = -1;
                    for (int k = 0; k < CurrentObject; k++)
                    {
                        if (Fixes.get(k) != null)
                        {
                            if (ClosestID == -1)
                            {
                                ClosestID = k;
                            }
                            else
                            {
                                float dAtK = (float)Distance.get(k);
                                float dAtClosestID = (float)Distance.get(ClosestID);
                                if (dAtK < dAtClosestID)
                                {
                                    ClosestID = k;
                                }
                            }
                        }
                    }
                    if (ClosestID != -1)
                    {
                        Fixes.set(ClosestID, null);
                        r = (int)Fixed.get(ClosestID);
                    }
                }
            }
            return new CValue(r);
        }

        private CValue GetDistObj(int p1)
        {
            if (p1 >= CurrentObject || p1 < 0)
            {
                p1 = CurrentObject - 1;
            }
            long r = 0;
            if (CurrentObject > 0)
            {
                CArrayList Fixes = new CArrayList();// = (long *)malloc(sizeof(long) * rdPtr->CurrentObject);
                for (int i = 0; i < CurrentObject; i++)
                {
                    Fixes.add(Fixed.get(i));
                }
                for (int i = 0; i <= p1; i++)
                {
                    int ClosestID = -1;
                    for (int k = 0; k < CurrentObject; k++)
                    {
                        if (Fixes.get(k) != null)
                        {
                            if (ClosestID == -1)
                            {
                                ClosestID = k;
                            }
                            else
                            {
                                float dAtK = (float)Distance.get(k);
                                float dAtClosestID = (float)Distance.get(ClosestID);
                                if (dAtK < dAtClosestID)
                                {
                                    ClosestID = k;
                                }
                            }
                        }
                    }
                    if (ClosestID != -1)
                    {
                        Fixes.set(ClosestID, null);
                        r = (int)((float)Distance.get(ClosestID));
                    }
                }
            }
            return new CValue(r);
        }

        private CValue XMov(int dir, int speed)
        {
            float r;
            dir = ((dir * 360) / NumDir);
            if (dir == 270 || dir == 90)
            {
                r = 0;
            }
            else
            {
                float angle = (float)((dir * Math.PI * 2) / 360);
                r = (float)(Math.Cos(angle * -1) * speed);
            }
            return new CValue(r);
        }

        private CValue YMov(int dir, int speed)
        {
            float r;
            dir = ((dir * 360) / NumDir);
            if (dir == 180 || dir == 0)
            {
                r = 0;
            }
            else
            {
                float angle = (float)((dir * Math.PI * 2) / 360);
                r = (float)(Math.Sin(angle * -1) * speed);
            }
            return new CValue(r);
        }

        private CValue DirBase(int p1, int p2)
        {
            float r = (float)((p1 * p2) / NumDir);
            return new CValue(r);
        }

    }
}
