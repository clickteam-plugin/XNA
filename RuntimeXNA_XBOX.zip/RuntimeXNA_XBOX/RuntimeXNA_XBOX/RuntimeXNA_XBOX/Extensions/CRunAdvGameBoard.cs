﻿//----------------------------------------------------------------------------------
//
// CRunAdvGameBoard : Advanced Game Board pObject
// fin: 4/10/09
//greyhill
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;

namespace RuntimeXNA.Extensions
{
    class CRunAdvGameBoard : CRunExtension
    {
        const int MOORECEPIENT_CHANNEL = -1;
        public const int CID_conOnFoundConnected = 0;
        public const int CID_conOnFoundBrick = 1;
        public const int CID_conOnFoundLooped = 2;
        public const int CID_conOnNoFoundConnected = 3;
        public const int CID_conBrickCanFallUp = 4;
        public const int CID_conBrickCanFallDown = 5;
        public const int CID_conBrickCanFallLeft = 6;
        public const int CID_conBrickCanFallRight = 7;
        public const int CID_conOnBrickMoved = 8;
        public const int CID_conOnBrickDeleted = 9;
        public const int CID_conIsEmpty = 10;
        const int AID_actSetBrick = 0;
        const int AID_actClear = 1;
        const int AID_actSetBoadSize = 2;
        const int AID_actSetMinConnected = 3;
        const int AID_actSearchHorizontal = 4;
        const int AID_actSearchVertical = 5;
        const int AID_actSearchDiagonalsLR = 6;
        const int AID_actSearchConnected = 7;
        const int AID_actDeleteHorizonal = 8;
        const int AID_actDeleteVertical = 9;
        const int AID_actSwap = 10;
        const int AID_actDropX = 11;
        const int AID_actDropOne = 12;
        const int AID_actMarkUsed = 13;
        const int AID_actDeleteMarked = 14;
        const int AID_actUndoSwap = 15;
        const int AID_actSearchDiagonalsRL = 16;
        const int AID_actLoopFoundBricks = 17;
        const int AID_actSetFixedOfBrick = 18;
        const int AID_actImportActives = 19;
        const int AID_actMarkCurrentSystem = 20;
        const int AID_actMarkCurrentBrick = 21;
        const int AID_actLoopEntireBoard = 22;
        const int AID_actLoopBoardOfType = 23;
        const int AID_actLoopSorrounding = 24;
        const int AID_actLoopHozLine = 25;
        const int AID_actLoopVerLine = 26;
        const int AID_actClearWithType = 27;
        const int AID_actInsertBrick = 28;
        const int AID_actSetOrigin = 29;
        const int AID_actSetCellDimensions = 30;
        const int AID_actMoveFixedON = 31;
        const int AID_actMoveFixedOFF = 32;
        const int AID_actMoveBrick = 33;
        const int AID_actDropOneUp = 34;
        const int AID_actDropOneLeft = 35;
        const int AID_actDropOneRight = 36;
        const int AID_actDropXUp = 37;
        const int AID_actDropXLeft = 38;
        const int AID_actDropXRight = 39;
        const int AID_actSetCellValue = 40;
        const int AID_actDeleteBrick = 41;
        const int AID_actShiftHosLine = 42;
        const int AID_actShiftVerLine = 43;
        const int AID_actPositionBricks = 44;
        const int EID_expGetBrickAt = 0;
        const int EID_expGetXSize = 1;
        const int EID_expGetYSize = 2;
        const int EID_expGetNumBricksInSystem = 3;
        const int EID_expGetXofBrick = 4;
        const int EID_expGetYofBrick = 5;
        const int EID_expGetFoundBrickType = 6;
        const int EID_expGetNumBricksInHozLine = 7;
        const int EID_expGetNumBricksInVerLine = 8;
        const int EID_expCountSorrounding = 9;
        const int EID_expCountTotal = 10;
        const int EID_expGetFoundBrickFixed = 11;
        const int EID_expGetFoundXofBrick = 12;
        const int EID_expGetFoundYofBrick = 13;
        const int EID_expGetTypeofBrick = 14;
        const int EID_expGetFixedOfBrick = 15;
        const int EID_expGetFixedAt = 16;
        const int EID_expLoopIndex = 17;
        const int EID_expFindXfromFixed = 18;
        const int EID_expFindYfromFixed = 19;
        const int EID_expFindBrickfromFixed = 20;
        const int EID_expGetLoopFoundXofBrick = 21;
        const int EID_expGetLoopFoundYofBrick = 22;
        const int EID_expGetLoopTypeofBrick = 23;
        const int EID_expGetLoopFoundBrickFixed = 24;
        const int EID_expLoopLoopIndex = 25;
        const int EID_expGetXBrickFromX = 26;
        const int EID_expGetYBrickFromY = 27;
        const int EID_expSnapXtoGrid = 28;
        const int EID_expSnapYtoGrid = 29;
        const int EID_expGetOriginX = 30;
        const int EID_expGetOriginY = 31;
        const int EID_expGetCellWidth = 32;
        const int EID_expGetCellHeight = 33;
        const int EID_expGetCellValue = 34;
        const int EID_expGetXofCell = 35;
        const int EID_expGetYofCell = 36;
        const int EID_expMovedFixed = 37;
        const int EID_expMovedNewX = 38;
        const int EID_expMovedNewY = 39;
        const int EID_expMovedOldX = 40;
        const int EID_expMovedOldY = 41;
        const int EID_expDeletedFixed = 42;
        const int EID_expDeletedX = 43;
        const int EID_expDeletedY = 44;

        
        public int BSizeX,  BSizeY,  MinConnected,  SwapBrick1,  SwapBrick2,  LoopIndex,  LoopedIndex,  OriginX,  OriginY,  CellWidth,  CellHeight;
        public int[] Board,  StateBoard,  FixedBoard,  CellValues;
        public bool MoveFixed,  TriggerMoved,  TriggerDeleted;
        public int DeletedFixed,  DeletedX,  DeletedY,  MovedFixed,  MovedNewX,  MovedNewY,  MovedOldX,  MovedOldY;
        public int AddIncrement,  SearchBrickType;
        CArrayList Bricks = new CArrayList(); //<Integer>
        CArrayList Looped = new CArrayList(); //<Integer>

        public override int getNumberOfConditions()
        {
            return 11;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            file.skipBytes(8);
            this.BSizeX = file.readAInt();
            this.BSizeY = file.readAInt();
            this.MinConnected = file.readAInt();
            this.SwapBrick1 = 0;
            this.SwapBrick2 = 0;
            this.LoopIndex = 0;
            this.LoopedIndex = 0;

            int size = this.BSizeX * this.BSizeY;
            this.Board = new int[size];
            this.StateBoard = new int[size];
            this.FixedBoard = new int[size];
            this.CellValues = new int[size];

            this.OriginX = file.readAInt();
            this.OriginY = file.readAInt();
            this.CellWidth = file.readAInt();
            this.CellHeight = file.readAInt();
            this.MoveFixed = (file.readAByte() != 0) ? true : false;
            this.TriggerMoved = (file.readAByte() != 0) ? true : false;
            this.TriggerDeleted = (file.readAByte() != 0) ? true : false;

            this.DeletedFixed = -1;
            this.DeletedX = -1;
            this.DeletedY = -1;

            this.MovedFixed = -1;
            this.MovedNewX = -1;
            this.MovedNewY = -1;

            this.MovedOldX = -1;
            this.MovedOldY = -1;

            return true;
        }

        public int getBrick(int x, int y)
        {
            if ((x < this.BSizeX) && (x >= 0) && (y < this.BSizeY) && (y >= 0))
            {
                return this.Board[this.BSizeX * y + x];
            }
            else
            {
                return -1;
            }
        }

        public int getBrickAtPos(int pos)
        {
            if (CHECKPOS(pos))
            {
                return this.Board[pos];
            }
            return 0;
        }

        public bool CHECKPOS(int nPos)
        {
            if (nPos >= 0 && nPos < this.BSizeX * this.BSizeY)
            {
                return true;
            }
            return false;
        }

        public int getPos(int x, int y)
        {
            if ((x < this.BSizeX) && (x >= 0) && (y < this.BSizeY) && (y >= 0))
            {
                return this.BSizeX * y + x;
            }
            else
            {
                return -1;
            }
        }

        public int getXbrick(int pos)
        {
            return pos % this.BSizeX;
        }

        public int getYbrick(int pos)
        {
            return pos / this.BSizeX;
        }

        public void setBrick(int x, int y, int value)
        {
            if (CHECKPOS(getPos(x, y)))
            {
                this.Board[getPos(x, y)] = value;
            }
        }

        public int getFixed(int x, int y)
        {
            if ((x < this.BSizeX) && (x >= 0) && (y < this.BSizeY) && (y >= 0))
            {
                return this.FixedBoard[this.BSizeX * y + x];
            }
            else
            {
                return -1;
            }
        }

        void setFixed(int x, int y, int value)
        {
            if (CHECKPOS(getPos(x, y)))
            {
                this.FixedBoard[getPos(x, y)] = value;
            }
        }

        public int wrapX(int shift)
        {
            return (shift >= 0) ? (shift % this.BSizeX) : this.BSizeX + (shift % this.BSizeX);
        }

        public int wrapY(int shift)
        {
            return (shift >= 0) ? (shift % this.BSizeY) : this.BSizeY + (shift % this.BSizeY);
        }

        public void MoveBrick(int sourceX, int sourceY, int destX, int destY)
        {

            if ((getPos(destX, destY) != -1) && (getPos(sourceX, sourceY) != -1))
            {
                bool triggerdeletedflag = false;
                bool triggermovedflag = false;

                if (this.TriggerMoved)
                {
                    this.MovedFixed = getFixed(sourceX, sourceY);
                    this.MovedNewX = destX;
                    this.MovedNewY = destY;
                    this.MovedOldX = sourceX;
                    this.MovedOldY = sourceY;
                    triggermovedflag = true;
                }

                if (this.TriggerDeleted && getBrick(destX, destY) != 0)
                {
                    this.DeletedFixed = getFixed(destX, destY);
                    this.DeletedX = destX;
                    this.DeletedY = destY;
                    triggerdeletedflag = true;
                }

                // Move the brick
                if (CHECKPOS(getPos(destX, destY)) && CHECKPOS(getPos(sourceX, sourceY)))
                {
                    this.Board[getPos(destX, destY)] = Board[getPos(sourceX, sourceY)];
                    this.Board[getPos(sourceX, sourceY)] = 0;

                    if (this.MoveFixed)
                    {
                        this.FixedBoard[getPos(destX, destY)] = this.FixedBoard[getPos(sourceX, sourceY)];
                        this.FixedBoard[getPos(sourceX, sourceY)] = 0;
                    }
                }
                if (triggermovedflag)
                {
                    ho.generateEvent(CID_conOnBrickMoved, ho.getEventParam());
                }
                if (triggerdeletedflag)
                {
                    ho.generateEvent(CID_conOnBrickDeleted, ho.getEventParam());
                }
            }
        }

        public void fall()
        {
            for (int x = 0; x < BSizeX; x++)
            {
                for (int y = BSizeY - 2; y >= 0; y--)
                {
                    if (getBrick(x, y + 1) == 0)
                    {
                        MoveBrick(x, y, x, y + 1);
                    }
                }
            }
        }

        public void fallUP()
        {
            for (int x = 0; x < BSizeX; x++)
            {
                for (int y = 1; y <= BSizeY - 1; y++)
                {
                    if (getBrick(x, y - 1) == 0)
                    {
                        MoveBrick(x, y, x, y - 1);
                    }
                }
            }
        }

        public void fallLEFT()
        {
            for (int y = 0; y <= BSizeY; y++)
            {
                for (int x = 1; x < BSizeX; x++)
                {
                    if (getBrick(x - 1, y) == 0)
                    {
                        MoveBrick(x, y, x - 1, y);
                    }
                }
            }
        }

        public void fallRIGHT()
        {
            for (int y = 0; y <= BSizeY; y++)
            {
                for (int x = BSizeX - 2; x >= 0; x--)
                {
                    if (getBrick(x + 1, y) == 0)
                    {
                        MoveBrick(x, y, x + 1, y);
                    }
                }
            }
        }

        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case CID_conOnFoundConnected:
                    return true;
                case CID_conOnFoundBrick:
                    return true;
                case CID_conOnFoundLooped:
                    return true;
                case CID_conOnNoFoundConnected:
                    return true;
                case CID_conBrickCanFallUp:
                    return conBrickCanFallUp(cnd.getParamExpression(rh, 0), cnd.getParamExpression(rh, 1));
                case CID_conBrickCanFallDown:
                    return conBrickCanFallDown(cnd.getParamExpression(rh, 0), cnd.getParamExpression(rh, 1));
                case CID_conBrickCanFallLeft:
                    return conBrickCanFallLeft(cnd.getParamExpression(rh, 0), cnd.getParamExpression(rh, 1));
                case CID_conBrickCanFallRight:
                    return conBrickCanFallRight(cnd.getParamExpression(rh, 0), cnd.getParamExpression(rh, 1));
                case CID_conOnBrickMoved:
                    return true;
                case CID_conOnBrickDeleted:
                    return true;
                case CID_conIsEmpty:
                    return conIsEmpty(cnd.getParamExpression(rh, 0), cnd.getParamExpression(rh, 1));
            }
            return false;
        }

        private bool conBrickCanFallUp(int x, int y)
        {
            int tempbrick = 0;
            int currentbrick = getBrick(x, y);
            int belowbrick = getBrick(x, y + 1);

            if (belowbrick == -1 || currentbrick == 0 || currentbrick == -1)
            {
                return false;
            }

            for (int i = y; i >= 0; i--)
            {
                tempbrick = getBrick(x, i);

                if (tempbrick == 0)
                {
                    return true;
                }
            }
            return false;
        }

        private bool conBrickCanFallDown(int x, int y)
        {
            int tempbrick = 0;
            int currentbrick = getBrick(x, y);
            int belowbrick = getBrick(x, y + 1);

            if (belowbrick == -1 || currentbrick == 0 || currentbrick == -1)
            {
                return false;
            }

            for (int i = y; i <= BSizeY - 1; i++)
            {
                tempbrick = getBrick(x, i);

                if (tempbrick == 0)
                {
                    return true;
                }
            }
            return false;
        }

        private bool conBrickCanFallLeft(int x, int y)
        {
            int tempbrick = 0;
            int currentbrick = getBrick(x, y);
            int belowbrick = getBrick(x - 1, y);

            if (belowbrick == -1 || currentbrick == 0 || currentbrick == -1)
            {
                return false;
            }

            for (int i = x; i >= 0; i--)
            {
                tempbrick = getBrick(i, y);

                if (tempbrick == 0)
                {
                    return true;
                }
            }
            return false;
        }

        private bool conBrickCanFallRight(int x, int y)
        {
            int tempbrick = 0;
            int currentbrick = getBrick(x, y);
            int belowbrick = getBrick(x + 1, y);

            if (belowbrick == -1 || currentbrick == 0 || currentbrick == -1)
            {
                return false;
            }

            for (int i = x; i <= BSizeX - 1; i++)
            {
                tempbrick = getBrick(i, y);

                if (tempbrick == 0)
                {
                    return true;
                }
            }
            return false;
        }

        private bool conIsEmpty(int x, int y)
        {
            if (getBrick(x, y) == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case AID_actSetBrick:
                    actSetBrick(act.getParamExpression(rh, 0),
                            act.getParamExpression(rh, 1),
                            act.getParamExpression(rh, 2));
                    break;
                case AID_actClear:
                    actClear();
                    break;
                case AID_actSetBoadSize:
                    actSetBoadSize(act.getParamExpression(rh, 0),
                            act.getParamExpression(rh, 1));
                    break;
                case AID_actSetMinConnected:
                    MinConnected = act.getParamExpression(rh, 0);
                    break;
                case AID_actSearchHorizontal:
                    actSearchHorizontal(act.getParamExpression(rh, 0));
                    break;
                case AID_actSearchVertical:
                    actSearchVertical(act.getParamExpression(rh, 0));
                    break;
                case AID_actSearchDiagonalsLR:
                    actSearchDiagonalsLR(act.getParamExpression(rh, 0));
                    break;
                case AID_actSearchConnected:
                    actSearchConnected(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case AID_actDeleteHorizonal:
                    actDeleteHorizonal(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case AID_actDeleteVertical:
                    actDeleteVertical(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case AID_actSwap:
                    actSwap(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1),
                            act.getParamExpression(rh, 2), act.getParamExpression(rh, 3));
                    break;
                case AID_actDropX:
                    actDropX(act.getParamExpression(rh, 0));
                    break;
                case AID_actDropOne:
                    fall();
                    break;
                case AID_actMarkUsed:
                    actMarkUsed(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case AID_actDeleteMarked:
                    actDeleteMarked();
                    break;
                case AID_actUndoSwap:
                    actUndoSwap();
                    break;
                case AID_actSearchDiagonalsRL:
                    actSearchDiagonalsRL(act.getParamExpression(rh, 0));
                    break;
                case AID_actLoopFoundBricks:
                    actLoopFoundBricks();
                    break;
                case AID_actSetFixedOfBrick:
                    actSetFixedOfBrick(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1), act.getParamExpression(rh, 2));
                    break;
                case AID_actImportActives:
                    actImportActives(act.getParamObject(rh, 0));
                    break;
                case AID_actMarkCurrentSystem:
                    actMarkCurrentSystem();
                    break;
                case AID_actMarkCurrentBrick:
                    actMarkCurrentBrick();
                    break;
                case AID_actLoopEntireBoard:
                    actLoopEntireBoard();
                    break;
                case AID_actLoopBoardOfType:
                    actLoopBoardOfType(act.getParamExpression(rh, 0));
                    break;
                case AID_actLoopSorrounding:
                    actLoopSorrounding(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case AID_actLoopHozLine:
                    actLoopHozLine(act.getParamExpression(rh, 0));
                    break;
                case AID_actLoopVerLine:
                    actLoopVerLine(act.getParamExpression(rh, 0));
                    break;
                case AID_actClearWithType:
                    actClearWithType(act.getParamExpression(rh, 0));
                    break;
                case AID_actInsertBrick:
                    actInsertBrick(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1), act.getParamExpression(rh, 2));
                    break;
                case AID_actSetOrigin:
                    OriginX = act.getParamExpression(rh, 0);
                    OriginY = act.getParamExpression(rh, 1);
                    break;
                case AID_actSetCellDimensions:
                    actSetCellDimensions(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case AID_actMoveFixedON:
                    MoveFixed = true;
                    break;
                case AID_actMoveFixedOFF:
                    MoveFixed = false;
                    break;
                case AID_actMoveBrick:
                    MoveBrick(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1),
                            act.getParamExpression(rh, 2), act.getParamExpression(rh, 3));
                    break;
                case AID_actDropOneUp:
                    fallUP();
                    break;
                case AID_actDropOneLeft:
                    fallLEFT();
                    break;
                case AID_actDropOneRight:
                    fallRIGHT();
                    break;
                case AID_actDropXUp:
                    actDropXUp(act.getParamExpression(rh, 0));
                    break;
                case AID_actDropXLeft:
                    actDropXLeft(act.getParamExpression(rh, 0));
                    break;
                case AID_actDropXRight:
                    actDropXRight(act.getParamExpression(rh, 0));
                    break;
                case AID_actSetCellValue:
                    actSetCellValue(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1), act.getParamExpression(rh, 2));
                    break;
                case AID_actDeleteBrick:
                    actDeleteBrick(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case AID_actShiftHosLine:
                    actShiftHosLine(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case AID_actShiftVerLine:
                    actShiftVerLine(act.getParamExpression(rh, 0), act.getParamExpression(rh, 1));
                    break;
                case AID_actPositionBricks:
                    actPositionBricks();
                    break;
            }
        }

        private void actSetBrick(int x, int y, int brickType)
        {
            setBrick(x, y, brickType);
        }

        private void actClear()
        {
            int size = BSizeX * BSizeY;
            for (int i = 0; i < size; i++)
            {
                Board[i] = 0;
            }
        }

        private void actSetBoadSize(int x, int y)
        {
            BSizeX = x; //Update size
            BSizeY = y;
            int size = BSizeX * BSizeY;
            Board = new int[size];  //Create new array
            StateBoard = new int[size];
            FixedBoard = new int[size];
            CellValues = new int[size];
        }

        private void actSearchHorizontal(int brickType)
        {
            SearchBrickType = brickType;
            int SizeX = BSizeX;
            int SizeY = BSizeY;
            int Found = 0;
            Bricks.clear();
            int FoundTotal = 0;

            for (int y = 0; y < SizeY; y++)
            {
                Found = 0;
                Bricks.clear();

                for (int x = 0; x < SizeX; x++)
                {
                    if (getBrick(x, y) == brickType)
                    {
                        Found++;
                        if (CHECKPOS(getPos(x, y)))
                        {
                            if (StateBoard[getPos(x, y)] == 0)
                            {
                                Bricks.add((int)getPos(x, y));
                            }
                        }
                    }
                    else
                    {
                        if (Found >= MinConnected)
                        {
                            ho.generateEvent(CID_conOnFoundConnected, ho.getEventParam());
                            FoundTotal++;
                        }
                        Found = 0;
                        Bricks.clear();
                    }

                }
                if (Found >= MinConnected)
                {
                    ho.generateEvent(CID_conOnFoundConnected, ho.getEventParam());
                    FoundTotal++;
                }
                Found = 0;
                Bricks.clear();
            }

            if (FoundTotal == 0)
            {
                ho.generateEvent(CID_conOnNoFoundConnected, ho.getEventParam());
            }
        }

        private void actSearchVertical(int brickType)
        {
            SearchBrickType = brickType;
            int SizeX = BSizeX;
            int SizeY = BSizeY;
            int Found = 0;
            Bricks.clear();
            int FoundTotal = 0;

            for (int x = 0; x < SizeX; x++)
            {
                Found = 0;
                Bricks.clear();

                for (int y = 0; y < SizeY; y++)
                {
                    if (getBrick(x, y) == brickType)
                    {
                        Found++;
                        if (CHECKPOS(getPos(x, y)))
                        {
                            if (StateBoard[getPos(x, y)] == 0)
                            {
                                Bricks.add((int)getPos(x, y));
                            }
                        }
                    }
                    else
                    {	//Trigger condition
                        if (Found >= MinConnected)
                        {
                            ho.generateEvent(CID_conOnFoundConnected, ho.getEventParam());
                            FoundTotal++;
                        }
                        Found = 0;
                        Bricks.clear();
                    }

                } // Trigger condition
                if (Found >= MinConnected)
                {
                    ho.generateEvent(CID_conOnFoundConnected, ho.getEventParam());
                    FoundTotal++;
                }
                Found = 0;
                Bricks.clear();
            }
            if (FoundTotal == 0)
            {
                ho.generateEvent(CID_conOnNoFoundConnected, ho.getEventParam());
            }
        }

        private void actSearchDiagonalsLR(int brickType)
        {
            int around = BSizeY + BSizeX + 2;
            int startoffX = 0;
            int startoffY = BSizeY;
            int loopindex = 0;
            int foundtotal = 0;
            int foundbricks = 0;

            for (int i = 0; i < around; i++)
            {
                if (startoffY == 0)
                {
                    startoffX++;
                }

                if (startoffY > 0)
                {
                    startoffY--;
                }

                loopindex = 0;
                Bricks.clear();
                foundbricks = 0;

                while ((getPos(startoffX + loopindex, startoffY + loopindex) != -1))
                {
                    if (getBrick(startoffX + loopindex, startoffY + loopindex) == brickType)
                    {
                        foundbricks++;

                        if (CHECKPOS(getPos(startoffX + loopindex, startoffY + loopindex)))
                        {
                            if (StateBoard[getPos(startoffX + loopindex, startoffY + loopindex)] == 0)
                            {
                                Bricks.add((int)(getPos(startoffX + loopindex, startoffY + loopindex)));
                            }
                        }
                    }
                    else
                    {

                        if (foundbricks >= MinConnected)
                        {
                            ho.generateEvent(CID_conOnFoundConnected, ho.getEventParam());
                            foundtotal++;
                        }

                        Bricks.clear();
                        foundbricks = 0;
                    }
                    loopindex++;
                }

                if (foundbricks >= MinConnected)
                {
                    ho.generateEvent(CID_conOnFoundConnected, ho.getEventParam());
                    foundtotal++;
                }
            }
            if (foundtotal == 0)
            {
                ho.generateEvent(CID_conOnNoFoundConnected, ho.getEventParam());
            }
        }

        private void actSearchConnected(int startX, int startY)
        {
            int FindBrick = getBrick(startX, startY);
            int size = BSizeX * BSizeY;
            int FoundTotal = 0;

            int[] Used = new int[size];

            CArrayList BrickList = new CArrayList(); //<Integer>
            BrickList.add((int)(getPos(startX, startY)));

            if (CHECKPOS(getPos(startX, startY)))
            {
                Used[getPos(startX, startY)] = 1;
            }

            Bricks.clear();
            Bricks.add((int)(getPos(startX, startY)));

            int currentbrick = 0;
            int currentX = 0;
            int currentY = 0;

            int[] offsetX =
            {
                0, -1, 1, 0
            };
            int[] offsetY =
            {
                -1, 0, 0, 1
            };

            //char * temp ="";

            while (BrickList.size() > 0)
            {
                currentX = getXbrick(((int) BrickList.get(0)));
                currentY = getYbrick(((int) BrickList.get(0)));
                for (int dir = 0; dir < 4; dir++) //Loop around brick
                {
                    currentbrick = getPos(currentX + offsetX[dir], currentY + offsetY[dir]);
                    if (CHECKPOS(currentbrick))
                    {
                        if ((Board[currentbrick] == FindBrick) && (Used[currentbrick] == 0) && (currentbrick != -1))
                        {
                            BrickList.add((int)(currentbrick));
                            Bricks.add((int)(currentbrick));
                            Used[currentbrick] = 1;
                        }
                    }
                }
                BrickList.remove(0);
            }
            if (Bricks.size() >= MinConnected)
            {
                ho.generateEvent(CID_conOnFoundConnected, ho.getEventParam());
                FoundTotal++;
            }

            BrickList.clear();

            if (FoundTotal == 0)
            {
                ho.generateEvent(CID_conOnNoFoundConnected, ho.getEventParam());
            }

        }

        private void actDeleteHorizonal(int y, int mode)
        {
            for (int del = 0; del < BSizeX; del++)
            {
                if (CHECKPOS(getPos(del, y)))
                {
                    bool triggerdeletedflag = false;
                    if (TriggerDeleted)
                    {
                        DeletedFixed = FixedBoard[getPos(del, y)];
                        DeletedX = del;
                        DeletedY = y;
                        triggerdeletedflag = true;
                    }

                    Board[getPos(del, y)] = 0;
                    if (MoveFixed)
                    {
                        FixedBoard[getPos(del, y)] = 0;
                    }

                    if (triggerdeletedflag)
                    {
                        ho.generateEvent(CID_conOnBrickDeleted, ho.getEventParam());
                    }
                }
            }

            if (mode == 1) //MOVE ABOVE DOWNWARDS
            {
                for (int udX = 0; udX < BSizeX; udX++)
                {
                    for (int udY = y - 1; udY >= 0; udY--)
                    {
                        MoveBrick(udX, udY, udX, udY + 1);
                    }
                }
            }

            if (mode == 2) //MOVE BELOW UPWARDS
            {
                for (int udX = 0; udX < BSizeX; udX++)
                {
                    for (int udY = y + 1; udY < BSizeY; udY++)
                    {
                        MoveBrick(udX, udY, udX, udY - 1);
                    }
                }
            }
        }

        private void actDeleteVertical(int x, int mode)
        {
            for (int del = 0; del < BSizeY; del++)
            {
                if (CHECKPOS(getPos(x, del)))
                {
                    bool triggerdeletedflag = false;
                    if (TriggerDeleted)
                    {
                        DeletedFixed = FixedBoard[getPos(x, del)];
                        DeletedX = x;
                        DeletedY = del;
                        triggerdeletedflag = true;
                    }

                    Board[getPos(x, del)] = 0;
                    if (MoveFixed)
                    {
                        FixedBoard[getPos(x, del)] = 0;
                    }

                    if (triggerdeletedflag)
                    {
                        ho.generateEvent(CID_conOnBrickDeleted, ho.getEventParam());
                    }
                }
            }

            if (mode == 1) //MOVE LEFT TO RIGHT ->-> ||
            {
                for (int lrY = 0; lrY < BSizeY; lrY++)
                {
                    for (int lrX = x - 1; lrX >= 0; lrX--)
                    {
                        MoveBrick(lrX, lrY, lrX + 1, lrY);
                    }
                }
            }
            if (mode == 2) //MOVE RIGHT TO LEFT   || <-<-
            {
                for (int lrY = 0; lrY < BSizeY; lrY++)
                {
                    for (int lrX = x + 1; lrX < BSizeX; lrX++)
                    {
                        MoveBrick(lrX, lrY, lrX - 1, lrY);
                    }
                }
            }
        }

        private void actSwap(int x1, int y1, int x2, int y2)
        {
            SwapBrick1 = getPos(x1, y1);  //Brick 1
            SwapBrick2 = getPos(x2, y2);  //Brick 2

            if (CHECKPOS(SwapBrick1) && CHECKPOS(SwapBrick2))
            {
                int temp = Board[SwapBrick1];
                int tempfixed = FixedBoard[SwapBrick1];

                Board[SwapBrick1] = Board[SwapBrick2];
                Board[SwapBrick2] = temp;

                if (MoveFixed)
                {
                    FixedBoard[SwapBrick1] = FixedBoard[SwapBrick2];
                    FixedBoard[SwapBrick2] = tempfixed;
                }

                if (TriggerMoved)
                {
                    MovedFixed = FixedBoard[SwapBrick1];
                    MovedNewX = x1;
                    MovedNewY = y1;
                    MovedOldX = x2;
                    MovedOldY = y2;
                    ho.generateEvent(CID_conOnBrickMoved, ho.getEventParam());

                    MovedFixed = FixedBoard[SwapBrick2];
                    MovedNewX = x2;
                    MovedNewY = y2;
                    MovedOldX = x1;
                    MovedOldY = y1;
                    ho.generateEvent(CID_conOnBrickMoved, ho.getEventParam());
                }
            }
        }

        private void actDropX(int n)
        {
            for (int i = 0; i < n; i++)
            {
                fall();
            }
        }

        private void actMarkUsed(int x, int y)
        {
            if (CHECKPOS(getPos(x, y)))
            {
                StateBoard[getPos(x, y)] = 1;
            }
        }

        private void actDeleteMarked()
        {
            int size = BSizeX * BSizeY;
            bool triggerdeleteflag = false;

            for (int i = 0; i < size; i++)
            {
                triggerdeleteflag = false;
                if (StateBoard[i] == 1)
                {
                    if (TriggerDeleted)
                    {
                        DeletedFixed = FixedBoard[i];
                        DeletedX = getXbrick(i);
                        DeletedY = getYbrick(i);
                        triggerdeleteflag = true;
                    }

                    Board[i] = 0;
                    StateBoard[i] = 0;

                    if (MoveFixed)
                    {
                        FixedBoard[i] = 0;
                    }

                    if (triggerdeleteflag)
                    {
                        ho.generateEvent(CID_conOnBrickDeleted, ho.getEventParam());
                    }
                }
            }
        }

        private void actUndoSwap()
        {
            if (CHECKPOS(SwapBrick1) && CHECKPOS(SwapBrick2))
            {
                int temp = Board[SwapBrick1];
                int tempfixed = FixedBoard[SwapBrick1];

                Board[SwapBrick1] = Board[SwapBrick2];
                Board[SwapBrick2] = temp;

                if (MoveFixed)
                {
                    FixedBoard[SwapBrick1] = FixedBoard[SwapBrick2];
                    FixedBoard[SwapBrick2] = tempfixed;
                }

                if (TriggerMoved)
                {
                    MovedFixed = FixedBoard[SwapBrick1];
                    MovedNewX = getXbrick(SwapBrick1);
                    MovedNewY = getYbrick(SwapBrick1);
                    MovedOldX = getXbrick(SwapBrick2);
                    MovedOldY = getYbrick(SwapBrick2);
                    ho.generateEvent(CID_conOnBrickMoved, ho.getEventParam());

                    MovedFixed = FixedBoard[SwapBrick2];
                    MovedNewX = getXbrick(SwapBrick2);
                    MovedNewY = getYbrick(SwapBrick2);
                    MovedOldX = getXbrick(SwapBrick1);
                    MovedOldY = getYbrick(SwapBrick1);
                    ho.generateEvent(CID_conOnBrickMoved, ho.getEventParam());
                }
            }
        }

        private void actSearchDiagonalsRL(int brickType)
        {

            int around = BSizeY + BSizeX + 2;
            int startoffX = BSizeX - 1;
            int startoffY = BSizeY;
            int loopindex = 0;
            int foundtotal = 0;
            int foundbricks = 0;

            for (int i = 0; i < around; i++)
            {
                if (startoffY == 0)
                {
                    startoffX--;
                }

                if (startoffY > 0)
                {
                    startoffY--;
                }

                loopindex = 0;
                foundbricks = 0;
                Bricks.clear();

                while ((getPos(startoffX - loopindex, startoffY + loopindex) != -1))
                {
                    if (getBrick(startoffX - loopindex, startoffY + loopindex) == brickType)
                    {
                        foundbricks++;

                        if (CHECKPOS(getPos(startoffX - loopindex, startoffY + loopindex)))
                        {
                            if (StateBoard[getPos(startoffX - loopindex, startoffY + loopindex)] == 0)
                            {
                                Bricks.add((int)(getPos(startoffX - loopindex, startoffY + loopindex)));
                            }
                        }
                    }
                    else
                    {

                        if (foundbricks >= MinConnected)
                        {
                            ho.generateEvent(CID_conOnFoundConnected, ho.getEventParam());
                            foundtotal++;
                        }

                        Bricks.clear();
                        foundbricks = 0;
                    }

                    loopindex++;
                }

                if (foundbricks >= MinConnected)
                {
                    ho.generateEvent(CID_conOnFoundConnected, ho.getEventParam());
                    foundtotal++;
                }

            }
            if (foundtotal == 0)
            {
                ho.generateEvent(CID_conOnNoFoundConnected, ho.getEventParam());
            }
        }

        private void actLoopFoundBricks()
        {
            for (int loop = 0; loop < Bricks.size(); loop++)
            {
                LoopIndex = loop;
                ho.generateEvent(CID_conOnFoundBrick, ho.getEventParam());
            }
        }

        private void actSetFixedOfBrick(int x, int y, int fv)
        {
            if (CHECKPOS(getPos(x, y)))
            {
                FixedBoard[getPos(x, y)] = fv;
            }
        }

        private void actImportActives(CObject selected)
        {
            int size = BSizeX * BSizeY;
            if (CHECKPOS(size - AddIncrement - 1))
            {
                FixedBoard[size - AddIncrement - 1] = (selected.hoCreationId << 16) + selected.hoNumber;
            }
            AddIncrement++;
        }

        private void actMarkCurrentSystem()
        {
            for (int i = 0; i < Bricks.size(); i++)
            {
                if (CHECKPOS(((int) Bricks.get(i))))
                {
                    StateBoard[((int) Bricks.get(i))] = 1;
                }
            //MessageBox(NULL, "Brick marked in system" , "Brick marked", MB_ICONEXCLAMATION);
            }
        }

        private void actMarkCurrentBrick()
        {
            if (CHECKPOS(((int) Bricks.get(LoopIndex))))
            {
                StateBoard[((int) Bricks.get(LoopIndex))] = 1;
            }
        //MessageBox(NULL, "Brick marked" , "Brick marked", MB_ICONEXCLAMATION);
        }

        private void actLoopEntireBoard()
        {
            int size = BSizeX * BSizeY;
            Looped.clear();

            for (int i = 0; i < size; i++)
            {
                Looped.add((int)i);
            }

            for (int u = 0; u < Looped.size(); u++)
            {
                LoopedIndex = u;
                ho.generateEvent(CID_conOnFoundLooped, ho.getEventParam());
            }
        }

        private void actLoopBoardOfType(int brickType)
        {
            int size = BSizeX * BSizeY;
            Looped.clear();

            for (int i = 0; i < size; i++)
            {
                if (Board[i] == brickType)
                {
                    Looped.add((int)i);
                }
            }
            for (int u = 0; u < Looped.size(); u++)
            {
                LoopedIndex = u;
                ho.generateEvent(CID_conOnFoundLooped, ho.getEventParam());
            }
        }

        private void actLoopSorrounding(int x, int y)
        {
            Looped.clear();

            int[] offsetX=
            {
                -1, 0, 1, -1, 1, -1, 0, 1
            };
            int[] offsetY =
            {
                -1, -1, -1, 0, 0, 1, 1, 1
            };

            for (int i = 0; i < 8; i++)
            {
                if (getBrick(x + offsetX[i], y + offsetY[i]) != -1)
                {
                    Looped.add((int)(getPos(x + offsetX[i], y + offsetY[i])));
                }
            }

            for (int u = 0; u < Looped.size(); u++)
            {
                LoopedIndex = u;
                ho.generateEvent(CID_conOnFoundLooped, ho.getEventParam());
            }
        }

        private void actLoopHozLine(int y)
        {
            Looped.clear();
            for (int i = 0; i < BSizeX; i++)
            {
                Looped.add((int)(getPos(i, y)));
            }

            for (int u = 0; u < Looped.size(); u++)
            {
                LoopedIndex = u;
                ho.generateEvent(CID_conOnFoundLooped, ho.getEventParam());
            }
        }

        private void actLoopVerLine(int x)
        {
            Looped.clear();
            for (int i = 0; i < BSizeY; i++)
            {
                Looped.add((int)(getPos(x, i)));
            }

            for (int u = 0; u < Looped.size(); u++)
            {
                LoopedIndex = u;
                ho.generateEvent(CID_conOnFoundLooped, ho.getEventParam());
            }
        }

        private void actClearWithType(int brickType)
        {
            int size = BSizeX * BSizeY;
            for (int i = 0; i < size; i++)
            {
                Board[i] = brickType;
            }
        }

        private void actInsertBrick(int x, int y, int brickType)
        {
            int size = BSizeX * BSizeY;
            bool triggerdeletedflag = false;

            if (TriggerDeleted && Board[size - 1] != 0)
            {
                DeletedFixed = FixedBoard[size - 1];
                DeletedX = getXbrick(size - 1);
                DeletedY = getYbrick(size - 1);
                triggerdeletedflag = true;
            }

            for (int i = size - 2; i > getPos(x, y); i--)
            {
                MoveBrick(getXbrick(i), getYbrick(i), getXbrick(i) + 1, getYbrick(i));
            }

            if (CHECKPOS(getPos(x, y)))
            {
                Board[getPos(x, y)] = brickType;

                if (MoveFixed)
                {
                    FixedBoard[getPos(x, y)] = 0;
                }
            }

            if (triggerdeletedflag && TriggerDeleted)
            {
                ho.generateEvent(CID_conOnBrickDeleted, ho.getEventParam());
            }
        }

        private void actSetCellDimensions(int x, int y)
        {
            CellWidth = x;
            CellHeight = y;
            if (CellWidth == 0)
            {
                CellWidth = 1;
            }
            if (CellHeight == 0)
            {
                CellHeight = 1;
            }
        }

        private void actDropXUp(int n)
        {
            for (int i = 0; i < n; i++)
            {
                fallUP();
            }
        }

        private void actDropXLeft(int n)
        {
            for (int i = 0; i < n; i++)
            {
                fallLEFT();
            }
        }

        private void actDropXRight(int n)
        {
            for (int i = 0; i < n; i++)
            {
                fallRIGHT();
            }
        }

        private void actSetCellValue(int x, int y, int value)
        {
            if (getPos(x, y) != -1)
            {
                CellValues[getPos(x, y)] = value;
            }
        }

        private void actDeleteBrick(int x, int y)
        {
            if (TriggerDeleted)
            {
                DeletedFixed = getFixed(x, y);
                DeletedX = x;
                DeletedY = y;
            }

            setBrick(x, y, 0);

            if (TriggerDeleted)
            {
                ho.generateEvent(CID_conOnBrickDeleted, ho.getEventParam());
            }
        }

        private void actShiftHosLine(int yline, int shift)
        {
            int[] templine = new int[BSizeX];
            int[] tempfixed = new int[BSizeX];

            //write to templine
            for (int i = 0; i < BSizeX; i++)
            {
                templine[i] = getBrick(wrapX(i - shift), yline);
                tempfixed[i] = getFixed(wrapX(i - shift), yline);
            }

            for (int j = 0; j < BSizeX; j++)
            {
                if (TriggerMoved)
                {
                    MovedOldX = j;
                    MovedOldY = yline;
                    MovedNewX = wrapX(j + shift);
                    MovedNewY = yline;
                    MovedFixed = getFixed(j, yline);
                }

                setBrick(j, yline, templine[j]);

                if (MoveFixed)
                {
                    setFixed(j, yline, tempfixed[j]);
                }

                if (TriggerMoved)
                {
                    ho.generateEvent(CID_conOnBrickMoved, ho.getEventParam());
                }
            }
        }

        private void actShiftVerLine(int xline, int shift)
        {
            int[] templine = new int[BSizeY];
            int[] tempfixed = new int[BSizeY];

            //write to templine
            for (int i = 0; i < BSizeY; i++)
            {
                templine[i] = getBrick(xline, wrapY(i - shift));
                tempfixed[i] = getFixed(xline, wrapY(i - shift));
            }

            for (int j = 0; j < BSizeY; j++)
            {
                if (TriggerMoved)
                {
                    MovedOldX = xline;
                    MovedOldY = j;
                    MovedNewX = xline;
                    MovedNewY = wrapY(j + shift);
                    MovedFixed = getFixed(xline, j);
                }

                setBrick(xline, j, templine[j]);

                if (MoveFixed)
                {
                    setFixed(xline, j, tempfixed[j]);
                }

                if (TriggerMoved)
                {
                    ho.generateEvent(CID_conOnBrickMoved, ho.getEventParam());
                }
            }
        }

        private CObject CObjectFromFixed(int fix)
        {
            CObject[] list = ho.hoAdRunHeader.rhObjectList;
            for (int i = 0; i < list.Length; i++)
            {
                if (list[i] != null)
                {
                    if (((list[i].hoCreationId << 16) + list[i].hoNumber) == fix)
                    {
                        return list[i];
                    }
                }
            }
            return null;
        }

        private void actPositionBricks()
        {
            int size = BSizeX * BSizeY;
            int fix = 0;
            CObject active;
            int posX = 0;
            int posY = 0;

            for (int i = 0; i < size; i++)
            {
                fix = FixedBoard[i];
                active = CObjectFromFixed(fix);
                posX = getXbrick(i);
                posY = getYbrick(i);

                if (active != null && fix > 0)
                {
                    active.hoX = CellWidth * posX + OriginX;
                    active.hoY = CellHeight * posY + OriginY;
                    active.roc.rcChanged = true;
                }

            }
        }

        public CValue get(int num)
        {
            switch (num)
            {
                case EID_expGetBrickAt:
                    return new CValue(getBrick(ho.getExpParam().getInt(), ho.getExpParam().getInt()));
                case EID_expGetXSize:
                    return new CValue(BSizeX);
                case EID_expGetYSize:
                    return new CValue(BSizeY);
                case EID_expGetNumBricksInSystem:
                    return new CValue(Bricks.size());
                case EID_expGetXofBrick:
                    return expGetXofBrick(ho.getExpParam().getInt());
                case EID_expGetYofBrick:
                    return expGetYofBrick(ho.getExpParam().getInt());
                case EID_expGetFoundBrickType:
                    return new CValue(SearchBrickType);
                case EID_expGetNumBricksInHozLine:
                    return expGetNumBricksInHozLine(ho.getExpParam().getInt());
                case EID_expGetNumBricksInVerLine:
                    return expGetNumBricksInVerLine(ho.getExpParam().getInt());
                case EID_expCountSorrounding:
                    return expCountSorrounding(ho.getExpParam().getInt(), ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EID_expCountTotal:
                    return expCountTotal();
                case EID_expGetFoundBrickFixed:
                    return expGetFoundBrickFixed(ho.getExpParam().getInt());
                case EID_expGetFoundXofBrick:
                    return new CValue(getXbrick(((int) Bricks.get(LoopIndex))));
                case EID_expGetFoundYofBrick:
                    return new CValue(getYbrick(((int) Bricks.get(LoopIndex))));
                case EID_expGetTypeofBrick:
                    return new CValue(SearchBrickType);
                case EID_expGetFixedOfBrick:
                    return expGetFixedOfBrick();
                case EID_expGetFixedAt:
                    return expGetFixedAt(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EID_expLoopIndex:
                    return new CValue(LoopIndex);
                case EID_expFindXfromFixed:
                    return expFindXfromFixed(ho.getExpParam().getInt());
                case EID_expFindYfromFixed:
                    return expFindYfromFixed(ho.getExpParam().getInt());
                case EID_expFindBrickfromFixed:
                    return expFindBrickfromFixed(ho.getExpParam().getInt());
                case EID_expGetLoopFoundXofBrick:
                    return new CValue(getXbrick(((int) Looped.get(LoopedIndex))));
                case EID_expGetLoopFoundYofBrick:
                    return new CValue(getYbrick(((int) Looped.get(LoopedIndex))));
                case EID_expGetLoopTypeofBrick:
                    return new CValue(getBrickAtPos(((int) Looped.get(LoopedIndex))));
                case EID_expGetLoopFoundBrickFixed:
                    return expGetLoopFoundBrickFixed();
                case EID_expLoopLoopIndex:
                    return new CValue(LoopIndex);
                case EID_expGetXBrickFromX:
                    return expGetXBrickFromX(ho.getExpParam().getInt());
                case EID_expGetYBrickFromY:
                    return expGetYBrickFromY(ho.getExpParam().getInt());
                case EID_expSnapXtoGrid:
                    return expSnapXtoGrid(ho.getExpParam().getInt());
                case EID_expSnapYtoGrid:
                    return expSnapYtoGrid(ho.getExpParam().getInt());
                case EID_expGetOriginX:
                    return new CValue(OriginX);
                case EID_expGetOriginY:
                    return new CValue(OriginY);
                case EID_expGetCellWidth:
                    return new CValue(CellWidth);
                case EID_expGetCellHeight:
                    return new CValue(CellHeight);
                case EID_expGetCellValue:
                    return expGetCellValue(ho.getExpParam().getInt(), ho.getExpParam().getInt());
                case EID_expGetXofCell:
                    return new CValue(CellWidth * ho.getExpParam().getInt() + OriginX);
                case EID_expGetYofCell:
                    return new CValue(CellHeight * ho.getExpParam().getInt() + OriginY);
                case EID_expMovedFixed:
                    return new CValue(MovedFixed);
                case EID_expMovedNewX:
                    return new CValue(MovedNewX);
                case EID_expMovedNewY:
                    return new CValue(MovedNewY);
                case EID_expMovedOldX:
                    return new CValue(MovedOldX);
                case EID_expMovedOldY:
                    return new CValue(MovedOldY);
                case EID_expDeletedFixed:
                    return new CValue(DeletedFixed);
                case EID_expDeletedX:
                    return new CValue(DeletedX);
                case EID_expDeletedY:
                    return new CValue(DeletedY);
            }
            return new CValue(0);//won't be used
        }

        private CValue expGetXofBrick(int i)
        {
            if (i < Bricks.size())
            {
                return new CValue(getXbrick(((int) Bricks.get(i))));
            }
            else
            {
                return new CValue(-1);
            }
        }

        private CValue expGetYofBrick(int i)
        {
            if (i < Bricks.size())
            {
                return new CValue(getYbrick(((int) Bricks.get(i))));
            }
            else
            {
                return new CValue(-1);
            }
        }

        private CValue expGetNumBricksInHozLine(int y)
        {
            int count = 0;

            for (int i = 0; i < BSizeX; i++)
            {
                if (getBrick(i, y) != 0)
                {
                    count++;
                }
            }
            return new CValue(count);
        }

        private CValue expGetNumBricksInVerLine(int x)
        {
            int count = 0;

            for (int i = 0; i < BSizeY; i++)
            {
                if (getBrick(x, i) != 0)
                {
                    count++;
                }
            }
            return new CValue(count);
        }

        private CValue expCountSorrounding(int x, int y, int value)
        {
            int[] offsetX =
            {
                -1, 0, 1, -1, 1, -1, 0, 1
            };
            int[] offsetY =
            {
                -1, -1, -1, 0, 0, 1, 1, 1
            };

            int count = 0;

            for (int i = 0; i < 8; i++)
            {
                if (getBrick(x + offsetX[i], y + offsetY[i]) == value)
                {
                    count++;
                }
            }

            return new CValue(count);
        }

        private CValue expCountTotal()
        {
            int count = 0;
            for (int i = 0; i < BSizeX * BSizeY; i++)
            {
                if (Board[i] != 0)
                {
                    count++;
                }
            }
            return new CValue(count);
        }

        private CValue expGetFoundBrickFixed(int i)
        {
            if (i < Looped.size())
            {
                if (CHECKPOS(LoopIndex))
                {
                    return new CValue(FixedBoard[LoopIndex]);
                }
            }
            return new CValue(-1);
        }

        private CValue expGetFixedOfBrick()
        {
            if (LoopIndex < Bricks.size())
            {
                if (CHECKPOS(((int) Bricks.get(LoopIndex))))
                {
                    return new CValue(FixedBoard[((int) Bricks.get(LoopIndex))]);
                }
            }
            return new CValue(-1);
        }

        private CValue expGetFixedAt(int x, int y)
        {
            if (getPos(x, y) != -1)
            {
                return new CValue(FixedBoard[getPos(x, y)]);
            }
            return new CValue(-1);
        }

        private CValue expFindXfromFixed(int fix)
        {
            int size = BSizeX * BSizeY;

            for (int i = 0; i < size; i++)
            {
                if (FixedBoard[i] == fix)
                {
                    return new CValue(getXbrick(i));
                }
            }
            return new CValue(-1);
        }

        private CValue expFindYfromFixed(int fix)
        {
            int size = BSizeX * BSizeY;

            for (int i = 0; i < size; i++)
            {
                if (FixedBoard[i] == fix)
                {
                    return new CValue(getYbrick(i));
                }
            }
            return new CValue(-1);
        }

        private CValue expFindBrickfromFixed(int fix)
        {
            int size = BSizeX * BSizeY;

            for (int i = 0; i < size; i++)
            {
                if (FixedBoard[i] == fix)
                {
                    return new CValue(Board[i]);
                }
            }
            return new CValue(-1);
        }

        private CValue expGetLoopFoundBrickFixed()
        {
            if (LoopedIndex < Looped.size())
            {
                if (CHECKPOS(((int) Looped.get(LoopedIndex))))
                {
                    return new CValue(FixedBoard[((int) Looped.get(LoopedIndex))]);
                }
            }
            return new CValue(-1);
        }

        private CValue expGetXBrickFromX(int x)
        {
            return new CValue((int) ((x - OriginX) / CellWidth));
        }

        private CValue expGetYBrickFromY(int y)
        {
            return new CValue((int) ((y - OriginY) / CellHeight));
        }

        private CValue expSnapXtoGrid(int x)
        {
            return new CValue(((int) ((x - OriginX) / CellWidth)) * CellWidth + OriginX);
        }

        private CValue expSnapYtoGrid(int y)
        {
            return new CValue(((int) ((y - OriginY) / CellHeight)) * CellHeight + OriginY);
        }

        private CValue expGetCellValue(int x, int y)
        {
            if (CHECKPOS(getPos(x, y)))
            {
                return new CValue(CellValues[getPos(x, y)]);
            }
            return new CValue(-1);
        }




    }
}
