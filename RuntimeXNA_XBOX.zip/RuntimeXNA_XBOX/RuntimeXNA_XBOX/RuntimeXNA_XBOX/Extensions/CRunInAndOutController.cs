﻿//----------------------------------------------------------------------------------
//
// MOVEMENT CONTROLLER: extension pObject
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;

namespace RuntimeXNA.Extensions
{
    class CRunInAndOutController : CRunExtension
    {
        const int ACT_SETOBJECT=0;
        const int ACT_SETOBJECTfix=1;
        const int ACT_POSITIONIN=2;
        const int ACT_POSITIONOUT=3;
        const int ACT_MOVEIN=4;
        const int ACT_MOVEOUT=5;
        const string DLL_INANDOUT = "InAndOut";
        const int ACTION_POSITIONIN=0;
        const int ACTION_POSITIONOUT=1;
        const int ACTION_MOVEIN=2;
        const int ACTION_MOVEOUT=3;

        CObject currentObject = null;

        public override int getNumberOfConditions()
        {
            return 0;
        }

        // Actions
        // -------------------------------------------------
        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                //*** Set pObject
                case ACT_SETOBJECT:
                    Action_SetObject_Object(act);
                    break;
                case ACT_SETOBJECTfix:
                    Action_SetObject_fixValue(act);
                    break;
                case ACT_POSITIONIN:
                    RACT_POSITIONIN(act);
                    break;
                case ACT_POSITIONOUT:
                    RACT_POSITIONOUT(act);
                    break;
                case ACT_MOVEIN:
                    RACT_MOVEIN(act);
                    break;
                case ACT_MOVEOUT:
                    RACT_MOVEOUT(act);
                    break;
            }
        }

        CObject getCurrentObject(String dllName)
        {
            // No need to search for the pObject if it's null
            if (currentObject == null)
            {
                return null;
            }

            // Enumerate objects
            CObject hoPtr;
            for (hoPtr = ho.getFirstObject(); hoPtr != null; hoPtr = ho.getNextObject())
            {
                if (hoPtr == currentObject)
                {
                    // Check if the pObject can have movements
                    if ((hoPtr.hoOEFlags & CObjectCommon.OEFLAG_MOVEMENTS) != 0)
                    {
                        // Test if the pObject has a movement and this movement is an extension
                        if (hoPtr.roc.rcMovementType == CMoveDef.MVTYPE_EXT)
                        {
                            if (dllName != null)
                            {
                                CObjectCommon ocPtr = hoPtr.hoCommon;
                                CMoveDefExtension mvPtr = (CMoveDefExtension)ocPtr.ocMovements.moveList[hoPtr.rom.rmMvtNum];
                                if (string.Compare(dllName, mvPtr.moduleName, StringComparison.OrdinalIgnoreCase) == 0)
                                {
                                    return hoPtr;
                                }
                                else
                                {
                                    return null;
                                }
                            }
                            else
                            {
                                return hoPtr;
                            }
                        }
                        return null;
                    }
                }
            }
            currentObject = null;
            return null;
        }

        // ============================================================================
        //
        // ACTIONS ROUTINES
        //
        // ============================================================================

        //*** Set pObject
        void Action_SetObject_Object(CActExtension act)
        {
            CObject hoPtr = act.getParamObject(rh, 0);
            if ((hoPtr.hoOEFlags & CObjectCommon.OEFLAG_MOVEMENTS) != 0)
            {
                if (hoPtr.roc.rcMovementType == CMoveDef.MVTYPE_EXT)
                {
                    currentObject = hoPtr;
                }
            }
        }

        void Action_SetObject_fixValue(CActExtension act)
    {
        int fix = act.getParamExpression(rh, 0);
        CObject hoPtr = ho.getObjectFromFixed(fix);

        if (hoPtr != null)
        {
            if ((hoPtr.hoOEFlags & CObjectCommon.OEFLAG_MOVEMENTS) != 0)
            {
                if (hoPtr.roc.rcMovementType == CMoveDef.MVTYPE_EXT)
                {
                    currentObject = hoPtr;
                }
            }
        }
    }
        void RACT_POSITIONIN(CActExtension act)
    {
        CObject pObject=getCurrentObject(DLL_INANDOUT);
        if (pObject!=null)
            ho.callMovement(pObject, ACTION_POSITIONIN, 0);
    }
        void RACT_POSITIONOUT(CActExtension act)
    {
        CObject pObject=getCurrentObject(DLL_INANDOUT);
        if (pObject!=null)
            ho.callMovement(pObject, ACTION_POSITIONOUT, 0);
    }
        void RACT_MOVEIN(CActExtension act)
    {
        CObject pObject=getCurrentObject(DLL_INANDOUT);
        if (pObject!=null)
            ho.callMovement(pObject, ACTION_MOVEIN, 0);
    }
        void RACT_MOVEOUT(CActExtension act)
    {
        CObject pObject=getCurrentObject(DLL_INANDOUT);
        if (pObject!=null)
            ho.callMovement(pObject, ACTION_MOVEOUT, 0);
    }

    }
}
