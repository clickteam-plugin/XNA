﻿//----------------------------------------------------------------------------------
//
// CRunKcDbl: Double precision calculator object
// fin 30/1/09
//greyhill
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;

namespace RuntimeXNA.Extensions
{
    class CRunKcDbl : CRunExtension
    {
        const int ACT_SETFORMAT_STD = 0;
        const int ACT_SETFORMAT_NDIGITS = 1;
        const int ACT_SETFORMAT_NDECIMALS = 2;
        const int EXP_ADD = 0;
        const int EXP_SUB = 1;
        const int EXP_MUL = 2;
        const int EXP_DIVIDE = 3;
        const int EXP_FMT_NDIGITS = 4;
        const int EXP_FMT_NDECIMALS = 5;

        int m_nDigits;
        int m_nDecimals;

        public override int getNumberOfConditions()
        {
            return 0;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            ho.hoX = cob.cobX;
            ho.hoY = cob.cobY;
            ho.hoImgWidth = 32;
            ho.hoImgHeight = 32;

            this.m_nDigits = 32;
            this.m_nDecimals = -1;

            return true;
        }

        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case ACT_SETFORMAT_STD:
                    Act_SetFormat_Std();
                    break;
                case ACT_SETFORMAT_NDIGITS:
                    Act_SetFormat_NDigits(act.getParamExpression(rh, 0));
                    break;
                case ACT_SETFORMAT_NDECIMALS:
                    Act_SetFormat_NDecimals(act.getParamExpression(rh, 0));
                    break;
            }
        }

        private void Act_SetFormat_Std()
        {
            m_nDigits = 32;
            m_nDecimals = -1;
        }

        private void Act_SetFormat_NDigits(int n)
        {
            m_nDigits = n;
            if (m_nDigits <= 0)
            {
                m_nDigits = 1;
            }
            if (m_nDigits > 256)
            {
                m_nDigits = 256;
            }
            m_nDecimals = -1;
        }

        private void Act_SetFormat_NDecimals(int n)
        {
            m_nDecimals = n;
            if (m_nDecimals < 0)
            {
                m_nDecimals = 0;
            }
            else if (m_nDecimals > 256)
            {
                m_nDecimals = 256;
            }
        }

        public override CValue expression(int num)
        {
            switch (num)
            {
                case EXP_ADD:
                    return Exp_Add(ho.getExpParam().getString(), ho.getExpParam().getString());
                case EXP_SUB:
                    return Exp_Sub(ho.getExpParam().getString(), ho.getExpParam().getString());
                case EXP_MUL:
                    return Exp_Mul(ho.getExpParam().getString(), ho.getExpParam().getString());
                case EXP_DIVIDE:
                    return Exp_Div(ho.getExpParam().getString(), ho.getExpParam().getString());
                case EXP_FMT_NDIGITS:
                    return Exp_Fmt_NDigits(ho.getExpParam().getString(), ho.getExpParam().getInt());
                case EXP_FMT_NDECIMALS:
                    return Exp_Fmt_NDecimals(ho.getExpParam().getString(), ho.getExpParam().getInt());
            }
            return new CValue(0);//won't be used
        }

        double StringToDouble(String ps)
        {
            double r = 0;
            try
            {
                r = System.Double.Parse(ps);
            }
            catch (System.FormatException e)
            {
                e.GetType();
            }
            return r;
        }

        String DoubleToString(double v)
        {
            String param;

            if (m_nDecimals >= 0)
            {
                param=v.ToString("F"+m_nDecimals.ToString());
            }
            else
            {
                param=v.ToString();
            }
            return param;
        }

        private CValue Exp_Add(String pValStr1, String pValStr2)
        {
            String pDest = "";
            if (pValStr1 != null && pValStr2 != null)
            {
                double val1 = StringToDouble(pValStr1);
                double val2 = StringToDouble(pValStr2);
                val1 += val2;
                pDest = DoubleToString(val1);
            }
            return new CValue(pDest);
        }

        private CValue Exp_Sub(String pValStr1, String pValStr2)
        {
            String pDest = "";
            if (pValStr1 != null && pValStr2 != null)
            {
                double val1 = StringToDouble(pValStr1);
                double val2 = StringToDouble(pValStr2);
                val1 -= val2;
                pDest = DoubleToString(val1);
            }
            return new CValue(pDest);
        }

        private CValue Exp_Mul(String pValStr1, String pValStr2)
        {
            String pDest = "";
            if (pValStr1 != null && pValStr2 != null)
            {
                double val1 = StringToDouble(pValStr1);
                double val2 = StringToDouble(pValStr2);
                val1 *= val2;
                pDest = DoubleToString(val1);
            }
            return new CValue(pDest);
        }

        private CValue Exp_Div(String pValStr1, String pValStr2)
        {
            String pDest = "";
            if (pValStr1 != null && pValStr2 != null)
            {
                double val1 = StringToDouble(pValStr1);
                double val2 = StringToDouble(pValStr2);
                if (val2 != 0.0)
                {
                    val1 /= val2;
                    pDest = DoubleToString(val1);
                }
            }
            return new CValue(pDest);
        }

        private CValue Exp_Fmt_NDigits(String param, int n)
        {
            return new CValue(param); //normal int
        }

        private CValue Exp_Fmt_NDecimals(String param, int n)
        {
            return new CValue(param);
        }

    }
}
