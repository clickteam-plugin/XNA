﻿//----------------------------------------------------------------------------------
//
// CRUNOBJECTMOVER
//
//----------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RuntimeXNA.Extensions;
using RuntimeXNA.Services;
using RuntimeXNA.RunLoop;
using RuntimeXNA.Sprites;
using RuntimeXNA.Conditions;
using RuntimeXNA.Actions;
using RuntimeXNA.Expressions;
using RuntimeXNA.Objects;
using RuntimeXNA.Params;
using RuntimeXNA.Frame;
using RuntimeXNA.OI;
using RuntimeXNA.Movements;

namespace RuntimeXNA.Extensions
{
    class CRunObjectMover : CRunExtension
    {
        short enabled;
        int previousX;
        int previousY;

        public override int getNumberOfConditions()
        {
            return 1;
        }

        public override bool createRunObject(CFile file, CCreateObjectInfo cob, int version)
        {
            ho.hoImgWidth = file.readAInt();
            ho.hoImgHeight = file.readAInt();
            enabled = file.readAShort();
            previousX = ho.hoX;
            previousY = ho.hoY;

            return false;
        }

        public override int handleRunObject()
        {
            if (ho.hoX != previousX || ho.hoY != previousY)
            {
                int deltaX = ho.hoX - previousX;
                int deltaY = ho.hoY - previousY;
                if (enabled != 0)
                {
                    int n;
                    int x1 = previousX;
                    int y1 = previousY;
                    int x2 = previousX + ho.hoImgWidth;
                    int y2 = previousY + ho.hoImgHeight;
                    CRun rhPtr = ho.hoAdRunHeader;
                    int count = 0;
                    for (n = 0; n < rhPtr.rhNObjects; n++)
                    {
                        while (rhPtr.rhObjectList[count] == null)
                        {
                            count++;
                        }
                        CObject pHo = rhPtr.rhObjectList[count];
                        count++;
                        if (pHo != ho)
                        {
                            if (pHo.hoX >= x1 && pHo.hoX + pHo.hoImgWidth < x2)
                            {
                                if (pHo.hoY >= y1 && pHo.hoY + pHo.hoImgHeight < y2)
                                {
                                    setPosition(pHo, pHo.hoX + deltaX, pHo.hoY + deltaY);
                                }
                            }
                        }
                    }
                }
                previousX = ho.hoX;
                previousY = ho.hoY;
            }
            return 0;
        }

        void setPosition(CObject pHo, int x, int y)
        {
            if (pHo.rom != null)
            {
                pHo.rom.rmMovement.setXPosition(x);
                pHo.rom.rmMovement.setYPosition(y);
            }
            else
            {
                pHo.hoX = x;
                pHo.hoY = y;
                if (pHo.roc != null)
                {
                    pHo.roc.rcChanged = true;
                    pHo.roc.rcCheckCollides = true;
                }
            }
        }

        // Conditions
        // --------------------------------------------------
        public override bool condition(int num, CCndExtension cnd)
        {
            switch (num)
            {
                case 0:
                    return cndEnabled(cnd);
            }
            return false;
        }

        bool cndEnabled(CCndExtension cnd)
        {
            return enabled != 0;
        }

        // Actions
        // -------------------------------------------------
        public override void action(int num, CActExtension act)
        {
            switch (num)
            {
                case 0:
                    actSetWidth(act);
                    break;
                case 1:
                    actSetHeight(act);
                    break;
                case 2:
                    actEnable(act);
                    break;
                case 3:
                    actDisable(act);
                    break;
            }
        }

        void actEnable(CActExtension act)
        {
            enabled = 1;
        }

        void actDisable(CActExtension act)
        {
            enabled = 0;
        }

        void actSetWidth(CActExtension act)
        {
            int width = act.getParamExpression(rh, 0);
            if (width > 0)
            {
                ho.hoImgWidth = width;
            }
        }

        void actSetHeight(CActExtension act)
        {
            int height = act.getParamExpression(rh, 0);
            if (height > 0)
            {
                ho.hoImgHeight = height;
            }
        }

        // Expressions
        // --------------------------------------------
        public override CValue expression(int num)
        {
            switch (num)
            {
                case 0:
                    return expGetWidth();
                case 1:
                    return expGetHeight();
            }
            return null;
        }

        CValue expGetWidth()
        {
            return new CValue(ho.hoImgWidth);
        }

        CValue expGetHeight()
        {
            return new CValue(ho.hoImgHeight);
        }




    }
}
